import sys

import math as python_lib_Math
import math as Math
from PyQt5.QtWidgets import QWidget
from krita import DockWidget
from krita import Extension
import inspect as python_lib_Inspect
from krita import Krita
from krita import ManagedColor
from krita import Selection
from PyQt5.QtCore import QBuffer
from PyQt5.QtCore import QByteArray
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QHBoxLayout
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5.QtWidgets import QCheckBox
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QGroupBox
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QPlainTextEdit
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QScrollArea
from PyQt5.QtWidgets import QSpinBox
from PyQt5.QtWidgets import QDoubleSpinBox
from PyQt5.QtWidgets import QTabWidget
import sys as python_lib_Sys
import functools as python_lib_Functools
import json as python_lib_Json
import random as python_lib_Random
import re as python_lib_Re
import socket as python_lib_Socket
import ssl as python_lib_Ssl
import traceback as python_lib_Traceback
from datetime import datetime as python_lib_datetime_Datetime
from datetime import timezone as python_lib_datetime_Timezone
from io import StringIO as python_lib_io_StringIO
from socket import socket as python_lib_socket_Socket
from ssl import SSLContext as python_lib_ssl_SSLContext
import urllib.parse as python_lib_urllib_Parse


class _hx_AnonObject:
    _hx_disable_getattr = False
    def __init__(self, fields):
        self.__dict__ = fields
    def __repr__(self):
        return repr(self.__dict__)
    def __contains__(self, item):
        return item in self.__dict__
    def __getitem__(self, item):
        return self.__dict__[item]
    def __getattr__(self, name):
        if (self._hx_disable_getattr):
            raise AttributeError('field does not exist')
        else:
            return None
    def _hx_hasattr(self,field):
        self._hx_disable_getattr = True
        try:
            getattr(self, field)
            self._hx_disable_getattr = False
            return True
        except AttributeError:
            self._hx_disable_getattr = False
            return False



class Enum:
    _hx_class_name = "Enum"
    __slots__ = ("tag", "index", "params")
    _hx_fields = ["tag", "index", "params"]
    _hx_methods = ["__str__"]

    def __init__(self,tag,index,params):
        self.tag = tag
        self.index = index
        self.params = params

    def __str__(self):
        if (self.params is None):
            return self.tag
        else:
            return self.tag + '(' + (', '.join(str(v) for v in self.params)) + ')'

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.tag = None
        _hx_o.index = None
        _hx_o.params = None
Enum._hx_class = Enum


class Class: pass


class Date:
    _hx_class_name = "Date"
    __slots__ = ("date", "dateUTC")
    _hx_fields = ["date", "dateUTC"]
    _hx_methods = ["toString"]
    _hx_statics = ["makeLocal"]

    def __init__(self,year,month,day,hour,_hx_min,sec):
        self.dateUTC = None
        if (year < python_lib_datetime_Datetime.min.year):
            year = python_lib_datetime_Datetime.min.year
        if (day == 0):
            day = 1
        self.date = Date.makeLocal(python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0))
        self.dateUTC = self.date.astimezone(python_lib_datetime_Timezone.utc)

    def toString(self):
        return self.date.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def makeLocal(date):
        try:
            return date.astimezone()
        except BaseException as _g:
            None
            tzinfo = python_lib_datetime_Datetime.now(python_lib_datetime_Timezone.utc).astimezone().tzinfo
            return date.replace(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'tzinfo': tzinfo})))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.date = None
        _hx_o.dateUTC = None
Date._hx_class = Date


class _Defs_Defs_Fields_:
    _hx_class_name = "_Defs.Defs_Fields_"
    __slots__ = ()
    _hx_statics = ["fn_indices", "baseurl", "defaults", "ui_tags"]
_Defs_Defs_Fields_._hx_class = _Defs_Defs_Fields_


class EReg:
    _hx_class_name = "EReg"
    __slots__ = ("pattern", "matchObj", "_hx_global")
    _hx_fields = ["pattern", "matchObj", "global"]

    def __init__(self,r,opt):
        self.matchObj = None
        self._hx_global = False
        options = 0
        _g = 0
        _g1 = len(opt)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            c = (-1 if ((i >= len(opt))) else ord(opt[i]))
            if (c == 109):
                options = (options | python_lib_Re.M)
            if (c == 105):
                options = (options | python_lib_Re.I)
            if (c == 115):
                options = (options | python_lib_Re.S)
            if (c == 117):
                options = (options | python_lib_Re.U)
            if (c == 103):
                self._hx_global = True
        self.pattern = python_lib_Re.compile(r,options)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.pattern = None
        _hx_o.matchObj = None
        _hx_o._hx_global = None
EReg._hx_class = EReg


class Lambda:
    _hx_class_name = "Lambda"
    __slots__ = ()
    _hx_statics = ["exists"]

    @staticmethod
    def exists(it,f):
        x = HxOverrides.iterator(it)
        while x.hasNext():
            x1 = x.next()
            if f(x1):
                return True
        return False
Lambda._hx_class = Lambda


class host_Docker(DockWidget):
    _hx_class_name = "host.Docker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canvasChanged"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = DockWidget


    def __init__(self):
        super().__init__()

    def canvasChanged(self,canvas):
        pass

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
host_Docker._hx_class = host_Docker


class hxasync_Asyncable:
    _hx_class_name = "hxasync.Asyncable"
    __slots__ = ()
hxasync_Asyncable._hx_class = hxasync_Asyncable


class MyDocker(host_Docker):
    _hx_class_name = "MyDocker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["generate2", "generate"]
    _hx_statics = ["__meta__", "checkReady"]
    _hx_interfaces = [hxasync_Asyncable]
    _hx_super = host_Docker


    def __init__(self):
        super().__init__()
        host_App.init(self)
        mode = _Defs_Defs_Fields_.ui_tags.keys()
        while mode.hasNext():
            mode1 = mode.next()
            print(str(mode1))
            print(str(len(_Defs_Defs_Fields_.defaults.h.get(mode1,None))))
            print(str(len(_Defs_Defs_Fields_.ui_tags.h.get(mode1,None))))

    def generate2(self,mode,form):
        ready = MyDocker.checkReady(mode)
        if ready:
            if (mode == "inpaint"):
                host_UI.is_inpainting = 1
            else:
                host_UI.is_inpainting = 0
            host_UI.toast(("READY - Generating " + ("null" if mode is None else mode)))
            apidata = []
            _g = 0
            _g1 = len(form)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                if (Reflect.field((form[i] if i >= 0 and i < len(form) else None),"getter") is not None):
                    p = Reflect.field((form[i] if i >= 0 and i < len(form) else None),"getter")()
                    apidata.append(p)
                else:
                    print("no getter - defaulting")
                    print(str((form[i] if i >= 0 and i < len(form) else None)))
                    try:
                        props = Reflect.field((form[i] if i >= 0 and i < len(form) else None),"props")
                        x = Reflect.field(props,"value")
                        apidata.append(x)
                    except BaseException as _g2:
                        e = haxe_Exception.caught(_g2)
                        print(str(e))
            print(str(apidata))
            Utils.request(mode,apidata)

    def generate(self,mode):
        ready = MyDocker.checkReady(mode)
        if ready:
            host_UI.toast(("READY - Generating " + ("null" if mode is None else mode)))
            apidata = []
            _g = 0
            _g1 = len(_Defs_Defs_Fields_.defaults.h.get(mode,None))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                if (python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i) is not None):
                    print(str(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i)))
                    p = host_UI.gatherParameter(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i))
                    print(str(p))
                    apidata.append(p)
                else:
                    x = python_internal_ArrayImpl._get(_Defs_Defs_Fields_.defaults.h.get(mode,None), i)
                    apidata.append(x)
            Utils.request(mode,apidata)

    @staticmethod
    def checkReady(mode):
        state = host_App.getDocumentState()
        if (Reflect.field(state,"selection") is None):
            selection = _hx_AnonObject({'x': 0, 'y': 0, 'width': 512, 'height': 512})
            Reflect.setField(state,"selection",selection)
            host_App.setDocumentState(state)
            host_UI.toast("NOT READY: no selection existed - defaulted to 512x512")
            return False
        elif ((HxOverrides.mod(Reflect.field(state,"selection").width, 64) != 0) or ((HxOverrides.mod(Reflect.field(state,"selection").height, 64) != 0))):
            host_UI.toast("NOT READY: resized selection to multiples of 64")
            x = (Reflect.field(state,"selection").width / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            Reflect.field(state,"selection").width = (64 * ((1 + tmp)))
            x = (Reflect.field(state,"selection").height / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                None
                tmp = None
            Reflect.field(state,"selection").height = (64 * ((1 + tmp)))
            host_App.setDocumentState(state)
            return False
        if (mode == "inpaint"):
            mask = host_Image.layerByName("!sdmask")
            if (mask is None):
                host_UI.toast("mask needed - created visible layer called !sdmask")
                mask = Krita.instance().activeDocument().createNode("!sdmask","paintlayer")
                mask.setOpacity(128)
                col_white = ManagedColor("RGBA","U8","")
                col_white.setComponents([1.0, 1.0, 1.0, 1.0])
                Krita.instance().activeWindow().activeView().setForeGroundColor(col_white)
                Krita.instance().activeDocument().activeNode().parentNode().addChildNode(mask,python_internal_ArrayImpl._get(Krita.instance().activeDocument().topLevelNodes(), -1))
                Krita.instance().activeDocument().setActiveNode(mask)
                return False
        return True

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
MyDocker._hx_class = MyDocker


class MyExtension(Extension):
    _hx_class_name = "MyExtension"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = Extension


    def __init__(self,parent = None):
        super().__init__(parent)
MyExtension._hx_class = MyExtension


class Reflect:
    _hx_class_name = "Reflect"
    __slots__ = ()
    _hx_statics = ["field", "setField", "getProperty", "isFunction", "compareMethods", "copy"]

    @staticmethod
    def field(o,field):
        return python_Boot.field(o,field)

    @staticmethod
    def setField(o,field,value):
        setattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)),value)

    @staticmethod
    def getProperty(o,field):
        if (o is None):
            return None
        if (field in python_Boot.keywords):
            field = ("_hx_" + field)
        elif ((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95))):
            field = ("_hx_" + field)
        if isinstance(o,_hx_AnonObject):
            return Reflect.field(o,field)
        tmp = Reflect.field(o,("get_" + ("null" if field is None else field)))
        if ((tmp is not None) and callable(tmp)):
            return tmp()
        else:
            return Reflect.field(o,field)

    @staticmethod
    def isFunction(f):
        if (not ((python_lib_Inspect.isfunction(f) or python_lib_Inspect.ismethod(f)))):
            return python_Boot.hasField(f,"func_code")
        else:
            return True

    @staticmethod
    def compareMethods(f1,f2):
        if HxOverrides.eq(f1,f2):
            return True
        if (isinstance(f1,python_internal_MethodClosure) and isinstance(f2,python_internal_MethodClosure)):
            m1 = f1
            m2 = f2
            if HxOverrides.eq(m1.obj,m2.obj):
                return (m1.func == m2.func)
            else:
                return False
        if ((not Reflect.isFunction(f1)) or (not Reflect.isFunction(f2))):
            return False
        return False

    @staticmethod
    def copy(o):
        if (o is None):
            return None
        o2 = _hx_AnonObject({})
        _g = 0
        _g1 = python_Boot.fields(o)
        while (_g < len(_g1)):
            f = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            value = Reflect.field(o,f)
            setattr(o2,(("_hx_" + f) if ((f in python_Boot.keywords)) else (("_hx_" + f) if (((((len(f) > 2) and ((ord(f[0]) == 95))) and ((ord(f[1]) == 95))) and ((ord(f[(len(f) - 1)]) != 95)))) else f)),value)
        return o2
Reflect._hx_class = Reflect


class Std:
    _hx_class_name = "Std"
    __slots__ = ()
    _hx_statics = ["is", "isOfType", "string", "parseInt"]

    @staticmethod
    def _hx_is(v,t):
        return Std.isOfType(v,t)

    @staticmethod
    def isOfType(v,t):
        if ((v is None) and ((t is None))):
            return False
        if (t is None):
            return False
        if ((type(t) == type) and (t == Dynamic)):
            return (v is not None)
        isBool = isinstance(v,bool)
        if (((type(t) == type) and (t == Bool)) and isBool):
            return True
        if ((((not isBool) and (not ((type(t) == type) and (t == Bool)))) and ((type(t) == type) and (t == Int))) and isinstance(v,int)):
            return True
        vIsFloat = isinstance(v,float)
        tmp = None
        tmp1 = None
        if (((not isBool) and vIsFloat) and ((type(t) == type) and (t == Int))):
            f = v
            tmp1 = (((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))
        else:
            tmp1 = False
        if tmp1:
            tmp1 = None
            try:
                tmp1 = int(v)
            except BaseException as _g:
                None
                tmp1 = None
            tmp = (v == tmp1)
        else:
            tmp = False
        if ((tmp and ((v <= 2147483647))) and ((v >= -2147483648))):
            return True
        if (((not isBool) and ((type(t) == type) and (t == Float))) and isinstance(v,(float, int))):
            return True
        if ((type(t) == type) and (t == str)):
            return isinstance(v,str)
        isEnumType = ((type(t) == type) and (t == Enum))
        if ((isEnumType and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_constructs")):
            return True
        if isEnumType:
            return False
        isClassType = ((type(t) == type) and (t == Class))
        if ((((isClassType and (not isinstance(v,Enum))) and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_class_name")) and (not hasattr(v,"_hx_constructs"))):
            return True
        if isClassType:
            return False
        tmp = None
        try:
            tmp = isinstance(v,t)
        except BaseException as _g:
            None
            tmp = False
        if tmp:
            return True
        if python_lib_Inspect.isclass(t):
            cls = t
            loop = None
            def _hx_local_1(intf):
                f = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                if (f is not None):
                    _g = 0
                    while (_g < len(f)):
                        i = (f[_g] if _g >= 0 and _g < len(f) else None)
                        _g = (_g + 1)
                        if (i == cls):
                            return True
                        else:
                            l = loop(i)
                            if l:
                                return True
                    return False
                else:
                    return False
            loop = _hx_local_1
            currentClass = v.__class__
            result = False
            while (currentClass is not None):
                if loop(currentClass):
                    result = True
                    break
                currentClass = python_Boot.getSuperClass(currentClass)
            return result
        else:
            return False

    @staticmethod
    def string(s):
        return python_Boot.toString1(s,"")

    @staticmethod
    def parseInt(x):
        if (x is None):
            return None
        try:
            return int(x)
        except BaseException as _g:
            None
            base = 10
            _hx_len = len(x)
            foundCount = 0
            sign = 0
            firstDigitIndex = 0
            lastDigitIndex = -1
            previous = 0
            _g = 0
            _g1 = _hx_len
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                c = (-1 if ((i >= len(x))) else ord(x[i]))
                if (((c > 8) and ((c < 14))) or ((c == 32))):
                    if (foundCount > 0):
                        return None
                    continue
                else:
                    c1 = c
                    if (c1 == 43):
                        if (foundCount == 0):
                            sign = 1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 45):
                        if (foundCount == 0):
                            sign = -1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 48):
                        if (not (((foundCount == 0) or (((foundCount == 1) and ((sign != 0))))))):
                            if (not (((48 <= c) and ((c <= 57))))):
                                if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                    break
                    elif ((c1 == 120) or ((c1 == 88))):
                        if ((previous == 48) and ((((foundCount == 1) and ((sign == 0))) or (((foundCount == 2) and ((sign != 0))))))):
                            base = 16
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (not (((48 <= c) and ((c <= 57))))):
                        if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                            break
                if (((foundCount == 0) and ((sign == 0))) or (((foundCount == 1) and ((sign != 0))))):
                    firstDigitIndex = i
                foundCount = (foundCount + 1)
                lastDigitIndex = i
                previous = c
            if (firstDigitIndex <= lastDigitIndex):
                digits = HxString.substring(x,firstDigitIndex,(lastDigitIndex + 1))
                try:
                    return (((-1 if ((sign == -1)) else 1)) * int(digits,base))
                except BaseException as _g:
                    return None
            return None
Std._hx_class = Std


class Float: pass


class Int: pass


class Bool: pass


class Dynamic: pass


class StringBuf:
    _hx_class_name = "StringBuf"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["get_length"]

    def __init__(self):
        self.b = python_lib_io_StringIO()

    def get_length(self):
        pos = self.b.tell()
        self.b.seek(0,2)
        _hx_len = self.b.tell()
        self.b.seek(pos,0)
        return _hx_len

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
StringBuf._hx_class = StringBuf


class StringTools:
    _hx_class_name = "StringTools"
    __slots__ = ()
    _hx_statics = ["isSpace", "ltrim", "rtrim", "lpad", "replace"]

    @staticmethod
    def isSpace(s,pos):
        if (((len(s) == 0) or ((pos < 0))) or ((pos >= len(s)))):
            return False
        c = HxString.charCodeAt(s,pos)
        if (not (((c > 8) and ((c < 14))))):
            return (c == 32)
        else:
            return True

    @staticmethod
    def ltrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,r)):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,r,(l - r))
        else:
            return s

    @staticmethod
    def rtrim(s):
        l = len(s)
        r = 0
        while ((r < l) and StringTools.isSpace(s,((l - r) - 1))):
            r = (r + 1)
        if (r > 0):
            return HxString.substr(s,0,(l - r))
        else:
            return s

    @staticmethod
    def lpad(s,c,l):
        if (len(c) <= 0):
            return s
        buf = StringBuf()
        l = (l - len(s))
        while (buf.get_length() < l):
            s1 = Std.string(c)
            buf.b.write(s1)
        s1 = Std.string(s)
        buf.b.write(s1)
        return buf.b.getvalue()

    @staticmethod
    def replace(s,sub,by):
        _this = (list(s) if ((sub == "")) else s.split(sub))
        return by.join([python_Boot.toString1(x1,'') for x1 in _this])
StringTools._hx_class = StringTools

class ValueType(Enum):
    __slots__ = ()
    _hx_class_name = "ValueType"
    _hx_constructs = ["TNull", "TInt", "TFloat", "TBool", "TObject", "TFunction", "TClass", "TEnum", "TUnknown"]

    @staticmethod
    def TClass(c):
        return ValueType("TClass", 6, (c,))

    @staticmethod
    def TEnum(e):
        return ValueType("TEnum", 7, (e,))
ValueType.TNull = ValueType("TNull", 0, ())
ValueType.TInt = ValueType("TInt", 1, ())
ValueType.TFloat = ValueType("TFloat", 2, ())
ValueType.TBool = ValueType("TBool", 3, ())
ValueType.TObject = ValueType("TObject", 4, ())
ValueType.TFunction = ValueType("TFunction", 5, ())
ValueType.TUnknown = ValueType("TUnknown", 8, ())
ValueType._hx_class = ValueType


class Type:
    _hx_class_name = "Type"
    __slots__ = ()
    _hx_statics = ["getClass", "getSuperClass", "getClassName", "createEmptyInstance", "typeof"]

    @staticmethod
    def getClass(o):
        if (o is None):
            return None
        o1 = o
        if ((o1 is not None) and ((HxOverrides.eq(o1,str) or python_lib_Inspect.isclass(o1)))):
            return None
        if isinstance(o,_hx_AnonObject):
            return None
        if hasattr(o,"_hx_class"):
            return o._hx_class
        if hasattr(o,"__class__"):
            return o.__class__
        else:
            return None

    @staticmethod
    def getSuperClass(c):
        return python_Boot.getSuperClass(c)

    @staticmethod
    def getClassName(c):
        if hasattr(c,"_hx_class_name"):
            return c._hx_class_name
        else:
            if (c == list):
                return "Array"
            if (c == Math):
                return "Math"
            if (c == str):
                return "String"
            try:
                return c.__name__
            except BaseException as _g:
                None
                return None

    @staticmethod
    def createEmptyInstance(cl):
        i = cl.__new__(cl)
        callInit = None
        def _hx_local_0(cl):
            sc = Type.getSuperClass(cl)
            if (sc is not None):
                callInit(sc)
            if hasattr(cl,"_hx_empty_init"):
                cl._hx_empty_init(i)
        callInit = _hx_local_0
        callInit(cl)
        return i

    @staticmethod
    def typeof(v):
        if (v is None):
            return ValueType.TNull
        elif isinstance(v,bool):
            return ValueType.TBool
        elif isinstance(v,int):
            return ValueType.TInt
        elif isinstance(v,float):
            return ValueType.TFloat
        elif isinstance(v,str):
            return ValueType.TClass(str)
        elif isinstance(v,list):
            return ValueType.TClass(list)
        elif (isinstance(v,_hx_AnonObject) or python_lib_Inspect.isclass(v)):
            return ValueType.TObject
        elif isinstance(v,Enum):
            return ValueType.TEnum(v.__class__)
        elif (isinstance(v,type) or hasattr(v,"_hx_class")):
            return ValueType.TClass(v.__class__)
        elif callable(v):
            return ValueType.TFunction
        else:
            return ValueType.TUnknown
Type._hx_class = Type


class Utils:
    _hx_class_name = "Utils"
    __slots__ = ()
    _hx_statics = ["__meta__", "params_for_layer", "request", "receive", "fetch_remote_png", "packInfo", "unpackInfo", "fetchAndInsert", "cleanTags", "cleanComponent", "fastdecode64", "fastencode64"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def request(mode,in_data):
        fn_i = None
        if (mode == "txt2img"):
            fn_i = host_UI.txt2img_generate_fn_index
        else:
            fn_i = host_UI.img2img_generate_fn_index
        data_formatted = haxe_format_JsonPrinter.print(_hx_AnonObject({'fn_index': fn_i, 'data': in_data, 'session_hash': None}),None,None)
        print(str(data_formatted))
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request('http://127.0.0.1:7860/api/predict')

        body_encoded = data_formatted.encode('utf-8')
        req.data=body_encoded
        req.add_header('Content-Type', 'application/json')
        req.add_header('Content-Length', str(len(body_encoded)))

        with urllib.request.urlopen(req) as res:
            Utils.receive(res.read())

        

    @staticmethod
    def receive(data):
        print("we get signal")
        obj = python_lib_Json.loads(data,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        print(str(obj))
        prefix = "data:image/png;base64,"
        string_array = (obj.data[0] if 0 < len(obj.data) else None)
        response_dict = python_lib_Json.loads((obj.data[1] if 1 < len(obj.data) else None),**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        _g = 0
        _g1 = len(string_array)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            finfo = (string_array[i] if i >= 0 and i < len(string_array) else None)
            name = Utils.packInfo(response_dict)
            _hx_bytes = Utils.fetch_remote_png(Reflect.field(finfo,"name"))
            host_Image.layerFromPng(_hx_bytes,name)
            _g2 = response_dict
            value = python_Boot._add_dynamic(Reflect.field(_g2,"seed"),1)
            setattr(_g2,(("_hx_" + "seed") if (("seed" in python_Boot.keywords)) else (("_hx_" + "seed") if (((((len("seed") > 2) and ((ord("seed"[0]) == 95))) and ((ord("seed"[1]) == 95))) and ((ord("seed"[(len("seed") - 1)]) != 95)))) else "seed")),value)
            _g3 = response_dict
            value1 = python_Boot._add_dynamic(Reflect.field(_g3,"subseed"),1)
            setattr(_g3,(("_hx_" + "subseed") if (("subseed" in python_Boot.keywords)) else (("_hx_" + "subseed") if (((((len("subseed") > 2) and ((ord("subseed"[0]) == 95))) and ((ord("subseed"[1]) == 95))) and ((ord("subseed"[(len("subseed") - 1)]) != 95)))) else "subseed")),value1)
        host_UI.toast((("OK - Generation finished for " + Std.string(len(string_array))) + " image(s)!"))

    @staticmethod
    def fetch_remote_png(fname):
        data = None
        url = ("http://localhost:7860/file=" + ("null" if fname is None else fname))
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request(url)

        with urllib.request.urlopen(req) as res:
            data = res.read()

        
        return data

    @staticmethod
    def packInfo(info):
        info_stripped = _hx_AnonObject({})
        _g = 0
        _g1 = python_Boot.fields(info)
        while (_g < len(_g1)):
            key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if ((host__UIDefs_UIDefs_Fields_.widgetinfo.h.get(key,None) is not None) and ((Reflect.field(info,key) is not None))):
                value = Reflect.field(info,key)
                setattr(info_stripped,(("_hx_" + key) if ((key in python_Boot.keywords)) else (("_hx_" + key) if (((((len(key) > 2) and ((ord(key[0]) == 95))) and ((ord(key[1]) == 95))) and ((ord(key[(len(key) - 1)]) != 95)))) else key)),value)
        print(str(info_stripped))
        return haxe_format_JsonPrinter.print(info_stripped,None,None)

    @staticmethod
    def unpackInfo(layer):
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        host_App.setLayerName(layer,StringTools.replace(layer.name,"Copy of ",""))
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        infoextract = layer._internal.name()
        jsonobj = python_lib_Json.loads(infoextract,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        return jsonobj

    @staticmethod
    def fetchAndInsert(layer,components):
        params = Utils.unpackInfo(layer)
        props = None
        _g = 0
        while (_g < len(components)):
            comp = (components[_g] if _g >= 0 and _g < len(components) else None)
            _g = (_g + 1)
            props = Reflect.field(comp,"props")
            if (Reflect.field(params,Reflect.field(props,"param_name")) is not None):
                Reflect.field(comp,"setter")(Reflect.field(params,Reflect.field(props,"param_name")))

    @staticmethod
    def cleanTags(tags):
        _g = 0
        while (_g < len(tags)):
            component = (tags[_g] if _g >= 0 and _g < len(tags) else None)
            _g = (_g + 1)
            Utils.cleanComponent(component)

    @staticmethod
    def cleanComponent(component):
        props = Reflect.field(component,"props")
        if (Reflect.field(props,"label") is not None):
            value = Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(props,"label"),"toLowerCase")(),"replace")(" ","_"),"replace")(" ","_"),"replace")(" ","_"),"replace")(" ","_"),"replace")(".",""),"replace")("\n","_")
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)
        else:
            value = Std.string(Reflect.field(component,"id"))
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)
        this1 = host__UIDefs_UIDefs_Fields_.parameterNames
        if (Reflect.field(props,"param_name") in this1.h):
            print(str(Reflect.field(props,"param_name")))
            this1 = host__UIDefs_UIDefs_Fields_.parameterNames
            key = Reflect.field(props,"param_name")
            value = this1.h.get(key,None)
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)

    @staticmethod
    def fastdecode64(data):
        import base64
        _hx_bytes = base64.decodebytes(data.encode("utf-8"))
        return _hx_bytes

    @staticmethod
    def fastencode64(data):
        return str(data.toBase64(), "utf-8")
Utils._hx_class = Utils


class cloner_Cloner:
    _hx_class_name = "cloner.Cloner"
    __slots__ = ("cache", "classHandles", "stringMapCloner", "intMapCloner")
    _hx_fields = ["cache", "classHandles", "stringMapCloner", "intMapCloner"]
    _hx_methods = ["returnString", "clone", "_clone", "handleAnonymous", "handleClass", "cloneArray", "cloneClass"]

    def __init__(self):
        self.intMapCloner = None
        self.stringMapCloner = None
        self.classHandles = None
        self.cache = None
        self.stringMapCloner = cloner_MapCloner(self,haxe_ds_StringMap)
        self.intMapCloner = cloner_MapCloner(self,haxe_ds_IntMap)
        self.classHandles = haxe_ds_StringMap()
        self.classHandles.h["String"] = self.returnString
        self.classHandles.h["Array"] = self.cloneArray
        self.classHandles.h["haxe.ds.StringMap"] = self.stringMapCloner.clone
        self.classHandles.h["haxe.ds.IntMap"] = self.intMapCloner.clone

    def returnString(self,v):
        return v

    def clone(self,v):
        self.cache = haxe_ds_ObjectMap()
        outcome = self._clone(v)
        self.cache = None
        return outcome

    def _clone(self,v):
        if (Type.getClassName(v) is not None):
            return v
        _g = Type.typeof(v)
        tmp = _g.index
        if (tmp == 0):
            return None
        elif (tmp == 1):
            return v
        elif (tmp == 2):
            return v
        elif (tmp == 3):
            return v
        elif (tmp == 4):
            return self.handleAnonymous(v)
        elif (tmp == 5):
            return None
        elif (tmp == 6):
            c = _g.params[0]
            if (not (v in self.cache.h)):
                self.cache.set(v,self.handleClass(c,v))
            return self.cache.h.get(v,None)
        elif (tmp == 7):
            e = _g.params[0]
            return v
        elif (tmp == 8):
            return None
        else:
            pass

    def handleAnonymous(self,v):
        properties = python_Boot.fields(v)
        anonymous = _hx_AnonObject({})
        _g = 0
        _g1 = len(properties)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            property = (properties[i] if i >= 0 and i < len(properties) else None)
            value = self._clone(Reflect.getProperty(v,property))
            setattr(anonymous,(("_hx_" + property) if ((property in python_Boot.keywords)) else (("_hx_" + property) if (((((len(property) > 2) and ((ord(property[0]) == 95))) and ((ord(property[1]) == 95))) and ((ord(property[(len(property) - 1)]) != 95)))) else property)),value)
        return anonymous

    def handleClass(self,c,inValue):
        this1 = self.classHandles
        key = Type.getClassName(c)
        handle = this1.h.get(key,None)
        if (handle is None):
            handle = self.cloneClass
        return handle(inValue)

    def cloneArray(self,inValue):
        array = list(inValue)
        _g = 0
        _g1 = len(array)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            python_internal_ArrayImpl._set(array, i, self._clone((array[i] if i >= 0 and i < len(array) else None)))
        return array

    def cloneClass(self,inValue):
        outValue = Type.createEmptyInstance(Type.getClass(inValue))
        fields = python_Boot.fields(inValue)
        _g = 0
        _g1 = len(fields)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            field = (fields[i] if i >= 0 and i < len(fields) else None)
            property = Reflect.getProperty(inValue,field)
            value = self._clone(property)
            setattr(outValue,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)),value)
        return outValue

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.cache = None
        _hx_o.classHandles = None
        _hx_o.stringMapCloner = None
        _hx_o.intMapCloner = None
cloner_Cloner._hx_class = cloner_Cloner


class cloner_MapCloner:
    _hx_class_name = "cloner.MapCloner"
    __slots__ = ("cloner", "type", "noArgs")
    _hx_fields = ["cloner", "type", "noArgs"]
    _hx_methods = ["clone"]

    def __init__(self,cloner,_hx_type):
        self.cloner = cloner
        self.type = _hx_type
        self.noArgs = []

    def clone(self,inValue):
        inMap = inValue
        _hx_map = self.type(*self.noArgs)
        key = inMap.keys()
        while key.hasNext():
            key1 = key.next()
            _hx_map.set(key1,self.cloner._clone(inMap.get(key1)))
        return _hx_map

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.cloner = None
        _hx_o.type = None
        _hx_o.noArgs = None
cloner_MapCloner._hx_class = cloner_MapCloner


class haxe_IMap:
    _hx_class_name = "haxe.IMap"
    __slots__ = ()
    _hx_methods = ["get", "set", "keys"]
haxe_IMap._hx_class = haxe_IMap


class haxe_Exception(Exception):
    _hx_class_name = "haxe.Exception"
    __slots__ = ("_hx___nativeStack", "_hx___skipStack", "_hx___nativeException", "_hx___previousException")
    _hx_fields = ["__nativeStack", "__skipStack", "__nativeException", "__previousException"]
    _hx_methods = ["unwrap", "toString", "get_message", "get_native"]
    _hx_statics = ["caught", "thrown"]
    _hx_interfaces = []
    _hx_super = Exception


    def __init__(self,message,previous = None,native = None):
        self._hx___previousException = None
        self._hx___nativeException = None
        self._hx___nativeStack = None
        self._hx___skipStack = 0
        super().__init__(message)
        self._hx___previousException = previous
        if ((native is not None) and Std.isOfType(native,BaseException)):
            self._hx___nativeException = native
            self._hx___nativeStack = haxe_NativeStackTrace.exceptionStack()
        else:
            self._hx___nativeException = self
            infos = python_lib_Traceback.extract_stack()
            if (len(infos) != 0):
                infos.pop()
            infos.reverse()
            self._hx___nativeStack = infos

    def unwrap(self):
        return self._hx___nativeException

    def toString(self):
        return self.get_message()

    def get_message(self):
        return str(self)

    def get_native(self):
        return self._hx___nativeException

    @staticmethod
    def caught(value):
        if Std.isOfType(value,haxe_Exception):
            return value
        elif Std.isOfType(value,BaseException):
            return haxe_Exception(str(value),None,value)
        else:
            return haxe_ValueException(value,None,value)

    @staticmethod
    def thrown(value):
        if Std.isOfType(value,haxe_Exception):
            return value.get_native()
        elif Std.isOfType(value,BaseException):
            return value
        else:
            e = haxe_ValueException(value)
            e._hx___skipStack = (e._hx___skipStack + 1)
            return e

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___nativeStack = None
        _hx_o._hx___skipStack = None
        _hx_o._hx___nativeException = None
        _hx_o._hx___previousException = None
haxe_Exception._hx_class = haxe_Exception


class haxe_NativeStackTrace:
    _hx_class_name = "haxe.NativeStackTrace"
    __slots__ = ()
    _hx_statics = ["saveStack", "exceptionStack"]

    @staticmethod
    def saveStack(exception):
        pass

    @staticmethod
    def exceptionStack():
        exc = python_lib_Sys.exc_info()
        if (exc[2] is not None):
            infos = python_lib_Traceback.extract_tb(exc[2])
            infos.reverse()
            return infos
        else:
            return []
haxe_NativeStackTrace._hx_class = haxe_NativeStackTrace


class haxe_ValueException(haxe_Exception):
    _hx_class_name = "haxe.ValueException"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["unwrap"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,value,previous = None,native = None):
        self.value = None
        super().__init__(Std.string(value),previous,native)
        self.value = value

    def unwrap(self):
        return self.value

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.value = None
haxe_ValueException._hx_class = haxe_ValueException


class haxe_io_Bytes:
    _hx_class_name = "haxe.io.Bytes"
    __slots__ = ("length", "b")
    _hx_fields = ["length", "b"]
    _hx_methods = ["sub", "getString", "toString"]
    _hx_statics = ["alloc", "ofString"]

    def __init__(self,length,b):
        self.length = length
        self.b = b

    def sub(self,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        return haxe_io_Bytes(_hx_len,self.b[pos:(pos + _hx_len)])

    def getString(self,pos,_hx_len,encoding = None):
        tmp = (encoding is None)
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        return self.b[pos:pos+_hx_len].decode('UTF-8','replace')

    def toString(self):
        return self.getString(0,self.length)

    @staticmethod
    def alloc(length):
        return haxe_io_Bytes(length,bytearray(length))

    @staticmethod
    def ofString(s,encoding = None):
        b = bytearray(s,"UTF-8")
        return haxe_io_Bytes(len(b),b)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.length = None
        _hx_o.b = None
haxe_io_Bytes._hx_class = haxe_io_Bytes


class haxe_ds_IntMap:
    _hx_class_name = "haxe.ds.IntMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def get(self,key):
        return self.h.get(key,None)

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_IntMap._hx_class = haxe_ds_IntMap


class haxe_ds_ObjectMap:
    _hx_class_name = "haxe.ds.ObjectMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def get(self,key):
        return self.h.get(key,None)

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_ObjectMap._hx_class = haxe_ds_ObjectMap


class haxe_ds_StringMap:
    _hx_class_name = "haxe.ds.StringMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def set(self,key,value):
        self.h[key] = value

    def get(self,key):
        return self.h.get(key,None)

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_StringMap._hx_class = haxe_ds_StringMap


class haxe_exceptions_PosException(haxe_Exception):
    _hx_class_name = "haxe.exceptions.PosException"
    __slots__ = ("posInfos",)
    _hx_fields = ["posInfos"]
    _hx_methods = ["toString"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,message,previous = None,pos = None):
        self.posInfos = None
        super().__init__(message,previous)
        if (pos is None):
            self.posInfos = _hx_AnonObject({'fileName': "(unknown)", 'lineNumber': 0, 'className': "(unknown)", 'methodName': "(unknown)"})
        else:
            self.posInfos = pos

    def toString(self):
        return ((((((((("" + HxOverrides.stringOrNull(super().toString())) + " in ") + HxOverrides.stringOrNull(self.posInfos.className)) + ".") + HxOverrides.stringOrNull(self.posInfos.methodName)) + " at ") + HxOverrides.stringOrNull(self.posInfos.fileName)) + ":") + Std.string(self.posInfos.lineNumber))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.posInfos = None
haxe_exceptions_PosException._hx_class = haxe_exceptions_PosException


class haxe_exceptions_NotImplementedException(haxe_exceptions_PosException):
    _hx_class_name = "haxe.exceptions.NotImplementedException"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_exceptions_PosException


    def __init__(self,message = None,previous = None,pos = None):
        if (message is None):
            message = "Not implemented"
        super().__init__(message,previous,pos)
haxe_exceptions_NotImplementedException._hx_class = haxe_exceptions_NotImplementedException


class haxe_format_JsonPrinter:
    _hx_class_name = "haxe.format.JsonPrinter"
    __slots__ = ("buf", "replacer", "indent", "pretty", "nind")
    _hx_fields = ["buf", "replacer", "indent", "pretty", "nind"]
    _hx_methods = ["write", "classString", "fieldsString", "quote"]
    _hx_statics = ["print"]

    def __init__(self,replacer,space):
        self.replacer = replacer
        self.indent = space
        self.pretty = (space is not None)
        self.nind = 0
        self.buf = StringBuf()

    def write(self,k,v):
        if (self.replacer is not None):
            v = self.replacer(k,v)
        _g = Type.typeof(v)
        tmp = _g.index
        if (tmp == 0):
            self.buf.b.write("null")
        elif (tmp == 1):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 2):
            f = v
            v1 = (Std.string(v) if ((((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))) else "null")
            _this = self.buf
            s = Std.string(v1)
            _this.b.write(s)
        elif (tmp == 3):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 4):
            self.fieldsString(v,python_Boot.fields(v))
        elif (tmp == 5):
            self.buf.b.write("\"<fun>\"")
        elif (tmp == 6):
            c = _g.params[0]
            if (c == str):
                self.quote(v)
            elif (c == list):
                v1 = v
                _this = self.buf
                s = "".join(map(chr,[91]))
                _this.b.write(s)
                _hx_len = len(v1)
                last = (_hx_len - 1)
                _g1 = 0
                _g2 = _hx_len
                while (_g1 < _g2):
                    i = _g1
                    _g1 = (_g1 + 1)
                    if (i > 0):
                        _this = self.buf
                        s = "".join(map(chr,[44]))
                        _this.b.write(s)
                    else:
                        _hx_local_0 = self
                        _hx_local_1 = _hx_local_0.nind
                        _hx_local_0.nind = (_hx_local_1 + 1)
                        _hx_local_1
                    if self.pretty:
                        _this1 = self.buf
                        s1 = "".join(map(chr,[10]))
                        _this1.b.write(s1)
                    if self.pretty:
                        v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                        _this2 = self.buf
                        s2 = Std.string(v2)
                        _this2.b.write(s2)
                    self.write(i,(v1[i] if i >= 0 and i < len(v1) else None))
                    if (i == last):
                        _hx_local_2 = self
                        _hx_local_3 = _hx_local_2.nind
                        _hx_local_2.nind = (_hx_local_3 - 1)
                        _hx_local_3
                        if self.pretty:
                            _this3 = self.buf
                            s3 = "".join(map(chr,[10]))
                            _this3.b.write(s3)
                        if self.pretty:
                            v3 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                            _this4 = self.buf
                            s4 = Std.string(v3)
                            _this4.b.write(s4)
                _this = self.buf
                s = "".join(map(chr,[93]))
                _this.b.write(s)
            elif (c == haxe_ds_StringMap):
                v1 = v
                o = _hx_AnonObject({})
                k = v1.keys()
                while k.hasNext():
                    k1 = k.next()
                    value = v1.h.get(k1,None)
                    setattr(o,(("_hx_" + k1) if ((k1 in python_Boot.keywords)) else (("_hx_" + k1) if (((((len(k1) > 2) and ((ord(k1[0]) == 95))) and ((ord(k1[1]) == 95))) and ((ord(k1[(len(k1) - 1)]) != 95)))) else k1)),value)
                v1 = o
                self.fieldsString(v1,python_Boot.fields(v1))
            elif (c == Date):
                v1 = v
                self.quote(v1.toString())
            else:
                self.classString(v)
        elif (tmp == 7):
            _g1 = _g.params[0]
            i = v.index
            _this = self.buf
            s = Std.string(i)
            _this.b.write(s)
        elif (tmp == 8):
            self.buf.b.write("\"???\"")
        else:
            pass

    def classString(self,v):
        self.fieldsString(v,python_Boot.getInstanceFields(Type.getClass(v)))

    def fieldsString(self,v,fields):
        _this = self.buf
        s = "".join(map(chr,[123]))
        _this.b.write(s)
        _hx_len = len(fields)
        last = (_hx_len - 1)
        first = True
        _g = 0
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            f = (fields[i] if i >= 0 and i < len(fields) else None)
            value = Reflect.field(v,f)
            if Reflect.isFunction(value):
                continue
            if first:
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.nind
                _hx_local_0.nind = (_hx_local_1 + 1)
                _hx_local_1
                first = False
            else:
                _this = self.buf
                s = "".join(map(chr,[44]))
                _this.b.write(s)
            if self.pretty:
                _this1 = self.buf
                s1 = "".join(map(chr,[10]))
                _this1.b.write(s1)
            if self.pretty:
                v1 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                _this2 = self.buf
                s2 = Std.string(v1)
                _this2.b.write(s2)
            self.quote(f)
            _this3 = self.buf
            s3 = "".join(map(chr,[58]))
            _this3.b.write(s3)
            if self.pretty:
                _this4 = self.buf
                s4 = "".join(map(chr,[32]))
                _this4.b.write(s4)
            self.write(f,value)
            if (i == last):
                _hx_local_2 = self
                _hx_local_3 = _hx_local_2.nind
                _hx_local_2.nind = (_hx_local_3 - 1)
                _hx_local_3
                if self.pretty:
                    _this5 = self.buf
                    s5 = "".join(map(chr,[10]))
                    _this5.b.write(s5)
                if self.pretty:
                    v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                    _this6 = self.buf
                    s6 = Std.string(v2)
                    _this6.b.write(s6)
        _this = self.buf
        s = "".join(map(chr,[125]))
        _this.b.write(s)

    def quote(self,s):
        _this = self.buf
        s1 = "".join(map(chr,[34]))
        _this.b.write(s1)
        i = 0
        length = len(s)
        while (i < length):
            index = i
            i = (i + 1)
            c = ord(s[index])
            c1 = c
            if (c1 == 8):
                self.buf.b.write("\\b")
            elif (c1 == 9):
                self.buf.b.write("\\t")
            elif (c1 == 10):
                self.buf.b.write("\\n")
            elif (c1 == 12):
                self.buf.b.write("\\f")
            elif (c1 == 13):
                self.buf.b.write("\\r")
            elif (c1 == 34):
                self.buf.b.write("\\\"")
            elif (c1 == 92):
                self.buf.b.write("\\\\")
            else:
                _this = self.buf
                s1 = "".join(map(chr,[c]))
                _this.b.write(s1)
        _this = self.buf
        s = "".join(map(chr,[34]))
        _this.b.write(s)

    @staticmethod
    def print(o,replacer = None,space = None):
        printer = haxe_format_JsonPrinter(replacer,space)
        printer.write("",o)
        return printer.buf.b.getvalue()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buf = None
        _hx_o.replacer = None
        _hx_o.indent = None
        _hx_o.pretty = None
        _hx_o.nind = None
haxe_format_JsonPrinter._hx_class = haxe_format_JsonPrinter


class haxe_http_HttpBase:
    _hx_class_name = "haxe.http.HttpBase"
    _hx_fields = ["url", "responseBytes", "responseAsString", "postData", "postBytes", "headers", "params", "emptyOnData"]
    _hx_methods = ["addHeader", "setPostData", "onData", "onBytes", "onError", "onStatus", "hasOnData", "success", "get_responseData"]

    def __init__(self,url):
        self.emptyOnData = None
        self.postBytes = None
        self.postData = None
        self.responseAsString = None
        self.responseBytes = None
        self.url = url
        self.headers = []
        self.params = []
        self.emptyOnData = self.onData

    def addHeader(self,header,value):
        _this = self.headers
        _this.append(_hx_AnonObject({'name': header, 'value': value}))

    def setPostData(self,data):
        self.postData = data
        self.postBytes = None

    def onData(self,data):
        pass

    def onBytes(self,data):
        pass

    def onError(self,msg):
        pass

    def onStatus(self,status):
        pass

    def hasOnData(self):
        return (not Reflect.compareMethods(self.onData,self.emptyOnData))

    def success(self,data):
        self.responseBytes = data
        self.responseAsString = None
        if self.hasOnData():
            self.onData(self.get_responseData())
        self.onBytes(self.responseBytes)

    def get_responseData(self):
        if ((self.responseAsString is None) and ((self.responseBytes is not None))):
            self.responseAsString = self.responseBytes.getString(0,self.responseBytes.length,haxe_io_Encoding.UTF8)
        return self.responseAsString

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.url = None
        _hx_o.responseBytes = None
        _hx_o.responseAsString = None
        _hx_o.postData = None
        _hx_o.postBytes = None
        _hx_o.headers = None
        _hx_o.params = None
        _hx_o.emptyOnData = None
haxe_http_HttpBase._hx_class = haxe_http_HttpBase


class haxe_io_BytesBuffer:
    _hx_class_name = "haxe.io.BytesBuffer"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["getBytes"]

    def __init__(self):
        self.b = bytearray()

    def getBytes(self):
        _hx_bytes = haxe_io_Bytes(len(self.b),self.b)
        self.b = None
        return _hx_bytes

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
haxe_io_BytesBuffer._hx_class = haxe_io_BytesBuffer


class haxe_io_Output:
    _hx_class_name = "haxe.io.Output"
    __slots__ = ("bigEndian",)
    _hx_fields = ["bigEndian"]
    _hx_methods = ["writeByte", "writeBytes", "close", "set_bigEndian", "writeFullBytes", "prepare", "writeString"]

    def writeByte(self,c):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Output.hx", 'lineNumber': 47, 'className': "haxe.io.Output", 'methodName': "writeByte"}))

    def writeBytes(self,s,pos,_hx_len):
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        b = s.b
        k = _hx_len
        while (k > 0):
            self.writeByte(b[pos])
            pos = (pos + 1)
            k = (k - 1)
        return _hx_len

    def close(self):
        pass

    def set_bigEndian(self,b):
        self.bigEndian = b
        return b

    def writeFullBytes(self,s,pos,_hx_len):
        while (_hx_len > 0):
            k = self.writeBytes(s,pos,_hx_len)
            pos = (pos + k)
            _hx_len = (_hx_len - k)

    def prepare(self,nbytes):
        pass

    def writeString(self,s,encoding = None):
        b = haxe_io_Bytes.ofString(s,encoding)
        self.writeFullBytes(b,0,b.length)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bigEndian = None
haxe_io_Output._hx_class = haxe_io_Output


class haxe_io_BytesOutput(haxe_io_Output):
    _hx_class_name = "haxe.io.BytesOutput"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["writeByte", "writeBytes", "getBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self):
        self.b = haxe_io_BytesBuffer()
        self.set_bigEndian(False)

    def writeByte(self,c):
        self.b.b.append(c)

    def writeBytes(self,buf,pos,_hx_len):
        _this = self.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > buf.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        _this.b.extend(buf.b[pos:(pos + _hx_len)])
        return _hx_len

    def getBytes(self):
        return self.b.getBytes()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
haxe_io_BytesOutput._hx_class = haxe_io_BytesOutput

class haxe_io_Encoding(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Encoding"
    _hx_constructs = ["UTF8", "RawNative"]
haxe_io_Encoding.UTF8 = haxe_io_Encoding("UTF8", 0, ())
haxe_io_Encoding.RawNative = haxe_io_Encoding("RawNative", 1, ())
haxe_io_Encoding._hx_class = haxe_io_Encoding


class haxe_io_Eof:
    _hx_class_name = "haxe.io.Eof"
    __slots__ = ()
    _hx_methods = ["toString"]

    def __init__(self):
        pass

    def toString(self):
        return "Eof"

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_io_Eof._hx_class = haxe_io_Eof

class haxe_io_Error(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Error"
    _hx_constructs = ["Blocked", "Overflow", "OutsideBounds", "Custom"]

    @staticmethod
    def Custom(e):
        return haxe_io_Error("Custom", 3, (e,))
haxe_io_Error.Blocked = haxe_io_Error("Blocked", 0, ())
haxe_io_Error.Overflow = haxe_io_Error("Overflow", 1, ())
haxe_io_Error.OutsideBounds = haxe_io_Error("OutsideBounds", 2, ())
haxe_io_Error._hx_class = haxe_io_Error


class haxe_io_Input:
    _hx_class_name = "haxe.io.Input"
    __slots__ = ()
    _hx_methods = ["readByte", "readBytes"]

    def readByte(self):
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Input.hx", 'lineNumber': 53, 'className': "haxe.io.Input", 'methodName': "readByte"}))

    def readBytes(self,s,pos,_hx_len):
        k = _hx_len
        b = s.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        try:
            while (k > 0):
                b[pos] = self.readByte()
                pos = (pos + 1)
                k = (k - 1)
        except BaseException as _g:
            None
            if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                raise _g
        return (_hx_len - k)

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_io_Input._hx_class = haxe_io_Input


class haxe_iterators_ArrayIterator:
    _hx_class_name = "haxe.iterators.ArrayIterator"
    __slots__ = ("array", "current")
    _hx_fields = ["array", "current"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return python_internal_ArrayImpl._get(self.array, _hx_local_2())
        return _hx_local_3()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.array = None
        _hx_o.current = None
haxe_iterators_ArrayIterator._hx_class = haxe_iterators_ArrayIterator


class haxe_iterators_ArrayKeyValueIterator:
    _hx_class_name = "haxe.iterators.ArrayKeyValueIterator"
    __slots__ = ("current", "array")
    _hx_fields = ["current", "array"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return _hx_AnonObject({'value': python_internal_ArrayImpl._get(self.array, self.current), 'key': _hx_local_2()})
        return _hx_local_3()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.current = None
        _hx_o.array = None
haxe_iterators_ArrayKeyValueIterator._hx_class = haxe_iterators_ArrayKeyValueIterator


class host_App:
    _hx_class_name = "host.App"
    __slots__ = ()
    _hx_statics = ["__meta__", "gradio_components", "gradio_dependencies", "init", "getDocumentState", "setDocumentState", "setLayerName", "docker"]
    _hx_interfaces = [hxasync_Asyncable]
    docker = None

    @staticmethod
    def init(v):
        host_App.docker = v
        req = sys_Http("http://localhost.tech:7860/")
        def _hx_local_15(data_out):
            _this = HxOverrides.arrayGet(data_out.split("<script>window.gradio_config = "), 1)
            gradio_props = python_lib_Json.loads(python_internal_ArrayImpl._get(_this.split(";</script>"), 0),**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
            host_App.gradio_components = Reflect.field(gradio_props,"components")
            def _hx_local_0(a,b):
                x = (Reflect.field(a,"id") - Reflect.field(b,"id"))
                try:
                    return int(x)
                except BaseException as _g:
                    None
                    return None
            host_App.gradio_components.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
            _g = 0
            _g1 = host_App.gradio_components
            while (_g < len(_g1)):
                component = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                comp = component
                props = Reflect.field(comp,"props")
                if (Reflect.field(props,"elem_id") == "txt2img_generate"):
                    host_UI.txt2img_generate_fn_index = Reflect.field(comp,"id")
            dep = None
            dependencies = Reflect.field(gradio_props,"dependencies")
            _g = 0
            _g1 = len(dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                dep = (dependencies[i] if i >= 0 and i < len(dependencies) else None)
                if (HxOverrides.arrayGet(Reflect.field(dep,"targets"), 0) == host_UI.txt2img_generate_fn_index):
                    host_UI.txt2img_data_inputs = Reflect.field(dep,"inputs")
                    host_UI.txt2img_data_outputs = Reflect.field(dep,"outputs")
                    host_UI.txt2img_generate_fn_index = i
                    break
            _g = 0
            _g1 = host_UI.txt2img_data_inputs
            while (_g < len(_g1)):
                id = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                _this = host_UI.tags.h.get("txt2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_4(id):
                    def _hx_local_3(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_3
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_4(id),_this1)), 0)
                _this.append(x)
            _g = 0
            _g1 = host_UI.txt2img_data_outputs
            while (_g < len(_g1)):
                id1 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                _this = host_UI.tags.h.get("txt2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_7(id):
                    def _hx_local_6(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_6
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_7(id1),_this1)), 0)
                _this.append(x)
            print(str(host_UI.tags.h.get("txt2img",None)))
            _g = 0
            _g1 = host_App.gradio_components
            while (_g < len(_g1)):
                component = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                comp = component
                props = Reflect.field(comp,"props")
                if (Reflect.field(props,"elem_id") == "img2img_generate"):
                    host_UI.img2img_generate_fn_index = Reflect.field(comp,"id")
                    print(str(comp))
            dep = None
            host_App.gradio_dependencies = Reflect.field(gradio_props,"dependencies")
            _g = 0
            _g1 = len(host_App.gradio_dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                dep = python_internal_ArrayImpl._get(host_App.gradio_dependencies, i)
                if (HxOverrides.arrayGet(Reflect.field(dep,"targets"), 0) == host_UI.img2img_generate_fn_index):
                    host_UI.img2img_data_inputs = Reflect.field(dep,"inputs")
                    host_UI.img2img_data_outputs = Reflect.field(dep,"outputs")
                    host_UI.img2img_generate_fn_index = i
                    break
            _g = 0
            _g1 = host_UI.img2img_data_inputs
            while (_g < len(_g1)):
                id2 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                _this = host_UI.tags.h.get("img2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_11(id):
                    def _hx_local_10(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_10
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_11(id2),_this1)), 0)
                _this.append(x)
            _g = 0
            _g1 = host_UI.img2img_data_outputs
            while (_g < len(_g1)):
                id3 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                _this = host_UI.tags.h.get("img2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_14(id):
                    def _hx_local_13(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_13
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_14(id3),_this1)), 0)
                _this.append(x)
            print(str(host_UI.tags.h.get("img2img",None)))
            host_UI.createInterface()
        req.onData = _hx_local_15
        req.request(False)
        v.setWindowTitle("Defuser")

    @staticmethod
    def getDocumentState():
        d = Krita.instance().activeDocument()
        if (d is None):
            print("returning 3none")
            state = _hx_AnonObject({'document': None, 'layer': None, 'selection': None})
            return state
        n = d.activeNode()
        layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
        s = d.selection()
        selection = None
        if (s is not None):
            selection = _hx_AnonObject({'x': s.x(), 'y': s.y(), 'width': s.width(), 'height': s.height()})
        state = _hx_AnonObject({'document': d, 'layer': layer, 'selection': selection})
        return state

    @staticmethod
    def setDocumentState(state):
        s = Selection()
        s.select(Reflect.field(state,"selection").x,Reflect.field(state,"selection").y,Reflect.field(state,"selection").width,Reflect.field(state,"selection").height,255)
        Krita.instance().activeDocument().setSelection(s)

    @staticmethod
    def setLayerName(layer,layer_name):
        layer._internal.setName(layer_name)
host_App._hx_class = host_App


class host__Docker_Docker_Fields_:
    _hx_class_name = "host._Docker.Docker_Fields_"
    __slots__ = ()
    _hx_statics = ["myDocker"]
    myDocker = None
host__Docker_Docker_Fields_._hx_class = host__Docker_Docker_Fields_


class host_Image:
    _hx_class_name = "host.Image"
    __slots__ = ()
    _hx_statics = ["layerByName", "pngFromSelection", "layerFromPng"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def layerByName(name):
        n = Krita.instance().activeDocument().nodeByName(name)
        if (n is not None):
            layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
            return layer
        else:
            return None

    @staticmethod
    def pngFromSelection(s,layer = None):
        d = Krita.instance().activeDocument()
        d.refreshProjection()
        pixel_data = None
        if (layer is not None):
            n = Krita.instance().activeDocument().nodeByName(layer.name)
            pixel_data = n.pixelData(s.x,s.y,s.width,s.height)
        else:
            pixel_data = d.pixelData(s.x,s.y,s.width,s.height)
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import base64
        image = QImage(pixel_data.data(),s.width,s.height,QImage.Format_RGBA8888).rgbSwapped()
        data = QByteArray()
        buf = QBuffer(data)
        image.save(buf, "PNG")
        return data

    @staticmethod
    def layerFromPng(_hx_bytes,layer_name = None):
        if (layer_name is None):
            layer_name = "SD"
        
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import json
        imagen = QImage()
        imagen.loadFromData(_hx_bytes, "PNG" )
        ptr = imagen.bits()
        ptr.setsize(imagen.byteCount())
        d= Krita.instance().activeDocument()
        root = d.rootNode()
        n = d.createNode(layer_name, "paintLayer")
        s = d.selection()
        root.addChildNode(n, None)

        size = imagen.rect()
        #write pixels and refresh 
        #TODO clean this up a little for async receive. might be possible that s = None
        n.setPixelData(QByteArray(ptr.asstring()),s.x(),s.y(),size.width(),size.height())
        d.waitForDone()
        
        
        d = Krita.instance().activeDocument()
        d.refreshProjection()
host_Image._hx_class = host_Image


class host_UI:
    _hx_class_name = "host.UI"
    __slots__ = ()
    _hx_statics = ["__meta__", "txt2img_generate_fn_index", "txt2img_data_inputs", "txt2img_data_outputs", "img2img_generate_fn_index", "img2img_data_inputs", "img2img_data_outputs", "is_inpainting", "tags", "uitop", "createInterface", "makeTab", "asyncfetch", "makeComponent", "toast", "setParameter", "gatherParameter", "insertValue", "extractValue", "gatherSpecialParameter"]
    _hx_interfaces = [hxasync_Asyncable]
    uitop = None

    @staticmethod
    def createInterface():
        cloner = cloner_Cloner()
        tabWidget = QTabWidget()
        host_UI.uitop = tabWidget
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(tabWidget)
        widget.setLayout(layout)
        host_App.docker.setWidget(widget)
        host_UI.makeTab("txt2img")
        host_UI.makeTab("img2img")
        _g = 0
        _g1 = host_UI.tags.h.get("img2img",None)
        while (_g < len(_g1)):
            tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = host_UI.tags.h.get("inpaint",None)
            x = Reflect.copy(tag)
            _this.append(x)
        _g = 0
        _g1 = host_UI.tags.h.get("img2img",None)
        while (_g < len(_g1)):
            tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            _this = host_UI.tags.h.get("outpainting_mk2",None)
            x = Reflect.copy(tag)
            _this.append(x)
        host_UI.makeTab("inpaint")
        host_UI.makeTab("outpainting_mk2")

    @staticmethod
    def makeTab(mode):
        tab = QWidget()
        layout_inner = QVBoxLayout()
        headerlayout = QHBoxLayout()
        btn_recycle = QPushButton("♻️")
        btn_recycle.setMaximumWidth(64)
        def _hx_local_0(_hx_bool):
            host_UI.asyncfetch(host_UI.tags.h.get(mode,None))
        f_recycle = _hx_local_0
        btn_recycle.clicked.connect(f_recycle)
        headerlayout.addWidget(btn_recycle)
        btn_run = QPushButton("Generate")
        btn_run.setStyleSheet("background-color: rgb(255, 153, 28); color: black; font: 14px;")
        def _hx_local_1(_hx_bool):
            host_App.docker.generate2(mode,host_UI.tags.h.get(mode,None))
        f = _hx_local_1
        btn_run.clicked.connect(f)
        headerlayout.addWidget(btn_run)
        layout_inner.addLayout(headerlayout)
        tabform = QWidget()
        formlayout = QVBoxLayout()
        Utils.cleanTags(host_UI.tags.h.get(mode,None))
        _g = 0
        _g1 = host_UI.tags.h.get(mode,None)
        while (_g < len(_g1)):
            comp = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            widget = host_UI.makeComponent(comp,mode)
            formlayout.addWidget(widget)
        tabform.setLayout(formlayout)
        scroll = QScrollArea()
        scroll.setWidget(tabform)
        scroll.setWidgetResizable(True)
        layout_inner.addWidget(scroll)
        tab.setLayout(layout_inner)
        host_UI.uitop.addTab(tab,mode)
        if (mode == "outpainting_mk2"):
            scriptcomponent = None
            temp_props = None
            _g = 0
            _g1 = host_UI.tags.h.get("outpainting_mk2",None)
            while (_g < len(_g1)):
                tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                temp_props = Reflect.field(tag,"props")
                if (Reflect.field(temp_props,"param_name") == "script"):
                    scriptcomponent = tag
            print(str(scriptcomponent))
            Reflect.field(scriptcomponent,"setter")("Outpainting mk2")
            scriptdep = None
            fni = None
            _g = 0
            _g1 = len(host_App.gradio_dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                if (HxOverrides.arrayGet(Reflect.field(python_internal_ArrayImpl._get(host_App.gradio_dependencies, i),"targets"), 0) == Reflect.field(scriptcomponent,"id")):
                    fni = i
            print(str(("Script dropdown fnid: " + Std.string(fni))))
            outputs = Reflect.field(python_internal_ArrayImpl._get(host_App.gradio_dependencies, fni),"outputs")
            req = sys_Http((HxOverrides.stringOrNull(_Defs_Defs_Fields_.baseurl) + "/api/predict"))
            req.addHeader("Content-Type","application/json")
            post_data = haxe_format_JsonPrinter.print(_hx_AnonObject({'fn_index': fni, 'data': ["Outpainting mk2"], 'session_hash': None}),None,None)
            print(str(post_data))
            req.setPostData(post_data)
            def _hx_local_5(data_out):
                vismap = []
                props = None
                _g = 0
                _g1 = host_UI.tags.h.get("outpainting_mk2",None)
                while (_g < len(_g1)):
                    comp = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                    _g = (_g + 1)
                    if (Reflect.field(comp,"id") in outputs):
                        vismap.append(comp)
                print(str(len(vismap)))
                jdata = python_lib_Json.loads(data_out,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
                data = Reflect.field(jdata,"data")
                print(str(len(data)))
                tag_props = None
                _g = 0
                _g1 = len(data)
                while (_g < _g1):
                    i = _g
                    _g = (_g + 1)
                    tag_props = Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"props")
                    value = Reflect.field((data[i] if i >= 0 and i < len(data) else None),"visible")
                    setattr(tag_props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),value)
                    if (Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container") is not None):
                        if (Reflect.field((data[i] if i >= 0 and i < len(data) else None),"visible") and (not Reflect.field(tag_props,"forcehidden"))):
                            Reflect.field(Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container"),"setVisible")(True)
                        else:
                            Reflect.field(Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container"),"setVisible")(False)
            req.onData = _hx_local_5
            def _hx_local_6(status):
                print(str(status))
            req.onStatus = _hx_local_6
            req.request(True)

    @staticmethod
    def asyncfetch(components):
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        if (layer is None):
            host_UI.toast("Please select a layer to fetch from")
        else:
            Utils.fetchAndInsert(layer,components)

    @staticmethod
    def makeComponent(component,mode):
        itype = Reflect.field(component,"type")
        props = Reflect.field(component,"props")
        param_name = Reflect.field(props,"param_name")
        groupbox = QGroupBox(Std.string(param_name))
        hbox = QHBoxLayout()
        groupbox.setLayout(hbox)
        if (param_name == "extra"):
            setattr(props,(("_hx_" + "value") if (("value" in python_Boot.keywords)) else (("_hx_" + "value") if (((((len("value") > 2) and ((ord("value"[0]) == 95))) and ((ord("value"[1]) == 95))) and ((ord("value"[(len("value") - 1)]) != 95)))) else "value")),True)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        if (param_name == "resize_mode"):
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        if (((((param_name == "mask_blur") or ((param_name == "masked_content"))) or ((param_name == "masking_mode"))) or ((param_name == "inpaint_at_full_resolution"))) or ((param_name == "inpaint_at_full_resolution_padding,_pixels"))):
            if (mode != "inpaint"):
                setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
            else:
                setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),True)
        if (param_name == "mask_mode"):
            value = ["Upload mask"]
            setattr(props,(("_hx_" + "choices") if (("choices" in python_Boot.keywords)) else (("_hx_" + "choices") if (((((len("choices") > 2) and ((ord("choices"[0]) == 95))) and ((ord("choices"[1]) == 95))) and ((ord("choices"[(len("choices") - 1)]) != 95)))) else "choices")),value)
            setattr(props,(("_hx_" + "value") if (("value" in python_Boot.keywords)) else (("_hx_" + "value") if (((((len("value") > 2) and ((ord("value"[0]) == 95))) and ((ord("value"[1]) == 95))) and ((ord("value"[(len("value") - 1)]) != 95)))) else "value")),"Upload mask")
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        if ((param_name == "input_directory") or ((param_name == "output_directory"))):
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        if (param_name == "height"):
            def _hx_local_0():
                return host_UI.gatherSpecialParameter("height")
            getter = _hx_local_0
            value = getter
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (param_name == "width"):
            def _hx_local_1():
                return host_UI.gatherSpecialParameter("width")
            getter1 = _hx_local_1
            value = getter1
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "image"):
            def _hx_local_2():
                return host_UI.gatherSpecialParameter(Reflect.field(props,"elem_id"))
            getter2 = _hx_local_2
            value = getter2
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "label"):
            def _hx_local_3():
                return host_UI.is_inpainting
            getter3 = _hx_local_3
            value = getter3
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif ((itype == "file") or ((itype == "html"))):
            setattr(props,(("_hx_" + "forcehidden") if (("forcehidden" in python_Boot.keywords)) else (("_hx_" + "forcehidden") if (((((len("forcehidden") > 2) and ((ord("forcehidden"[0]) == 95))) and ((ord("forcehidden"[1]) == 95))) and ((ord("forcehidden"[(len("forcehidden") - 1)]) != 95)))) else "forcehidden")),True)
            def _hx_local_4():
                return None
            getter4 = _hx_local_4
            value = getter4
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif ((itype == "gallery") or ((itype == "html"))):
            def _hx_local_5():
                return ""
            getter5 = _hx_local_5
            value = getter5
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "textbox"):
            input = QPlainTextEdit(Reflect.field(props,"value"))
            hbox.addWidget(input)
            def _hx_local_6():
                return input.toPlainText()
            getter6 = _hx_local_6
            def _hx_local_7(val):
                input.setPlainText(val)
            setter = _hx_local_7
            value = getter6
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            value = setter
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif ((itype == "dropdown") or ((itype == "radio"))):
            input1 = QComboBox()
            input1.addItems(Reflect.field(props,"choices"))
            hbox.addWidget(input1)
            def _hx_local_8():
                return input1.currentText()
            getter7 = _hx_local_8
            def _hx_local_9(val):
                input1.setCurrentText(val)
            setter1 = _hx_local_9
            value = getter7
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            value = setter1
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
            if (param_name == "script"):
                input1.setDisabled(True)
        elif (itype == "slider"):
            try:
                _hx_local_10 = Reflect.field(props,"step")
                if (Std.isOfType(_hx_local_10,Int) or ((_hx_local_10 is None))):
                    _hx_local_10
                else:
                    raise "Class cast error"
                _hx_local_10
            except BaseException as _g:
                input2 = QDoubleSpinBox()
                def _hx_local_12():
                    _hx_local_11 = Reflect.field(props,"minimum")
                    if (Std.isOfType(_hx_local_11,Float) or ((_hx_local_11 is None))):
                        _hx_local_11
                    else:
                        raise "Class cast error"
                    return _hx_local_11
                input2.setMinimum(_hx_local_12())
                def _hx_local_14():
                    _hx_local_13 = Reflect.field(props,"maximum")
                    if (Std.isOfType(_hx_local_13,Float) or ((_hx_local_13 is None))):
                        _hx_local_13
                    else:
                        raise "Class cast error"
                    return _hx_local_13
                input2.setMaximum(_hx_local_14())
                def _hx_local_16():
                    _hx_local_15 = Reflect.field(props,"step")
                    if (Std.isOfType(_hx_local_15,Float) or ((_hx_local_15 is None))):
                        _hx_local_15
                    else:
                        raise "Class cast error"
                    return _hx_local_15
                input2.setSingleStep(_hx_local_16())
                def _hx_local_18():
                    _hx_local_17 = Reflect.field(props,"value")
                    if (Std.isOfType(_hx_local_17,Float) or ((_hx_local_17 is None))):
                        _hx_local_17
                    else:
                        raise "Class cast error"
                    return _hx_local_17
                input2.setValue(_hx_local_18())
                hbox.addWidget(input2)
                def _hx_local_19():
                    return input2.value()
                getter8 = _hx_local_19
                def _hx_local_20(val):
                    input2.setValue(val)
                setter2 = _hx_local_20
                value = getter8
                setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
                value = setter2
                setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
                return groupbox
            input3 = QSpinBox()
            def _hx_local_22():
                _hx_local_21 = Reflect.field(props,"minimum")
                if (Std.isOfType(_hx_local_21,Int) or ((_hx_local_21 is None))):
                    _hx_local_21
                else:
                    raise "Class cast error"
                return _hx_local_21
            input3.setMinimum(_hx_local_22())
            def _hx_local_24():
                _hx_local_23 = Reflect.field(props,"maximum")
                if (Std.isOfType(_hx_local_23,Int) or ((_hx_local_23 is None))):
                    _hx_local_23
                else:
                    raise "Class cast error"
                return _hx_local_23
            input3.setMaximum(_hx_local_24())
            def _hx_local_26():
                _hx_local_25 = Reflect.field(props,"step")
                if (Std.isOfType(_hx_local_25,Int) or ((_hx_local_25 is None))):
                    _hx_local_25
                else:
                    raise "Class cast error"
                return _hx_local_25
            input3.setSingleStep(_hx_local_26())
            def _hx_local_28():
                _hx_local_27 = Reflect.field(props,"value")
                if (Std.isOfType(_hx_local_27,Int) or ((_hx_local_27 is None))):
                    _hx_local_27
                else:
                    raise "Class cast error"
                return _hx_local_27
            input3.setValue(_hx_local_28())
            hbox.addWidget(input3)
            def _hx_local_29():
                return input3.value()
            getter9 = _hx_local_29
            def _hx_local_30(val):
                input3.setValue(val)
            setter3 = _hx_local_30
            value = getter9
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            value = setter3
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif (itype == "checkbox"):
            input4 = QCheckBox()
            def _hx_local_32():
                _hx_local_31 = Reflect.field(props,"value")
                if (Std.isOfType(_hx_local_31,Bool) or ((_hx_local_31 is None))):
                    _hx_local_31
                else:
                    raise "Class cast error"
                return _hx_local_31
            input4.setChecked(_hx_local_32())
            hbox.addWidget(input4)
            def _hx_local_33():
                return input4.isChecked()
            getter10 = _hx_local_33
            def _hx_local_34(val):
                if val:
                    input4.setCheckState(Qt.Checked)
                else:
                    input4.setCheckState(Qt.Unchecked)
            setter4 = _hx_local_34
            value = getter10
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            value = setter4
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif (itype == "number"):
            input5 = QLineEdit()
            input5.setText("-1")
            hbox.addWidget(input5)
            def _hx_local_35():
                return input5.text()
            getter11 = _hx_local_35
            def _hx_local_36(val):
                input5.setText(Std.string(val))
            setter5 = _hx_local_36
            value = getter11
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            value = setter5
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
            reset = QPushButton("🎲")
            def _hx_local_37(_hx_bool):
                Reflect.field(component,"setter")(-1)
            reset.clicked.connect(_hx_local_37)
            hbox.addWidget(reset)
            keep = QPushButton("♻️")
            def _hx_local_38(_hx_bool):
                if (Reflect.field(host_App.getDocumentState(),"layer") is None):
                    host_UI.toast("No Layer selected?")
                    return
                else:
                    Utils.fetchAndInsert(Reflect.field(host_App.getDocumentState(),"layer"),[component])
            f_rec = _hx_local_38
            keep.clicked.connect(f_rec)
            hbox.addWidget(keep)
        elif (itype == "checkboxgroup"):
            choices = Reflect.field(props,"choices")
            checks = []
            _g = 0
            while (_g < len(choices)):
                name = (choices[_g] if _g >= 0 and _g < len(choices) else None)
                _g = (_g + 1)
                chk = QCheckBox(name)
                chk.setChecked(True)
                hbox.addWidget(chk)
                checks.append(chk)
            def _hx_local_40():
                toggledopts = []
                _g = 0
                _g1 = len(choices)
                while (_g < _g1):
                    i = _g
                    _g = (_g + 1)
                    if (checks[i] if i >= 0 and i < len(checks) else None).isChecked():
                        toggledopts.append((choices[i] if i >= 0 and i < len(choices) else None))
                return toggledopts
            getter12 = _hx_local_40
            value = getter12
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
        tmp = None
        if (Reflect.field(props,"visible") != False):
            _this = host_UI.txt2img_data_outputs
            tmp = (Reflect.field(component,"id") in _this)
        else:
            tmp = True
        if tmp:
            groupbox.setVisible(False)
        setattr(component,(("_hx_" + "container") if (("container" in python_Boot.keywords)) else (("_hx_" + "container") if (((((len("container") > 2) and ((ord("container"[0]) == 95))) and ((ord("container"[1]) == 95))) and ((ord("container"[(len("container") - 1)]) != 95)))) else "container")),groupbox)
        if (mode == "inpaint"):
            print(str(param_name))
            print(("visible: " + Std.string(Reflect.field(props,"visible"))))
        return groupbox

    @staticmethod
    def toast(msg):
        Krita.instance().activeWindow().activeView().showFloatingMessage(("" + Std.string(msg)),QIcon(),2000,1)

    @staticmethod
    def setParameter(param_name,value):
        tab = host_UI.uitop.currentWidget()
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                def _hx_local_4():
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                host_UI.insertValue(_hx_local_4(),value)

    @staticmethod
    def gatherParameter(param_name):
        tab = host_UI.uitop.currentWidget()
        param = None
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                def _hx_local_4():
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                param = host_UI.extractValue(_hx_local_4())
        if (param is None):
            param = host_UI.gatherSpecialParameter(param_name)
        if (param is None):
            print("\nerror in gatherParameter")
            print(str(param_name))
        return param

    @staticmethod
    def insertValue(groupBox,value):
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        winfo = this1.h.get(key,None)
        itype = winfo.inputtype
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = widget
                if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            (_hx_local_2()).setPlainText(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_5():
                _hx_local_4 = widget
                if (Std.isOfType(_hx_local_4,QSpinBox) or ((_hx_local_4 is None))):
                    _hx_local_4
                else:
                    raise "Class cast error"
                return _hx_local_4
            (_hx_local_5()).setValue(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_8():
                _hx_local_7 = widget
                if (Std.isOfType(_hx_local_7,QDoubleSpinBox) or ((_hx_local_7 is None))):
                    _hx_local_7
                else:
                    raise "Class cast error"
                return _hx_local_7
            (_hx_local_8()).setValue(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_11():
                _hx_local_10 = widget
                if (Std.isOfType(_hx_local_10,QComboBox) or ((_hx_local_10 is None))):
                    _hx_local_10
                else:
                    raise "Class cast error"
                return _hx_local_10
            (_hx_local_11()).setCurrentText(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_14():
                _hx_local_13 = widget
                if (Std.isOfType(_hx_local_13,QLineEdit) or ((_hx_local_13 is None))):
                    _hx_local_13
                else:
                    raise "Class cast error"
                return _hx_local_13
            (_hx_local_14()).setText(Std.string(value))
            return
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            return
        else:
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if value:
                    def _hx_local_17():
                        _hx_local_16 = widget
                        if (Std.isOfType(_hx_local_16,QCheckBox) or ((_hx_local_16 is None))):
                            _hx_local_16
                        else:
                            raise "Class cast error"
                        return _hx_local_16
                    (_hx_local_17()).setCheckState(Qt.Checked)
                else:
                    def _hx_local_19():
                        _hx_local_18 = widget
                        if (Std.isOfType(_hx_local_18,QCheckBox) or ((_hx_local_18 is None))):
                            _hx_local_18
                        else:
                            raise "Class cast error"
                        return _hx_local_18
                    (_hx_local_19()).setCheckState(Qt.Unchecked)
                return

    @staticmethod
    def extractValue(groupBox):
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        widgetinfo = this1.h.get(key,None)
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_3():
                def _hx_local_2():
                    _hx_local_1 = widget
                    if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                        _hx_local_1
                    else:
                        raise "Class cast error"
                    return _hx_local_1
                return (_hx_local_2()).toPlainText()
            return _hx_local_3()
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_7():
                def _hx_local_6():
                    _hx_local_5 = widget
                    if (Std.isOfType(_hx_local_5,QSpinBox) or ((_hx_local_5 is None))):
                        _hx_local_5
                    else:
                        raise "Class cast error"
                    return _hx_local_5
                return (_hx_local_6()).value()
            return _hx_local_7()
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_11():
                def _hx_local_10():
                    _hx_local_9 = widget
                    if (Std.isOfType(_hx_local_9,QDoubleSpinBox) or ((_hx_local_9 is None))):
                        _hx_local_9
                    else:
                        raise "Class cast error"
                    return _hx_local_9
                return (_hx_local_10()).value()
            return _hx_local_11()
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_15():
                def _hx_local_14():
                    _hx_local_13 = widget
                    if (Std.isOfType(_hx_local_13,QComboBox) or ((_hx_local_13 is None))):
                        _hx_local_13
                    else:
                        raise "Class cast error"
                    return _hx_local_13
                return (_hx_local_14()).currentText()
            return _hx_local_15()
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            checklist = []
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                def _hx_local_18():
                    _hx_local_17 = widget
                    if (Std.isOfType(_hx_local_17,QCheckBox) or ((_hx_local_17 is None))):
                        _hx_local_17
                    else:
                        raise "Class cast error"
                    return _hx_local_17
                if (_hx_local_18()).isChecked():
                    def _hx_local_20():
                        _hx_local_19 = widget
                        if (Std.isOfType(_hx_local_19,QCheckBox) or ((_hx_local_19 is None))):
                            _hx_local_19
                        else:
                            raise "Class cast error"
                        return _hx_local_19
                    x = (_hx_local_20()).text()
                    checklist.append(x)
            return checklist
        else:
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                def _hx_local_24():
                    def _hx_local_23():
                        _hx_local_22 = widget
                        if (Std.isOfType(_hx_local_22,QCheckBox) or ((_hx_local_22 is None))):
                            _hx_local_22
                        else:
                            raise "Class cast error"
                        return _hx_local_22
                    return (_hx_local_23()).isChecked()
                return _hx_local_24()
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if ((groupBox.title() == "seed") or ((groupBox.title() == "subseed"))):
                def _hx_local_28():
                    def _hx_local_27():
                        _hx_local_26 = widget
                        if (Std.isOfType(_hx_local_26,QLineEdit) or ((_hx_local_26 is None))):
                            _hx_local_26
                        else:
                            raise "Class cast error"
                        return _hx_local_26
                    return Std.parseInt((_hx_local_27()).text())
                return _hx_local_28()
            else:
                def _hx_local_31():
                    def _hx_local_30():
                        _hx_local_29 = widget
                        if (Std.isOfType(_hx_local_29,QLineEdit) or ((_hx_local_29 is None))):
                            _hx_local_29
                        else:
                            raise "Class cast error"
                        return _hx_local_29
                    return (_hx_local_30()).text()
                return _hx_local_31()
        return None

    @staticmethod
    def gatherSpecialParameter(param_name):
        print(str(("gathering special parameter: " + ("null" if param_name is None else param_name))))
        state = host_App.getDocumentState()
        s = Krita.instance().activeDocument().selection()
        if (((param_name == "img2img_image") and ((host_UI.is_inpainting == 0))) or (((param_name == "img_inpaint_base") and ((host_UI.is_inpainting == 1))))):
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            if (mask is not None):
                mask.setVisible(False)
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"))
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            return base64string
        if (param_name == "img2maskimg"):
            return None
        if ((param_name == "img_inpaint_mask") and ((host_UI.is_inpainting == 1))):
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            mask.setVisible(True)
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"),Reflect.field(state,"layer"))
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            return base64string
        if (param_name == "width"):
            return s.width()
        if (param_name == "height"):
            print("getting height special")
            return s.height()
        return None
host_UI._hx_class = host_UI


class host__UIDefs_UIDefs_Fields_:
    _hx_class_name = "host._UIDefs.UIDefs_Fields_"
    __slots__ = ()
    _hx_statics = ["samplers", "widgetinfo", "parameterNames"]
host__UIDefs_UIDefs_Fields_._hx_class = host__UIDefs_UIDefs_Fields_


class pyqt5_qtcore__QMap_QMapIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapIterator"
    __slots__ = ("checked", "has", "it", "x")
    _hx_fields = ["checked", "has", "it", "x"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,q):
        self.x = None
        self.has = False
        self.checked = False
        self.it = q

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except StopIteration:
                self.has = False
                self.x = None
            self.checked = True

        return self.has

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.checked = None
        _hx_o.has = None
        _hx_o.it = None
        _hx_o.x = None
pyqt5_qtcore__QMap_QMapIterator._hx_class = pyqt5_qtcore__QMap_QMapIterator


class pyqt5_qtcore__QMap_QMapKeyValueIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapKeyValueIterator"
    __slots__ = ("map", "keys")
    _hx_fields = ["map", "keys"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,_hx_map):
        self.map = _hx_map
        self.keys = pyqt5_qtcore__QMap_QMapIterator(iter(_hx_map.keys()))

    def hasNext(self):
        return self.keys.hasNext()

    def next(self):
        key = self.keys.next()
        return _hx_AnonObject({'value': self.map[key], 'key': key})

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.map = None
        _hx_o.keys = None
pyqt5_qtcore__QMap_QMapKeyValueIterator._hx_class = pyqt5_qtcore__QMap_QMapKeyValueIterator


class python_Boot:
    _hx_class_name = "python.Boot"
    __slots__ = ()
    _hx_statics = ["keywords", "_add_dynamic", "toString1", "fields", "simpleField", "hasField", "field", "getInstanceFields", "getSuperClass", "getClassFields", "prefixLength", "unhandleKeywords"]

    @staticmethod
    def _add_dynamic(a,b):
        if (isinstance(a,str) and isinstance(b,str)):
            return (a + b)
        if (isinstance(a,str) or isinstance(b,str)):
            return (python_Boot.toString1(a,"") + python_Boot.toString1(b,""))
        return (a + b)

    @staticmethod
    def toString1(o,s):
        if (o is None):
            return "null"
        if isinstance(o,str):
            return o
        if (s is None):
            s = ""
        if (len(s) >= 5):
            return "<...>"
        if isinstance(o,bool):
            if o:
                return "true"
            else:
                return "false"
        if (isinstance(o,int) and (not isinstance(o,bool))):
            return str(o)
        if isinstance(o,float):
            try:
                if (o == int(o)):
                    return str(Math.floor((o + 0.5)))
                else:
                    return str(o)
            except BaseException as _g:
                None
                return str(o)
        if isinstance(o,list):
            o1 = o
            l = len(o1)
            st = "["
            s = (("null" if s is None else s) + "\t")
            _g = 0
            _g1 = l
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                prefix = ""
                if (i > 0):
                    prefix = ","
                st = (("null" if st is None else st) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1((o1[i] if i >= 0 and i < len(o1) else None),s))))))
            st = (("null" if st is None else st) + "]")
            return st
        try:
            if hasattr(o,"toString"):
                return o.toString()
        except BaseException as _g:
            None
        if hasattr(o,"__class__"):
            if isinstance(o,_hx_AnonObject):
                toStr = None
                try:
                    fields = python_Boot.fields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (("{ " + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " }")
                except BaseException as _g:
                    None
                    return "{ ... }"
                if (toStr is None):
                    return "{ ... }"
                else:
                    return toStr
            if isinstance(o,Enum):
                o1 = o
                l = len(o1.params)
                hasParams = (l > 0)
                if hasParams:
                    paramsStr = ""
                    _g = 0
                    _g1 = l
                    while (_g < _g1):
                        i = _g
                        _g = (_g + 1)
                        prefix = ""
                        if (i > 0):
                            prefix = ","
                        paramsStr = (("null" if paramsStr is None else paramsStr) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1(o1.params[i],s))))))
                    return (((HxOverrides.stringOrNull(o1.tag) + "(") + ("null" if paramsStr is None else paramsStr)) + ")")
                else:
                    return o1.tag
            if hasattr(o,"_hx_class_name"):
                if (o.__class__.__name__ != "type"):
                    fields = python_Boot.getInstanceFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((HxOverrides.stringOrNull(o._hx_class_name) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
                else:
                    fields = python_Boot.getClassFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((("#" + HxOverrides.stringOrNull(o._hx_class_name)) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
            if ((type(o) == type) and (o == str)):
                return "#String"
            if ((type(o) == type) and (o == list)):
                return "#Array"
            if callable(o):
                return "function"
            try:
                if hasattr(o,"__repr__"):
                    return o.__repr__()
            except BaseException as _g:
                None
            if hasattr(o,"__str__"):
                return o.__str__([])
            if hasattr(o,"__name__"):
                return o.__name__
            return "???"
        else:
            return str(o)

    @staticmethod
    def fields(o):
        a = []
        if (o is not None):
            if hasattr(o,"_hx_fields"):
                fields = o._hx_fields
                if (fields is not None):
                    return list(fields)
            if isinstance(o,_hx_AnonObject):
                d = o.__dict__
                keys = d.keys()
                handler = python_Boot.unhandleKeywords
                for k in keys:
                    if (k != '_hx_disable_getattr'):
                        a.append(handler(k))
            elif hasattr(o,"__dict__"):
                d = o.__dict__
                keys1 = d.keys()
                for k in keys1:
                    a.append(k)
        return a

    @staticmethod
    def simpleField(o,field):
        if (field is None):
            return None
        field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        if hasattr(o,field1):
            return getattr(o,field1)
        else:
            return None

    @staticmethod
    def hasField(o,field):
        if isinstance(o,_hx_AnonObject):
            return o._hx_hasattr(field)
        return hasattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)))

    @staticmethod
    def field(o,field):
        if (field is None):
            return None
        if isinstance(o,str):
            field1 = field
            _hx_local_0 = len(field1)
            if (_hx_local_0 == 10):
                if (field1 == "charCodeAt"):
                    return python_internal_MethodClosure(o,HxString.charCodeAt)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,HxString.lastIndexOf)
                elif (field1 == "toLowerCase"):
                    return python_internal_MethodClosure(o,HxString.toLowerCase)
                elif (field1 == "toUpperCase"):
                    return python_internal_MethodClosure(o,HxString.toUpperCase)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 9):
                if (field1 == "substring"):
                    return python_internal_MethodClosure(o,HxString.substring)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 5):
                if (field1 == "split"):
                    return python_internal_MethodClosure(o,HxString.split)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,HxString.indexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 8):
                if (field1 == "toString"):
                    return python_internal_MethodClosure(o,HxString.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 6):
                if (field1 == "charAt"):
                    return python_internal_MethodClosure(o,HxString.charAt)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "substr"):
                    return python_internal_MethodClosure(o,HxString.substr)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        elif isinstance(o,list):
            field1 = field
            _hx_local_1 = len(field1)
            if (_hx_local_1 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.lastIndexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 4):
                if (field1 == "copy"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.copy)
                elif (field1 == "join"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.join)
                elif (field1 == "push"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.push)
                elif (field1 == "sort"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.sort)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 5):
                if (field1 == "shift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.shift)
                elif (field1 == "slice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.slice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.indexOf)
                elif (field1 == "reverse"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.reverse)
                elif (field1 == "unshift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.unshift)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 3):
                if (field1 == "map"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.map)
                elif (field1 == "pop"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.pop)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 8):
                if (field1 == "contains"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.contains)
                elif (field1 == "iterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.iterator)
                elif (field1 == "toString"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 16):
                if (field1 == "keyValueIterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.keyValueIterator)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 6):
                if (field1 == "concat"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.concat)
                elif (field1 == "filter"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.filter)
                elif (field1 == "insert"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.insert)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "remove"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.remove)
                elif (field1 == "splice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.splice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        else:
            field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
            if hasattr(o,field1):
                return getattr(o,field1)
            else:
                return None

    @staticmethod
    def getInstanceFields(c):
        f = (list(c._hx_fields) if (hasattr(c,"_hx_fields")) else [])
        if hasattr(c,"_hx_methods"):
            f = (f + c._hx_methods)
        sc = python_Boot.getSuperClass(c)
        if (sc is None):
            return f
        else:
            scArr = python_Boot.getInstanceFields(sc)
            scMap = set(scArr)
            _g = 0
            while (_g < len(f)):
                f1 = (f[_g] if _g >= 0 and _g < len(f) else None)
                _g = (_g + 1)
                if (not (f1 in scMap)):
                    scArr.append(f1)
            return scArr

    @staticmethod
    def getSuperClass(c):
        if (c is None):
            return None
        try:
            if hasattr(c,"_hx_super"):
                return c._hx_super
            return None
        except BaseException as _g:
            None
        return None

    @staticmethod
    def getClassFields(c):
        if hasattr(c,"_hx_statics"):
            x = c._hx_statics
            return list(x)
        else:
            return []

    @staticmethod
    def unhandleKeywords(name):
        if (HxString.substr(name,0,python_Boot.prefixLength) == "_hx_"):
            real = HxString.substr(name,python_Boot.prefixLength,None)
            if (real in python_Boot.keywords):
                return real
        return name
python_Boot._hx_class = python_Boot


class python_HaxeIterator:
    _hx_class_name = "python.HaxeIterator"
    __slots__ = ("it", "x", "has", "checked")
    _hx_fields = ["it", "x", "has", "checked"]
    _hx_methods = ["next", "hasNext"]

    def __init__(self,it):
        self.checked = False
        self.has = False
        self.x = None
        self.it = it

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),StopIteration):
                    self.has = False
                    self.x = None
                else:
                    raise _g
            self.checked = True
        return self.has

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.it = None
        _hx_o.x = None
        _hx_o.has = None
        _hx_o.checked = None
python_HaxeIterator._hx_class = python_HaxeIterator


class python__KwArgs_KwArgs_Impl_:
    _hx_class_name = "python._KwArgs.KwArgs_Impl_"
    __slots__ = ()
    _hx_statics = ["fromT"]

    @staticmethod
    def fromT(d):
        this1 = python_Lib.anonAsDict(d)
        return this1
python__KwArgs_KwArgs_Impl_._hx_class = python__KwArgs_KwArgs_Impl_


class python_Lib:
    _hx_class_name = "python.Lib"
    __slots__ = ()
    _hx_statics = ["dictToAnon", "anonToDict", "anonAsDict"]

    @staticmethod
    def dictToAnon(v):
        return _hx_AnonObject(v.copy())

    @staticmethod
    def anonToDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__.copy()
        else:
            return None

    @staticmethod
    def anonAsDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__
        else:
            return None
python_Lib._hx_class = python_Lib


class python_internal_ArrayImpl:
    _hx_class_name = "python.internal.ArrayImpl"
    __slots__ = ()
    _hx_statics = ["concat", "copy", "iterator", "keyValueIterator", "indexOf", "lastIndexOf", "join", "toString", "pop", "push", "unshift", "remove", "contains", "shift", "slice", "sort", "splice", "map", "filter", "insert", "reverse", "_get", "_set"]

    @staticmethod
    def concat(a1,a2):
        return (a1 + a2)

    @staticmethod
    def copy(x):
        return list(x)

    @staticmethod
    def iterator(x):
        return python_HaxeIterator(x.__iter__())

    @staticmethod
    def keyValueIterator(x):
        return haxe_iterators_ArrayKeyValueIterator(x)

    @staticmethod
    def indexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (0 if ((fromIndex is None)) else ((_hx_len + fromIndex) if ((fromIndex < 0)) else fromIndex))
        if (l < 0):
            l = 0
        _g = l
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            if HxOverrides.eq(a[i],x):
                return i
        return -1

    @staticmethod
    def lastIndexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (_hx_len if ((fromIndex is None)) else (((_hx_len + fromIndex) + 1) if ((fromIndex < 0)) else (fromIndex + 1)))
        if (l > _hx_len):
            l = _hx_len
        while True:
            l = (l - 1)
            tmp = l
            if (not ((tmp > -1))):
                break
            if HxOverrides.eq(a[l],x):
                return l
        return -1

    @staticmethod
    def join(x,sep):
        return sep.join([python_Boot.toString1(x1,'') for x1 in x])

    @staticmethod
    def toString(x):
        return (("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in x]))) + "]")

    @staticmethod
    def pop(x):
        if (len(x) == 0):
            return None
        else:
            return x.pop()

    @staticmethod
    def push(x,e):
        x.append(e)
        return len(x)

    @staticmethod
    def unshift(x,e):
        x.insert(0, e)

    @staticmethod
    def remove(x,e):
        try:
            x.remove(e)
            return True
        except BaseException as _g:
            None
            return False

    @staticmethod
    def contains(x,e):
        return (e in x)

    @staticmethod
    def shift(x):
        if (len(x) == 0):
            return None
        return x.pop(0)

    @staticmethod
    def slice(x,pos,end = None):
        return x[pos:end]

    @staticmethod
    def sort(x,f):
        x.sort(key= python_lib_Functools.cmp_to_key(f))

    @staticmethod
    def splice(x,pos,_hx_len):
        if (pos < 0):
            pos = (len(x) + pos)
        if (pos < 0):
            pos = 0
        res = x[pos:(pos + _hx_len)]
        del x[pos:(pos + _hx_len)]
        return res

    @staticmethod
    def map(x,f):
        return list(map(f,x))

    @staticmethod
    def filter(x,f):
        return list(filter(f,x))

    @staticmethod
    def insert(a,pos,x):
        a.insert(pos, x)

    @staticmethod
    def reverse(a):
        a.reverse()

    @staticmethod
    def _get(x,idx):
        if ((idx > -1) and ((idx < len(x)))):
            return x[idx]
        else:
            return None

    @staticmethod
    def _set(x,idx,v):
        l = len(x)
        while (l < idx):
            x.append(None)
            l = (l + 1)
        if (l == idx):
            x.append(v)
        else:
            x[idx] = v
        return v
python_internal_ArrayImpl._hx_class = python_internal_ArrayImpl


class HxOverrides:
    _hx_class_name = "HxOverrides"
    __slots__ = ()
    _hx_statics = ["iterator", "eq", "stringOrNull", "toLowerCase", "modf", "mod", "arrayGet", "mapKwArgs"]

    @staticmethod
    def iterator(x):
        if isinstance(x,list):
            return haxe_iterators_ArrayIterator(x)
        return x.iterator()

    @staticmethod
    def eq(a,b):
        if (isinstance(a,list) or isinstance(b,list)):
            return a is b
        return (a == b)

    @staticmethod
    def stringOrNull(s):
        if (s is None):
            return "null"
        else:
            return s

    @staticmethod
    def toLowerCase(x):
        if isinstance(x,str):
            return x.lower()
        return x.toLowerCase()

    @staticmethod
    def modf(a,b):
        if (b == 0.0):
            return float('nan')
        elif (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mod(a,b):
        if (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def arrayGet(a,i):
        if isinstance(a,list):
            x = a
            if ((i > -1) and ((i < len(x)))):
                return x[i]
            else:
                return None
        else:
            return a[i]

    @staticmethod
    def mapKwArgs(a,v):
        a1 = _hx_AnonObject(python_Lib.anonToDict(a))
        k = python_HaxeIterator(iter(v.keys()))
        while k.hasNext():
            k1 = k.next()
            val = v.get(k1)
            if a1._hx_hasattr(k1):
                x = getattr(a1,k1)
                setattr(a1,val,x)
                delattr(a1,k1)
        return a1
HxOverrides._hx_class = HxOverrides


class python_internal_MethodClosure:
    _hx_class_name = "python.internal.MethodClosure"
    __slots__ = ("obj", "func")
    _hx_fields = ["obj", "func"]
    _hx_methods = ["__call__"]

    def __init__(self,obj,func):
        self.obj = obj
        self.func = func

    def __call__(self,*args):
        return self.func(self.obj,*args)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.obj = None
        _hx_o.func = None
python_internal_MethodClosure._hx_class = python_internal_MethodClosure


class HxString:
    _hx_class_name = "HxString"
    __slots__ = ()
    _hx_statics = ["split", "charCodeAt", "charAt", "lastIndexOf", "toUpperCase", "toLowerCase", "indexOf", "indexOfImpl", "toString", "substring", "substr"]

    @staticmethod
    def split(s,d):
        if (d == ""):
            return list(s)
        else:
            return s.split(d)

    @staticmethod
    def charCodeAt(s,index):
        if ((((s is None) or ((len(s) == 0))) or ((index < 0))) or ((index >= len(s)))):
            return None
        else:
            return ord(s[index])

    @staticmethod
    def charAt(s,index):
        if ((index < 0) or ((index >= len(s)))):
            return ""
        else:
            return s[index]

    @staticmethod
    def lastIndexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.rfind(_hx_str, 0, len(s))
        elif (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        else:
            i = s.rfind(_hx_str, 0, (startIndex + 1))
            startLeft = (max(0,((startIndex + 1) - len(_hx_str))) if ((i == -1)) else (i + 1))
            check = s.find(_hx_str, startLeft, len(s))
            if ((check > i) and ((check <= startIndex))):
                return check
            else:
                return i

    @staticmethod
    def toUpperCase(s):
        return s.upper()

    @staticmethod
    def toLowerCase(s):
        return s.lower()

    @staticmethod
    def indexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.find(_hx_str)
        else:
            return HxString.indexOfImpl(s,_hx_str,startIndex)

    @staticmethod
    def indexOfImpl(s,_hx_str,startIndex):
        if (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        return s.find(_hx_str, startIndex)

    @staticmethod
    def toString(s):
        return s

    @staticmethod
    def substring(s,startIndex,endIndex = None):
        if (startIndex < 0):
            startIndex = 0
        if (endIndex is None):
            return s[startIndex:]
        else:
            if (endIndex < 0):
                endIndex = 0
            if (endIndex < startIndex):
                return s[endIndex:startIndex]
            else:
                return s[startIndex:endIndex]

    @staticmethod
    def substr(s,startIndex,_hx_len = None):
        if (_hx_len is None):
            return s[startIndex:]
        else:
            if (_hx_len == 0):
                return ""
            if (startIndex < 0):
                startIndex = (len(s) + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            return s[startIndex:(startIndex + _hx_len)]
HxString._hx_class = HxString


class sys_net_Socket:
    _hx_class_name = "sys.net.Socket"
    __slots__ = ("_hx___s", "input", "output")
    _hx_fields = ["__s", "input", "output"]
    _hx_methods = ["__initSocket", "close", "connect", "shutdown", "setTimeout", "fileno"]

    def __init__(self):
        self.output = None
        self.input = None
        self._hx___s = None
        self._hx___initSocket()
        self.input = sys_net__Socket_SocketInput(self._hx___s)
        self.output = sys_net__Socket_SocketOutput(self._hx___s)

    def _hx___initSocket(self):
        self._hx___s = python_lib_socket_Socket()

    def close(self):
        self._hx___s.close()

    def connect(self,host,port):
        host_str = host.toString()
        self._hx___s.connect((host_str, port))

    def shutdown(self,read,write):
        self._hx___s.shutdown((python_lib_Socket.SHUT_RDWR if ((read and write)) else (python_lib_Socket.SHUT_RD if read else python_lib_Socket.SHUT_WR)))

    def setTimeout(self,timeout):
        self._hx___s.settimeout(timeout)

    def fileno(self):
        return self._hx___s.fileno()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
        _hx_o.input = None
        _hx_o.output = None
sys_net_Socket._hx_class = sys_net_Socket


class python_net_SslSocket(sys_net_Socket):
    _hx_class_name = "python.net.SslSocket"
    __slots__ = ("hostName",)
    _hx_fields = ["hostName"]
    _hx_methods = ["__initSocket", "connect"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = sys_net_Socket


    def __init__(self):
        self.hostName = None
        super().__init__()

    def _hx___initSocket(self):
        context = python_lib_ssl_SSLContext(python_lib_Ssl.PROTOCOL_SSLv23)
        context.verify_mode = python_lib_Ssl.CERT_REQUIRED
        context.set_default_verify_paths()
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv2)
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv3)
        context.options = (context.options | python_lib_Ssl.OP_NO_COMPRESSION)
        context.options = (context.options | python_lib_Ssl.OP_NO_TLSv1)
        self._hx___s = python_lib_socket_Socket()
        self._hx___s = context.wrap_socket(self._hx___s,False,True,True,self.hostName)

    def connect(self,host,port):
        self.hostName = host.host
        super().connect(host,port)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.hostName = None
python_net_SslSocket._hx_class = python_net_SslSocket


class sys_Http(haxe_http_HttpBase):
    _hx_class_name = "sys.Http"
    __slots__ = ("noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file")
    _hx_fields = ["noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file"]
    _hx_methods = ["request", "customRequest", "writeBody", "readHttpResponse", "readChunk"]
    _hx_statics = ["PROXY"]
    _hx_interfaces = []
    _hx_super = haxe_http_HttpBase


    def __init__(self,url):
        self.file = None
        self.chunk_buf = None
        self.chunk_size = None
        self.responseHeaders = None
        self.noShutdown = None
        self.cnxTimeout = 10
        super().__init__(url)

    def request(self,post = None):
        _gthis = self
        output = haxe_io_BytesOutput()
        old = self.onError
        err = False
        def _hx_local_0(e):
            nonlocal err
            _gthis.responseBytes = output.getBytes()
            err = True
            _gthis.onError = old
            _gthis.onError(e)
        self.onError = _hx_local_0
        post = ((post or ((self.postBytes is not None))) or ((self.postData is not None)))
        self.customRequest(post,output)
        if (not err):
            self.success(output.getBytes())

    def customRequest(self,post,api,sock = None,method = None):
        self.responseAsString = None
        self.responseBytes = None
        url_regexp = EReg("^(https?://)?([a-zA-Z\\.0-9_-]+)(:[0-9]+)?(.*)$","")
        url_regexp.matchObj = python_lib_Re.search(url_regexp.pattern,self.url)
        if (url_regexp.matchObj is None):
            self.onError("Invalid URL")
            return
        secure = (url_regexp.matchObj.group(1) == "https://")
        if (sock is None):
            if secure:
                sock = python_net_SslSocket()
            else:
                sock = sys_net_Socket()
            sock.setTimeout(self.cnxTimeout)
        host = url_regexp.matchObj.group(2)
        portString = url_regexp.matchObj.group(3)
        request = url_regexp.matchObj.group(4)
        if ((("" if ((0 >= len(request))) else request[0])) != "/"):
            request = ("/" + ("null" if request is None else request))
        port = ((443 if secure else 80) if (((portString is None) or ((portString == "")))) else Std.parseInt(HxString.substr(portString,1,(len(portString) - 1))))
        multipart = (self.file is not None)
        boundary = None
        uri = None
        if multipart:
            post = True
            boundary = (((Std.string(int((python_lib_Random.random() * 1000))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000))))
            while (len(boundary) < 38):
                boundary = ("-" + ("null" if boundary is None else boundary))
            b_b = python_lib_io_StringIO()
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                b_b.write("--")
                b_b.write(Std.string(boundary))
                b_b.write("\r\n")
                b_b.write("Content-Disposition: form-data; name=\"")
                b_b.write(Std.string(p.name))
                b_b.write("\"")
                b_b.write("\r\n")
                b_b.write("\r\n")
                b_b.write(Std.string(p.value))
                b_b.write("\r\n")
            b_b.write("--")
            b_b.write(Std.string(boundary))
            b_b.write("\r\n")
            b_b.write("Content-Disposition: form-data; name=\"")
            b_b.write(Std.string(self.file.param))
            b_b.write("\"; filename=\"")
            b_b.write(Std.string(self.file.filename))
            b_b.write("\"")
            b_b.write("\r\n")
            b_b.write(Std.string(((("Content-Type: " + HxOverrides.stringOrNull(self.file.mimeType)) + "\r\n") + "\r\n")))
            uri = b_b.getvalue()
        else:
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if (uri is None):
                    uri = ""
                else:
                    uri = (("null" if uri is None else uri) + "&")
                uri = (("null" if uri is None else uri) + HxOverrides.stringOrNull((((HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(p.name,"")) + "=") + HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(("" + HxOverrides.stringOrNull(p.value)),""))))))
        b = haxe_io_BytesOutput()
        if (method is not None):
            b.writeString(method)
            b.writeString(" ")
        elif post:
            b.writeString("POST ")
        else:
            b.writeString("GET ")
        if (sys_Http.PROXY is not None):
            b.writeString("http://")
            b.writeString(host)
            if (port != 80):
                b.writeString(":")
                b.writeString(("" + Std.string(port)))
        b.writeString(request)
        if ((not post) and ((uri is not None))):
            if (HxString.indexOfImpl(request,"?",0) >= 0):
                b.writeString("&")
            else:
                b.writeString("?")
            b.writeString(uri)
        b.writeString(((" HTTP/1.1\r\nHost: " + ("null" if host is None else host)) + "\r\n"))
        if (self.postData is not None):
            self.postBytes = haxe_io_Bytes.ofString(self.postData)
            self.postData = None
        if (self.postBytes is not None):
            b.writeString((("Content-Length: " + Std.string(self.postBytes.length)) + "\r\n"))
        elif (post and ((uri is not None))):
            def _hx_local_4(h):
                return (h.name == "Content-Type")
            if (multipart or (not Lambda.exists(self.headers,_hx_local_4))):
                b.writeString("Content-Type: ")
                if multipart:
                    b.writeString("multipart/form-data")
                    b.writeString("; boundary=")
                    b.writeString(boundary)
                else:
                    b.writeString("application/x-www-form-urlencoded")
                b.writeString("\r\n")
            if multipart:
                b.writeString((("Content-Length: " + Std.string(((((len(uri) + self.file.size) + len(boundary)) + 6)))) + "\r\n"))
            else:
                b.writeString((("Content-Length: " + Std.string(len(uri))) + "\r\n"))
        b.writeString("Connection: close\r\n")
        _g = 0
        _g1 = self.headers
        while (_g < len(_g1)):
            h = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            b.writeString(h.name)
            b.writeString(": ")
            b.writeString(h.value)
            b.writeString("\r\n")
        b.writeString("\r\n")
        if (self.postBytes is not None):
            b.writeFullBytes(self.postBytes,0,self.postBytes.length)
        elif (post and ((uri is not None))):
            b.writeString(uri)
        try:
            if (sys_Http.PROXY is not None):
                sock.connect(sys_net_Host(sys_Http.PROXY.host),sys_Http.PROXY.port)
            else:
                sock.connect(sys_net_Host(host),port)
            if multipart:
                self.writeBody(b,self.file.io,self.file.size,boundary,sock)
            else:
                self.writeBody(b,None,0,None,sock)
            self.readHttpResponse(api,sock)
            sock.close()
        except BaseException as _g:
            None
            e = haxe_Exception.caught(_g).unwrap()
            try:
                sock.close()
            except BaseException as _g:
                pass
            self.onError(Std.string(e))

    def writeBody(self,body,fileInput,fileSize,boundary,sock):
        if (body is not None):
            _hx_bytes = body.getBytes()
            sock.output.writeFullBytes(_hx_bytes,0,_hx_bytes.length)
        if (boundary is not None):
            bufsize = 4096
            buf = haxe_io_Bytes.alloc(bufsize)
            while (fileSize > 0):
                size = (bufsize if ((fileSize > bufsize)) else fileSize)
                _hx_len = 0
                try:
                    _hx_len = fileInput.readBytes(buf,0,size)
                except BaseException as _g:
                    None
                    if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                        break
                    else:
                        raise _g
                sock.output.writeFullBytes(buf,0,_hx_len)
                fileSize = (fileSize - _hx_len)
            sock.output.writeString("\r\n")
            sock.output.writeString("--")
            sock.output.writeString(boundary)
            sock.output.writeString("--")

    def readHttpResponse(self,api,sock):
        b = haxe_io_BytesBuffer()
        k = 4
        s = haxe_io_Bytes.alloc(4)
        sock.setTimeout(self.cnxTimeout)
        while True:
            p = sock.input.readBytes(s,0,k)
            while (p != k):
                p = (p + sock.input.readBytes(s,p,(k - p)))
            if ((k < 0) or ((k > s.length))):
                raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
            b.b.extend(s.b[0:k])
            k1 = k
            if (k1 == 1):
                c = s.b[0]
                if (c == 10):
                    break
                if (c == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 2):
                c1 = s.b[1]
                if (c1 == 10):
                    if (s.b[0] == 13):
                        break
                    k = 4
                elif (c1 == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 3):
                c2 = s.b[2]
                if (c2 == 10):
                    if (s.b[1] != 13):
                        k = 4
                    elif (s.b[0] != 10):
                        k = 2
                    else:
                        break
                elif (c2 == 13):
                    if ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 1
                    else:
                        k = 3
                else:
                    k = 4
            elif (k1 == 4):
                c3 = s.b[3]
                if (c3 == 10):
                    if (s.b[2] != 13):
                        continue
                    elif ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 2
                    else:
                        break
                elif (c3 == 13):
                    if ((s.b[2] != 10) or ((s.b[1] != 13))):
                        k = 3
                    else:
                        k = 1
            else:
                pass
        _this = b.getBytes().toString()
        headers = _this.split("\r\n")
        response = (None if ((len(headers) == 0)) else headers.pop(0))
        rp = response.split(" ")
        status = Std.parseInt((rp[1] if 1 < len(rp) else None))
        if ((status == 0) or ((status is None))):
            raise haxe_Exception.thrown("Response status error")
        if (len(headers) != 0):
            headers.pop()
        if (len(headers) != 0):
            headers.pop()
        self.responseHeaders = haxe_ds_StringMap()
        size = None
        chunked = False
        _g = 0
        while (_g < len(headers)):
            hline = (headers[_g] if _g >= 0 and _g < len(headers) else None)
            _g = (_g + 1)
            a = hline.split(": ")
            hname = (None if ((len(a) == 0)) else a.pop(0))
            hval = ((a[0] if 0 < len(a) else None) if ((len(a) == 1)) else ": ".join([python_Boot.toString1(x1,'') for x1 in a]))
            hval = StringTools.ltrim(StringTools.rtrim(hval))
            self.responseHeaders.h[hname] = hval
            _g1 = hname.lower()
            _hx_local_2 = len(_g1)
            if (_hx_local_2 == 17):
                if (_g1 == "transfer-encoding"):
                    chunked = (hval.lower() == "chunked")
            elif (_hx_local_2 == 14):
                if (_g1 == "content-length"):
                    size = Std.parseInt(hval)
            else:
                pass
        self.onStatus(status)
        chunk_re = EReg("^([0-9A-Fa-f]+)[ ]*\r\n","m")
        self.chunk_size = None
        self.chunk_buf = None
        bufsize = 1024
        buf = haxe_io_Bytes.alloc(bufsize)
        if chunked:
            try:
                while True:
                    _hx_len = sock.input.readBytes(buf,0,bufsize)
                    if (not self.readChunk(chunk_re,api,buf,_hx_len)):
                        break
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        elif (size is None):
            if (not self.noShutdown):
                sock.shutdown(False,True)
            try:
                while True:
                    _hx_len = sock.input.readBytes(buf,0,bufsize)
                    if (_hx_len == 0):
                        break
                    api.writeBytes(buf,0,_hx_len)
            except BaseException as _g:
                None
                if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                    raise _g
        else:
            api.prepare(size)
            try:
                while (size > 0):
                    _hx_len = sock.input.readBytes(buf,0,(bufsize if ((size > bufsize)) else size))
                    api.writeBytes(buf,0,_hx_len)
                    size = (size - _hx_len)
            except BaseException as _g:
                None
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        if (chunked and (((self.chunk_size is not None) or ((self.chunk_buf is not None))))):
            raise haxe_Exception.thrown("Invalid chunk")
        if ((status < 200) or ((status >= 400))):
            raise haxe_Exception.thrown(("Http Error #" + Std.string(status)))
        api.close()

    def readChunk(self,chunk_re,api,buf,_hx_len):
        if (self.chunk_size is None):
            if (self.chunk_buf is not None):
                b = haxe_io_BytesBuffer()
                b.b.extend(self.chunk_buf.b)
                if ((_hx_len < 0) or ((_hx_len > buf.length))):
                    raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
                b.b.extend(buf.b[0:_hx_len])
                buf = b.getBytes()
                _hx_len = (_hx_len + self.chunk_buf.length)
                self.chunk_buf = None
            s = buf.toString()
            chunk_re.matchObj = python_lib_Re.search(chunk_re.pattern,s)
            if (chunk_re.matchObj is not None):
                p_pos = chunk_re.matchObj.start()
                p_len = (chunk_re.matchObj.end() - chunk_re.matchObj.start())
                if (p_len <= _hx_len):
                    cstr = chunk_re.matchObj.group(1)
                    self.chunk_size = Std.parseInt(("0x" + ("null" if cstr is None else cstr)))
                    if (self.chunk_size == 0):
                        self.chunk_size = None
                        self.chunk_buf = None
                        return False
                    _hx_len = (_hx_len - p_len)
                    return self.readChunk(chunk_re,api,buf.sub(p_len,_hx_len),_hx_len)
            if (_hx_len > 10):
                self.onError("Invalid chunk")
                return False
            self.chunk_buf = buf.sub(0,_hx_len)
            return True
        if (self.chunk_size > _hx_len):
            _hx_local_2 = self
            _hx_local_3 = _hx_local_2.chunk_size
            _hx_local_2.chunk_size = (_hx_local_3 - _hx_len)
            _hx_local_2.chunk_size
            api.writeBytes(buf,0,_hx_len)
            return True
        end = (self.chunk_size + 2)
        if (_hx_len >= end):
            if (self.chunk_size > 0):
                api.writeBytes(buf,0,self.chunk_size)
            _hx_len = (_hx_len - end)
            self.chunk_size = None
            if (_hx_len == 0):
                return True
            return self.readChunk(chunk_re,api,buf.sub(end,_hx_len),_hx_len)
        if (self.chunk_size > 0):
            api.writeBytes(buf,0,self.chunk_size)
        _hx_local_5 = self
        _hx_local_6 = _hx_local_5.chunk_size
        _hx_local_5.chunk_size = (_hx_local_6 - _hx_len)
        _hx_local_5.chunk_size
        return True

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.noShutdown = None
        _hx_o.cnxTimeout = None
        _hx_o.responseHeaders = None
        _hx_o.chunk_size = None
        _hx_o.chunk_buf = None
        _hx_o.file = None
sys_Http._hx_class = sys_Http


class sys_net_Host:
    _hx_class_name = "sys.net.Host"
    __slots__ = ("host", "name")
    _hx_fields = ["host", "name"]
    _hx_methods = ["toString"]

    def __init__(self,name):
        self.host = name
        self.name = name

    def toString(self):
        return self.name

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.host = None
        _hx_o.name = None
sys_net_Host._hx_class = sys_net_Host


class sys_net__Socket_SocketInput(haxe_io_Input):
    _hx_class_name = "sys.net._Socket.SocketInput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["readByte", "readBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,s):
        self._hx___s = s

    def readByte(self):
        r = None
        try:
            r = self._hx___s.recv(1,0)
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        return r[0]

    def readBytes(self,buf,pos,_hx_len):
        r = None
        data = buf.b
        try:
            r = self._hx___s.recv(_hx_len,0)
            _g = pos
            _g1 = (pos + len(r))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                data.__setitem__(i,r[(i - pos)])
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        return len(r)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
sys_net__Socket_SocketInput._hx_class = sys_net__Socket_SocketInput


class sys_net__Socket_SocketOutput(haxe_io_Output):
    _hx_class_name = "sys.net._Socket.SocketOutput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["writeByte", "writeBytes", "close"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self,s):
        self._hx___s = s

    def writeByte(self,c):
        try:
            self._hx___s.send(bytes([c]),0)
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def writeBytes(self,buf,pos,_hx_len):
        try:
            data = buf.b
            payload = data[pos:pos+_hx_len]
            r = self._hx___s.send(payload,0)
            return r
        except BaseException as _g:
            None
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def close(self):
        super().close()
        if (self._hx___s is not None):
            self._hx___s.close()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
sys_net__Socket_SocketOutput._hx_class = sys_net__Socket_SocketOutput


class tink_Clone:
    _hx_class_name = "tink.Clone"
    __slots__ = ()
tink_Clone._hx_class = tink_Clone

Math.NEGATIVE_INFINITY = float("-inf")
Math.POSITIVE_INFINITY = float("inf")
Math.NaN = float("nan")
Math.PI = python_lib_Math.pi

def _hx_init__Defs_Defs_Fields__fn_indices():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = 13
        _g.h["img2img"] = 33
        _g.h["inpaint"] = 33
        _g.h["Outpainting_mk2"] = 33
        _g.h["SD Upscale"] = 33
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.fn_indices = _hx_init__Defs_Defs_Fields__fn_indices()
_Defs_Defs_Fields_.baseurl = "http://localhost:7860"
def _hx_init__Defs_Defs_Fields__defaults():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["Outpainting_mk2"] = [0, "a cute dog", "evil", "None", "None", "data:image/png;base64,", None, None, None, "Draw mask", 20, "Euler a", 4, "fill", False, False, 1, 1, 7, 0.75, -1, -1, 0, 0, 0, True, 512, 512, "Just resize", False, 32, "Inpaint masked", "", "", "Outpainting mk2", "Nonsense", True, True, "", "", True, 50, True, 1, 0, False, 4, 1, "Nonsense", 120, 7, ["left", "up", "down"], 1.02, 0.06, 128, 4, "fill", ["left", "right", "up", "down"], False, False, None, "", "Nonsense", 64, "None", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.defaults = _hx_init__Defs_Defs_Fields__defaults()
def _hx_init__Defs_Defs_Fields__ui_tags():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["Outpainting_mk2"] = [None, "prompt", "negative_prompt", None, None, "!img_in", None, None, None, None, "steps", "sampler", None, None, "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "denoising_strength", "seed", "subseed", "subseed_strength", "seed_resize_from_w", "seed_resize_from_h", None, "!img_height", "!img_width", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, "outpainting_pixels_to_expand", "outpainting_mask_blur", "outpainting_directions", "outpainting_falloff_exponent", "outpainting_color_variation", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.ui_tags = _hx_init__Defs_Defs_Fields__ui_tags()
MyDocker.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'checkReady': _hx_AnonObject({'_hx_async': None})}), 'fields': _hx_AnonObject({'generate2': _hx_AnonObject({'_hx_async': None}), 'generate': _hx_AnonObject({'_hx_async': None})})})
Utils.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'receive': _hx_AnonObject({'_hx_async': None})})})
Utils.params_for_layer = []
host_App.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'getDocumentState': _hx_AnonObject({'_hx_async': None}), 'setDocumentState': _hx_AnonObject({'_hx_async': None})})})
host_App.gradio_components = []
host_App.gradio_dependencies = []
host_UI.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'asyncfetch': _hx_AnonObject({'_hx_async': None})})})
host_UI.txt2img_generate_fn_index = None
host_UI.txt2img_data_inputs = []
host_UI.txt2img_data_outputs = []
host_UI.img2img_generate_fn_index = None
host_UI.img2img_data_inputs = []
host_UI.img2img_data_outputs = []
host_UI.is_inpainting = 0
def _hx_init_host_UI_tags():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = []
        _g.h["img2img"] = []
        _g.h["inpaint"] = []
        _g.h["outpainting_mk2"] = []
        return _g
    return _hx_local_0()
host_UI.tags = _hx_init_host_UI_tags()
host__UIDefs_UIDefs_Fields_.samplers = ["Euler a", "Euler", "LMS", "Heun", "DPM2", "DPM2 a", "DPM fast", "DPM adaptive", "LMS Karras", "DPM2 Karras", "DPM2a Karras", "DDIM", "PLMS"]
def _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "a cute dog"})
        _g.h["negative_prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "evil"})
        _g.h["steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 20, 'range': _hx_AnonObject({'min': 1, 'max': 200, 'step': 1})})
        _g.h["sampler"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "Euler a", 'comboBoxOptions': host__UIDefs_UIDefs_Fields_.samplers})
        _g.h["restore_faces"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["tiling"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["batch_count"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 32, 'step': 1})})
        _g.h["batch_size"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 16, 'step': 1})})
        _g.h["cfg_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 7, 'range': _hx_AnonObject({'min': -10, 'max': 64, 'step': 0.5})})
        _g.h["seed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.05})})
        _g.h["seed_resize_from_h"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["seed_resize_from_w"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["highres_fix"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_scale_latent"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_noise_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.7, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["denoising_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.75, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 512, 'step': 1})})
        _g.h["masked_content"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "fill", 'comboBoxOptions': ["fill", "original", "latent noise", "latent nothing"]})
        _g.h["inpaint_at_full_res"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["outpainting_pixels_to_expand"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 8, 'range': _hx_AnonObject({'min': 8, 'max': 128, 'step': 8})})
        _g.h["outpainting_mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 64, 'step': 1})})
        _g.h["outpainting_directions"] = _hx_AnonObject({'inputtype': "outpainting_directions", 'fdefault': ["left", "right", "up", "down"]})
        _g.h["outpainting_falloff_exponent"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 0, 'max': 4, 'step': 0.01})})
        _g.h["outpainting_color_variation"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.05, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["upscale_tile_overlap"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 64, 'range': _hx_AnonObject({'min': 16, 'max': 256, 'step': 16})})
        _g.h["upscaler"] = _hx_AnonObject({'inputtype': "ComboBox", 'comboBoxOptions': ["Lanczos", "None", "Real-ESRGAN 4x plus", "Real-ESRGAN 4x plus anime 6B", "LDSR"]})
        _g.h["firstpass_width"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["firstpass_height"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["Ae_learn_rate"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "0.0001"})
        _g.h["Ae_weight"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.9, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 5, 'range': _hx_AnonObject({'min': 0, 'max': 50, 'step': 1})})
        _g.h["Ae_embedding"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "None"})
        _g.h["Ae_slerp"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["Ae_text"] = _hx_AnonObject({'inputtype': "string", 'fdefault': ""})
        _g.h["Ae_slerp_angle"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.1, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_negative"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        return _g
    return _hx_local_0()
host__UIDefs_UIDefs_Fields_.widgetinfo = _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo()
def _hx_init_host__UIDefs_UIDefs_Fields__parameterNames():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["variation_seed"] = "subseed"
        _g.h["variation_strength"] = "subseed_strength"
        _g.h["sampling_steps"] = "steps"
        _g.h["sampling_method"] = "sampler"
        _g.h["resize_seed_from_height"] = "resize_seed_from_h"
        _g.h["resize_seed_from_width"] = "resize_seed_from_w"
        return _g
    return _hx_local_0()
host__UIDefs_UIDefs_Fields_.parameterNames = _hx_init_host__UIDefs_UIDefs_Fields__parameterNames()
python_Boot.keywords = set(["and", "del", "from", "not", "with", "as", "elif", "global", "or", "yield", "assert", "else", "if", "pass", "None", "break", "except", "import", "raise", "True", "class", "exec", "in", "return", "False", "continue", "finally", "is", "try", "def", "for", "lambda", "while"])
python_Boot.prefixLength = len("_hx_")
sys_Http.PROXY = None