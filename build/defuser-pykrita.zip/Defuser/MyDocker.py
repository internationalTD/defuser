import sys

import math as python_lib_Math
import math as Math
from PyQt5.QtWidgets import QWidget
from krita import DockWidget
from krita import Extension
import inspect as python_lib_Inspect
from krita import Krita
from krita import ManagedColor
from krita import Selection
from PyQt5.QtCore import QBuffer
from PyQt5.QtCore import QByteArray
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QHBoxLayout
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5.QtWidgets import QCheckBox
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QGroupBox
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QPlainTextEdit
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QScrollArea
from PyQt5.QtWidgets import QSpinBox
from PyQt5.QtWidgets import QDoubleSpinBox
from PyQt5.QtWidgets import QTabWidget
import sys as python_lib_Sys
import traceback as python_lib_Traceback
import functools as python_lib_Functools
import json as python_lib_Json
import random as python_lib_Random
import re as python_lib_Re
import socket as python_lib_Socket
import ssl as python_lib_Ssl
from datetime import datetime as python_lib_datetime_Datetime
from datetime import timezone as python_lib_datetime_Timezone
from io import StringIO as python_lib_io_StringIO
from socket import socket as python_lib_socket_Socket
from ssl import SSLContext as python_lib_ssl_SSLContext
import urllib.parse as python_lib_urllib_Parse


class _hx_AnonObject:
    _hx_disable_getattr = False
    def __init__(self, fields):
        self.__dict__ = fields
    def __repr__(self):
        return repr(self.__dict__)
    def __contains__(self, item):
        return item in self.__dict__
    def __getitem__(self, item):
        return self.__dict__[item]
    def __getattr__(self, name):
        if (self._hx_disable_getattr):
            raise AttributeError('field does not exist')
        else:
            return None
    def _hx_hasattr(self,field):
        self._hx_disable_getattr = True
        try:
            getattr(self, field)
            self._hx_disable_getattr = False
            return True
        except AttributeError:
            self._hx_disable_getattr = False
            return False



class Enum:
    _hx_class_name = "Enum"
    __slots__ = ("tag", "index", "params")
    _hx_fields = ["tag", "index", "params"]
    _hx_methods = ["__str__"]

    def __init__(self,tag,index,params):
        # C:\HaxeToolkit\haxe\std/python/internal/EnumImpl.hx:39
        self.tag = tag
        # C:\HaxeToolkit\haxe\std/python/internal/EnumImpl.hx:40
        self.index = index
        # C:\HaxeToolkit\haxe\std/python/internal/EnumImpl.hx:41
        self.params = params

    def __str__(self):
        # C:\HaxeToolkit\haxe\std/python/internal/EnumImpl.hx:46
        if (self.params is None):
            return self.tag
        else:
            return self.tag + '(' + (', '.join(str(v) for v in self.params)) + ')'

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.tag = None
        _hx_o.index = None
        _hx_o.params = None
Enum._hx_class = Enum


class Class: pass


class Date:
    _hx_class_name = "Date"
    __slots__ = ("date", "dateUTC")
    _hx_fields = ["date", "dateUTC"]
    _hx_methods = ["toString"]
    _hx_statics = ["makeLocal"]

    def __init__(self,year,month,day,hour,_hx_min,sec):
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:30
        self.dateUTC = None
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:33
        if (year < python_lib_datetime_Datetime.min.year):
            year = python_lib_datetime_Datetime.min.year
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:35
        if (day == 0):
            day = 1
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:37
        self.date = Date.makeLocal(python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0))
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:38
        self.dateUTC = self.date.astimezone(python_lib_datetime_Timezone.utc)

    def toString(self):
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:106
        return self.date.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def makeLocal(date):
        # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:124
        try:
            return date.astimezone()
        except BaseException as _g:
            # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:129
            tzinfo = python_lib_datetime_Datetime.now(python_lib_datetime_Timezone.utc).astimezone().tzinfo
            # C:\HaxeToolkit\haxe\std/python/_std/Date.hx:130
            return date.replace(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'tzinfo': tzinfo})))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.date = None
        _hx_o.dateUTC = None
Date._hx_class = Date


class haxe_IMap:
    _hx_class_name = "haxe.IMap"
    __slots__ = ()
    _hx_methods = ["get", "set", "keys"]
haxe_IMap._hx_class = haxe_IMap


class haxe_ds_StringMap:
    _hx_class_name = "haxe.ds.StringMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/StringMap.hx:32
        self.h = dict()

    def set(self,key,value):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/StringMap.hx:36
        self.h[key] = value

    def get(self,key):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/StringMap.hx:40
        return self.h.get(key,None)

    def keys(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/StringMap.hx:55
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_StringMap._hx_class = haxe_ds_StringMap


class _Defs_Defs_Fields_:
    _hx_class_name = "_Defs.Defs_Fields_"
    __slots__ = ()
    _hx_statics = ["fn_indices", "baseurl", "defaults", "ui_tags"]
_Defs_Defs_Fields_._hx_class = _Defs_Defs_Fields_


class EReg:
    _hx_class_name = "EReg"
    __slots__ = ("pattern", "matchObj", "_hx_global")
    _hx_fields = ["pattern", "matchObj", "global"]

    def __init__(self,r,opt):
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:31
        self.matchObj = None
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:35
        self._hx_global = False
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:36
        options = 0
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:37
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:37
        _g = 0
        _g1 = len(opt)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:38
            c = (-1 if ((i >= len(opt))) else ord(opt[i]))
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:39
            if (c == 109):
                options = (options | python_lib_Re.M)
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:41
            if (c == 105):
                options = (options | python_lib_Re.I)
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:43
            if (c == 115):
                options = (options | python_lib_Re.S)
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:45
            if (c == 117):
                options = (options | python_lib_Re.U)
            # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:47
            if (c == 103):
                self._hx_global = True
        # C:\HaxeToolkit\haxe\std/python/_std/EReg.hx:50
        self.pattern = python_lib_Re.compile(r,options)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.pattern = None
        _hx_o.matchObj = None
        _hx_o._hx_global = None
EReg._hx_class = EReg


class Lambda:
    _hx_class_name = "Lambda"
    __slots__ = ()
    _hx_statics = ["exists"]

    @staticmethod
    def exists(it,f):
        # C:\HaxeToolkit\haxe\std/Lambda.hx:126
        # C:\HaxeToolkit\haxe\std/Lambda.hx:126
        x = HxOverrides.iterator(it)
        while x.hasNext():
            x1 = x.next()
            # C:\HaxeToolkit\haxe\std/Lambda.hx:127
            if f(x1):
                return True
        # C:\HaxeToolkit\haxe\std/Lambda.hx:129
        return False
Lambda._hx_class = Lambda


class host_Docker(DockWidget):
    _hx_class_name = "host.Docker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canvasChanged"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = DockWidget


    def __init__(self):
        # src/host/Docker.hx:7
        super().__init__()

    def canvasChanged(self,canvas):
        pass

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
host_Docker._hx_class = host_Docker


class hxasync_Asyncable:
    _hx_class_name = "hxasync.Asyncable"
    __slots__ = ()
hxasync_Asyncable._hx_class = hxasync_Asyncable


class MyDocker(host_Docker):
    _hx_class_name = "MyDocker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["generate2", "generate"]
    _hx_statics = ["__meta__", "checkReady"]
    _hx_interfaces = [hxasync_Asyncable]
    _hx_super = host_Docker


    def __init__(self):
        # src/MyDocker.hx:26
        super().__init__()
        # src/MyDocker.hx:28
        host_App.init(self)
        # src/MyDocker.hx:31
        # src/MyDocker.hx:31
        mode = _Defs_Defs_Fields_.ui_tags.keys()
        while mode.hasNext():
            mode1 = mode.next()
            # src/MyDocker.hx:32
            print(str(mode1))
            # src/MyDocker.hx:33
            print(str(len(_Defs_Defs_Fields_.defaults.h.get(mode1,None))))
            # src/MyDocker.hx:34
            print(str(len(_Defs_Defs_Fields_.ui_tags.h.get(mode1,None))))

    def generate2(self,mode,form):
        # src/MyDocker.hx:40
        ready = MyDocker.checkReady(mode)
        # src/MyDocker.hx:42
        if ready:
            # src/MyDocker.hx:47
            if (mode == "inpaint"):
                host_UI.is_inpainting = 1
            else:
                host_UI.is_inpainting = 0
            # src/MyDocker.hx:50
            host_UI.toast(("READY - Generating " + ("null" if mode is None else mode)))
            # src/MyDocker.hx:51
            apidata = []
            # src/MyDocker.hx:54
            # src/MyDocker.hx:54
            _g = 0
            _g1 = len(form)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # src/MyDocker.hx:55
                if (Reflect.field((form[i] if i >= 0 and i < len(form) else None),"getter") is not None):
                    # src/MyDocker.hx:57
                    p = Reflect.field((form[i] if i >= 0 and i < len(form) else None),"getter")()
                    # src/MyDocker.hx:58
                    apidata.append(p)
                else:
                    # src/MyDocker.hx:60
                    print("no getter - defaulting")
                    # src/MyDocker.hx:62
                    print(str((form[i] if i >= 0 and i < len(form) else None)))
                    # src/MyDocker.hx:63
                    try:
                        # src/MyDocker.hx:64
                        props = Reflect.field((form[i] if i >= 0 and i < len(form) else None),"props")
                        # src/MyDocker.hx:65
                        # src/MyDocker.hx:65
                        x = Reflect.field(props,"value")
                        apidata.append(x)
                    except BaseException as _g2:
                        # src/MyDocker.hx:66
                        e = haxe_Exception.caught(_g2)
                        print(str(e))
            # src/MyDocker.hx:71
            print(str(apidata))
            # src/MyDocker.hx:74
            Utils.request(mode,apidata)

    def generate(self,mode):
        # src/MyDocker.hx:80
        ready = MyDocker.checkReady(mode)
        # src/MyDocker.hx:82
        if ready:
            # src/MyDocker.hx:86
            host_UI.toast(("READY - Generating " + ("null" if mode is None else mode)))
            # src/MyDocker.hx:87
            apidata = []
            # src/MyDocker.hx:90
            # src/MyDocker.hx:90
            _g = 0
            _g1 = len(_Defs_Defs_Fields_.defaults.h.get(mode,None))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # src/MyDocker.hx:91
                if (python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i) is not None):
                    # src/MyDocker.hx:92
                    print(str(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i)))
                    # src/MyDocker.hx:93
                    p = host_UI.gatherParameter(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i))
                    # src/MyDocker.hx:94
                    print(str(p))
                    # src/MyDocker.hx:95
                    apidata.append(p)
                else:
                    # src/MyDocker.hx:99
                    x = python_internal_ArrayImpl._get(_Defs_Defs_Fields_.defaults.h.get(mode,None), i)
                    apidata.append(x)
            # src/MyDocker.hx:105
            Utils.request(mode,apidata)

    @staticmethod
    def checkReady(mode):
        # src/MyDocker.hx:112
        state = host_App.getDocumentState()
        # src/MyDocker.hx:113
        if (Reflect.field(state,"selection") is None):
            # src/MyDocker.hx:115
            selection = _hx_AnonObject({'x': 0, 'y': 0, 'width': 512, 'height': 512})
            # src/MyDocker.hx:116
            Reflect.setField(state,"selection",selection)
            # src/MyDocker.hx:117
            host_App.setDocumentState(state)
            # src/MyDocker.hx:118
            host_UI.toast("NOT READY: no selection existed - defaulted to 512x512")
            # src/MyDocker.hx:119
            return False
        elif ((HxOverrides.mod(Reflect.field(state,"selection").width, 64) != 0) or ((HxOverrides.mod(Reflect.field(state,"selection").height, 64) != 0))):
            # src/MyDocker.hx:122
            host_UI.toast("NOT READY: resized selection to multiples of 64")
            # src/MyDocker.hx:123
            x = (Reflect.field(state,"selection").width / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:128
                None
                # src/MyDocker.hx:123
                tmp = None
            Reflect.field(state,"selection").width = (64 * ((1 + tmp)))
            # src/MyDocker.hx:124
            x = (Reflect.field(state,"selection").height / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:128
                None
                # src/MyDocker.hx:124
                tmp = None
            Reflect.field(state,"selection").height = (64 * ((1 + tmp)))
            # src/MyDocker.hx:125
            host_App.setDocumentState(state)
            # src/MyDocker.hx:126
            return False
        # src/MyDocker.hx:130
        if (mode == "inpaint"):
            # src/MyDocker.hx:131
            mask = host_Image.layerByName("!sdmask")
            # src/MyDocker.hx:132
            if (mask is None):
                # src/MyDocker.hx:133
                host_UI.toast("mask needed - created visible layer called !sdmask")
                # src/MyDocker.hx:140
                mask = Krita.instance().activeDocument().createNode("!sdmask","paintlayer")
                # src/MyDocker.hx:141
                mask.setOpacity(128)
                # src/MyDocker.hx:142
                col_white = ManagedColor("RGBA","U8","")
                # src/MyDocker.hx:143
                col_white.setComponents([1.0, 1.0, 1.0, 1.0])
                # src/MyDocker.hx:144
                Krita.instance().activeWindow().activeView().setForeGroundColor(col_white)
                # src/MyDocker.hx:145
                Krita.instance().activeDocument().activeNode().parentNode().addChildNode(mask,python_internal_ArrayImpl._get(Krita.instance().activeDocument().topLevelNodes(), -1))
                # src/MyDocker.hx:147
                Krita.instance().activeDocument().setActiveNode(mask)
                # src/MyDocker.hx:156
                return False
        # src/MyDocker.hx:160
        return True

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
MyDocker._hx_class = MyDocker


class MyExtension(Extension):
    _hx_class_name = "MyExtension"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = Extension


    def __init__(self,parent = None):
        # src/MyDocker.hx:170
        super().__init__(parent)
MyExtension._hx_class = MyExtension


class Reflect:
    _hx_class_name = "Reflect"
    __slots__ = ()
    _hx_statics = ["field", "setField", "getProperty", "isFunction", "compareMethods", "copy"]

    @staticmethod
    def field(o,field):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:43
        return python_Boot.field(o,field)

    @staticmethod
    def setField(o,field,value):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:48
        setattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)),value)

    @staticmethod
    def getProperty(o,field):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:52
        if (o is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:55
        if (field in python_Boot.keywords):
            field = ("_hx_" + field)
        elif ((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95))):
            field = ("_hx_" + field)
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:56
        if isinstance(o,_hx_AnonObject):
            return Reflect.field(o,field)
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:58
        tmp = Reflect.field(o,("get_" + ("null" if field is None else field)))
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:59
        if ((tmp is not None) and callable(tmp)):
            return tmp()
        else:
            return Reflect.field(o,field)

    @staticmethod
    def isFunction(f):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:84
        if (not ((python_lib_Inspect.isfunction(f) or python_lib_Inspect.ismethod(f)))):
            return python_Boot.hasField(f,"func_code")
        else:
            return True

    @staticmethod
    def compareMethods(f1,f2):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:98
        if HxOverrides.eq(f1,f2):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:100
        if (isinstance(f1,python_internal_MethodClosure) and isinstance(f2,python_internal_MethodClosure)):
            # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:101
            m1 = f1
            # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:102
            m2 = f2
            # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:103
            if HxOverrides.eq(m1.obj,m2.obj):
                return (m1.func == m2.func)
            else:
                return False
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:105
        if ((not Reflect.isFunction(f1)) or (not Reflect.isFunction(f2))):
            return False
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:108
        return False

    @staticmethod
    def copy(o):
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:131
        if (o is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:133
        o2 = _hx_AnonObject({})
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:134
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:134
        _g = 0
        _g1 = python_Boot.fields(o)
        while (_g < len(_g1)):
            f = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:135
            # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:135
            value = Reflect.field(o,f)
            setattr(o2,(("_hx_" + f) if ((f in python_Boot.keywords)) else (("_hx_" + f) if (((((len(f) > 2) and ((ord(f[0]) == 95))) and ((ord(f[1]) == 95))) and ((ord(f[(len(f) - 1)]) != 95)))) else f)),value)
        # C:\HaxeToolkit\haxe\std/python/_std/Reflect.hx:136
        return o2
Reflect._hx_class = Reflect


class Std:
    _hx_class_name = "Std"
    __slots__ = ()
    _hx_statics = ["is", "isOfType", "string", "parseInt"]

    @staticmethod
    def _hx_is(v,t):
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:55
        return Std.isOfType(v,t)

    @staticmethod
    def isOfType(v,t):
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:61
        if ((v is None) and ((t is None))):
            return False
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:64
        if (t is None):
            return False
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:67
        if ((type(t) == type) and (t == Dynamic)):
            return (v is not None)
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:70
        isBool = isinstance(v,bool)
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:72
        if (((type(t) == type) and (t == Bool)) and isBool):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:75
        if ((((not isBool) and (not ((type(t) == type) and (t == Bool)))) and ((type(t) == type) and (t == Int))) and isinstance(v,int)):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:78
        vIsFloat = isinstance(v,float)
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:80
        tmp = None
        tmp1 = None
        if (((not isBool) and vIsFloat) and ((type(t) == type) and (t == Int))):
            f = v
            tmp1 = (((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))
        else:
            tmp1 = False
        if tmp1:
            tmp1 = None
            try:
                tmp1 = int(v)
            except BaseException as _g:
                tmp1 = None
            tmp = (v == tmp1)
        else:
            tmp = False
        if ((tmp and ((v <= 2147483647))) and ((v >= -2147483648))):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:84
        if (((not isBool) and ((type(t) == type) and (t == Float))) and isinstance(v,(float, int))):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:88
        if ((type(t) == type) and (t == str)):
            return isinstance(v,str)
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:91
        isEnumType = ((type(t) == type) and (t == Enum))
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:92
        if ((isEnumType and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_constructs")):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:95
        if isEnumType:
            return False
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:98
        isClassType = ((type(t) == type) and (t == Class))
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:99
        if ((((isClassType and (not isinstance(v,Enum))) and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_class_name")) and (not hasattr(v,"_hx_constructs"))):
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:106
        if isClassType:
            return False
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:109
        tmp = None
        try:
            tmp = isinstance(v,t)
        except BaseException as _g:
            tmp = False
        if tmp:
            return True
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:113
        if python_lib_Inspect.isclass(t):
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:114
            cls = t
            loop = None
            def _hx_local_1(intf):
                f = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                if (f is not None):
                    _g = 0
                    while (_g < len(f)):
                        i = (f[_g] if _g >= 0 and _g < len(f) else None)
                        _g = (_g + 1)
                        if (i == cls):
                            return True
                        else:
                            l = loop(i)
                            if l:
                                return True
                    return False
                else:
                    return False
            loop = _hx_local_1
            currentClass = v.__class__
            result = False
            while (currentClass is not None):
                if loop(currentClass):
                    result = True
                    break
                currentClass = python_Boot.getSuperClass(currentClass)
            return result
        else:
            return False

    @staticmethod
    def string(s):
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:122
        return python_Boot.toString1(s,"")

    @staticmethod
    def parseInt(x):
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:134
        if (x is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:136
        try:
            return int(x)
        except BaseException as _g:
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:139
            base = 10
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:140
            _hx_len = len(x)
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:141
            foundCount = 0
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:142
            sign = 0
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:143
            firstDigitIndex = 0
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:144
            lastDigitIndex = -1
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:145
            previous = 0
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:147
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:147
            _g = 0
            _g1 = _hx_len
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:148
                c = (-1 if ((i >= len(x))) else ord(x[i]))
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:149
                if (((c > 8) and ((c < 14))) or ((c == 32))):
                    # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:151
                    if (foundCount > 0):
                        return None
                    # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:154
                    continue
                else:
                    # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:149
                    c1 = c
                    # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:157
                    if (c1 == 43):
                        if (foundCount == 0):
                            sign = 1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 45):
                        if (foundCount == 0):
                            sign = -1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 48):
                        if (not (((foundCount == 0) or (((foundCount == 1) and ((sign != 0))))))):
                            if (not (((48 <= c) and ((c <= 57))))):
                                if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                    break
                    elif ((c1 == 120) or ((c1 == 88))):
                        if ((previous == 48) and ((((foundCount == 1) and ((sign == 0))) or (((foundCount == 2) and ((sign != 0))))))):
                            base = 16
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (not (((48 <= c) and ((c <= 57))))):
                        if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                            break
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:167
                if (((foundCount == 0) and ((sign == 0))) or (((foundCount == 1) and ((sign != 0))))):
                    firstDigitIndex = i
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:170
                foundCount = (foundCount + 1)
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:171
                lastDigitIndex = i
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:172
                previous = c
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:174
            if (firstDigitIndex <= lastDigitIndex):
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:175
                digits = HxString.substring(x,firstDigitIndex,(lastDigitIndex + 1))
                # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:176
                try:
                    return (((-1 if ((sign == -1)) else 1)) * int(digits,base))
                except BaseException as _g:
                    return None
            # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:182
            return None
Std._hx_class = Std


class Float: pass


class Int: pass


class Bool: pass


class Dynamic: pass


class StringBuf:
    _hx_class_name = "StringBuf"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["get_length"]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:31
        self.b = python_lib_io_StringIO()

    def get_length(self):
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:37
        pos = self.b.tell()
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:38
        self.b.seek(0,2)
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:39
        _hx_len = self.b.tell()
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:40
        self.b.seek(pos,0)
        # C:\HaxeToolkit\haxe\std/python/_std/StringBuf.hx:41
        return _hx_len

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
StringBuf._hx_class = StringBuf


class StringTools:
    _hx_class_name = "StringTools"
    __slots__ = ()
    _hx_statics = ["isSpace", "ltrim", "rtrim", "lpad", "replace"]

    @staticmethod
    def isSpace(s,pos):
        # C:\HaxeToolkit\haxe\std/StringTools.hx:280
        if (((len(s) == 0) or ((pos < 0))) or ((pos >= len(s)))):
            return False
        # C:\HaxeToolkit\haxe\std/StringTools.hx:283
        c = HxString.charCodeAt(s,pos)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:284
        if (not (((c > 8) and ((c < 14))))):
            return (c == 32)
        else:
            return True

    @staticmethod
    def ltrim(s):
        # C:\HaxeToolkit\haxe\std/StringTools.hx:300
        l = len(s)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:301
        r = 0
        # C:\HaxeToolkit\haxe\std/StringTools.hx:302
        while ((r < l) and StringTools.isSpace(s,r)):
            r = (r + 1)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:305
        if (r > 0):
            return HxString.substr(s,r,(l - r))
        else:
            return s

    @staticmethod
    def rtrim(s):
        # C:\HaxeToolkit\haxe\std/StringTools.hx:325
        l = len(s)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:326
        r = 0
        # C:\HaxeToolkit\haxe\std/StringTools.hx:327
        while ((r < l) and StringTools.isSpace(s,((l - r) - 1))):
            r = (r + 1)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:330
        if (r > 0):
            return HxString.substr(s,0,(l - r))
        else:
            return s

    @staticmethod
    def lpad(s,c,l):
        # C:\HaxeToolkit\haxe\std/StringTools.hx:366
        if (len(c) <= 0):
            return s
        # C:\HaxeToolkit\haxe\std/StringTools.hx:369
        buf = StringBuf()
        # C:\HaxeToolkit\haxe\std/StringTools.hx:370
        l = (l - len(s))
        # C:\HaxeToolkit\haxe\std/StringTools.hx:371
        while (buf.get_length() < l):
            # C:\HaxeToolkit\haxe\std/StringTools.hx:372
            s1 = Std.string(c)
            buf.b.write(s1)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:374
        # C:\HaxeToolkit\haxe\std/StringTools.hx:374
        s1 = Std.string(s)
        buf.b.write(s1)
        # C:\HaxeToolkit\haxe\std/StringTools.hx:375
        return buf.b.getvalue()

    @staticmethod
    def replace(s,sub,by):
        # C:\HaxeToolkit\haxe\std/StringTools.hx:424
        _this = (list(s) if ((sub == "")) else s.split(sub))
        return by.join([python_Boot.toString1(x1,'') for x1 in _this])
StringTools._hx_class = StringTools

class ValueType(Enum):
    __slots__ = ()
    _hx_class_name = "ValueType"
    _hx_constructs = ["TNull", "TInt", "TFloat", "TBool", "TObject", "TFunction", "TClass", "TEnum", "TUnknown"]

    @staticmethod
    def TClass(c):
        return ValueType("TClass", 6, (c,))

    @staticmethod
    def TEnum(e):
        return ValueType("TEnum", 7, (e,))
ValueType.TNull = ValueType("TNull", 0, ())
ValueType.TInt = ValueType("TInt", 1, ())
ValueType.TFloat = ValueType("TFloat", 2, ())
ValueType.TBool = ValueType("TBool", 3, ())
ValueType.TObject = ValueType("TObject", 4, ())
ValueType.TFunction = ValueType("TFunction", 5, ())
ValueType.TUnknown = ValueType("TUnknown", 8, ())
ValueType._hx_class = ValueType


class Type:
    _hx_class_name = "Type"
    __slots__ = ()
    _hx_statics = ["getClass", "getSuperClass", "getClassName", "createEmptyInstance", "typeof"]

    @staticmethod
    def getClass(o):
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:44
        if (o is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:47
        o1 = o
        if ((o1 is not None) and ((HxOverrides.eq(o1,str) or python_lib_Inspect.isclass(o1)))):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:50
        if isinstance(o,_hx_AnonObject):
            return None
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:53
        if hasattr(o,"_hx_class"):
            return o._hx_class
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:56
        if hasattr(o,"__class__"):
            return o.__class__
        else:
            return None

    @staticmethod
    def getSuperClass(c):
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:70
        return python_Boot.getSuperClass(c)

    @staticmethod
    def getClassName(c):
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:74
        if hasattr(c,"_hx_class_name"):
            return c._hx_class_name
        else:
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:78
            if (c == list):
                return "Array"
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:80
            if (c == Math):
                return "Math"
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:82
            if (c == str):
                return "String"
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:85
            try:
                return c.__name__
            except BaseException as _g:
                return None

    @staticmethod
    def createEmptyInstance(cl):
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:124
        i = cl.__new__(cl)
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:126
        callInit = None
        def _hx_local_0(cl):
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:127
            sc = Type.getSuperClass(cl)
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:128
            if (sc is not None):
                callInit(sc)
            # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:131
            if hasattr(cl,"_hx_empty_init"):
                cl._hx_empty_init(i)
        callInit = _hx_local_0
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:135
        callInit(cl)
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:137
        return i

    @staticmethod
    def typeof(v):
        # C:\HaxeToolkit\haxe\std/python/_std/Type.hx:180
        if (v is None):
            return ValueType.TNull
        elif isinstance(v,bool):
            return ValueType.TBool
        elif isinstance(v,int):
            return ValueType.TInt
        elif isinstance(v,float):
            return ValueType.TFloat
        elif isinstance(v,str):
            return ValueType.TClass(str)
        elif isinstance(v,list):
            return ValueType.TClass(list)
        elif (isinstance(v,_hx_AnonObject) or python_lib_Inspect.isclass(v)):
            return ValueType.TObject
        elif isinstance(v,Enum):
            return ValueType.TEnum(v.__class__)
        elif (isinstance(v,type) or hasattr(v,"_hx_class")):
            return ValueType.TClass(v.__class__)
        elif callable(v):
            return ValueType.TFunction
        else:
            return ValueType.TUnknown
Type._hx_class = Type


class Utils:
    _hx_class_name = "Utils"
    __slots__ = ()
    _hx_statics = ["__meta__", "params_for_layer", "request", "receive", "fetch_remote_png", "packInfo", "unpackInfo", "fetchAndInsert", "cleanTags", "cleanComponent", "fastdecode64", "fastencode64"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def request(mode,in_data):
        # src/Utils.hx:36
        fn_i = None
        # src/Utils.hx:37
        if (mode == "txt2img"):
            fn_i = host_UI.txt2img_generate_fn_index
        else:
            fn_i = host_UI.img2img_generate_fn_index
        # src/Utils.hx:43
        data_formatted = haxe_format_JsonPrinter.print(_hx_AnonObject({'fn_index': fn_i, 'data': in_data, 'session_hash': None}),None,None)
        # src/Utils.hx:49
        print(str(data_formatted))
        # src/Utils.hx:67
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request('http://127.0.0.1:7860/api/predict')

        body_encoded = data_formatted.encode('utf-8')
        req.data=body_encoded
        req.add_header('Content-Type', 'application/json')
        req.add_header('Content-Length', str(len(body_encoded)))

        with urllib.request.urlopen(req) as res:
            Utils.receive(res.read())

        

    @staticmethod
    def receive(data):
        # src/Utils.hx:88
        print("we get signal")
        # src/Utils.hx:89
        obj = python_lib_Json.loads(data,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        # src/Utils.hx:90
        print(str(obj))
        # src/Utils.hx:92
        prefix = "data:image/png;base64,"
        # src/Utils.hx:93
        string_array = (obj.data[0] if 0 < len(obj.data) else None)
        # src/Utils.hx:95
        response_dict = python_lib_Json.loads((obj.data[1] if 1 < len(obj.data) else None),**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        # src/Utils.hx:99
        # src/Utils.hx:99
        _g = 0
        _g1 = len(string_array)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # src/Utils.hx:100
            finfo = (string_array[i] if i >= 0 and i < len(string_array) else None)
            # src/Utils.hx:101
            name = Utils.packInfo(response_dict)
            # src/Utils.hx:102
            _hx_bytes = Utils.fetch_remote_png(Reflect.field(finfo,"name"))
            # src/Utils.hx:104
            host_Image.layerFromPng(_hx_bytes,name)
            # src/Utils.hx:105
            # src/Utils.hx:105
            _g2 = response_dict
            value = python_Boot._add_dynamic(Reflect.field(_g2,"seed"),1)
            setattr(_g2,(("_hx_" + "seed") if (("seed" in python_Boot.keywords)) else (("_hx_" + "seed") if (((((len("seed") > 2) and ((ord("seed"[0]) == 95))) and ((ord("seed"[1]) == 95))) and ((ord("seed"[(len("seed") - 1)]) != 95)))) else "seed")),value)
            # src/Utils.hx:106
            # src/Utils.hx:106
            _g3 = response_dict
            value1 = python_Boot._add_dynamic(Reflect.field(_g3,"subseed"),1)
            setattr(_g3,(("_hx_" + "subseed") if (("subseed" in python_Boot.keywords)) else (("_hx_" + "subseed") if (((((len("subseed") > 2) and ((ord("subseed"[0]) == 95))) and ((ord("subseed"[1]) == 95))) and ((ord("subseed"[(len("subseed") - 1)]) != 95)))) else "subseed")),value1)
        # src/Utils.hx:108
        host_UI.toast((("OK - Generation finished for " + Std.string(len(string_array))) + " image(s)!"))

    @staticmethod
    def fetch_remote_png(fname):
        # src/Utils.hx:113
        data = None
        # src/Utils.hx:115
        url = ((HxOverrides.stringOrNull(_Defs_Defs_Fields_.baseurl) + "/file=") + ("null" if fname is None else fname))
        # src/Utils.hx:116
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request(url)

        with urllib.request.urlopen(req) as res:
            data = res.read()

        
        # src/Utils.hx:128
        return data

    @staticmethod
    def packInfo(info):
        # src/Utils.hx:154
        info_stripped = _hx_AnonObject({})
        # src/Utils.hx:155
        # src/Utils.hx:155
        _g = 0
        _g1 = python_Boot.fields(info)
        while (_g < len(_g1)):
            key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/Utils.hx:156
            if ((host__UIDefs_UIDefs_Fields_.widgetinfo.h.get(key,None) is not None) and ((Reflect.field(info,key) is not None))):
                # src/Utils.hx:157
                value = Reflect.field(info,key)
                setattr(info_stripped,(("_hx_" + key) if ((key in python_Boot.keywords)) else (("_hx_" + key) if (((((len(key) > 2) and ((ord(key[0]) == 95))) and ((ord(key[1]) == 95))) and ((ord(key[(len(key) - 1)]) != 95)))) else key)),value)
        # src/Utils.hx:160
        print(str(info_stripped))
        # src/Utils.hx:162
        return haxe_format_JsonPrinter.print(info_stripped,None,None)

    @staticmethod
    def unpackInfo(layer):
        # src/Utils.hx:172
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        # src/Utils.hx:173
        host_App.setLayerName(layer,StringTools.replace(layer.name,"Copy of ",""))
        # src/Utils.hx:177
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        # src/Utils.hx:179
        infoextract = layer._internal.name()
        # src/Utils.hx:182
        jsonobj = python_lib_Json.loads(infoextract,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        # src/Utils.hx:184
        return jsonobj

    @staticmethod
    def fetchAndInsert(layer,components):
        # src/Utils.hx:195
        params = Utils.unpackInfo(layer)
        # src/Utils.hx:197
        props = None
        # src/Utils.hx:198
        # src/Utils.hx:198
        _g = 0
        while (_g < len(components)):
            comp = (components[_g] if _g >= 0 and _g < len(components) else None)
            _g = (_g + 1)
            # src/Utils.hx:199
            props = Reflect.field(comp,"props")
            # src/Utils.hx:201
            if (Reflect.field(params,Reflect.field(props,"param_name")) is not None):
                Reflect.field(comp,"setter")(Reflect.field(params,Reflect.field(props,"param_name")))

    @staticmethod
    def cleanTags(tags):
        # src/Utils.hx:211
        _g = 0
        while (_g < len(tags)):
            component = (tags[_g] if _g >= 0 and _g < len(tags) else None)
            _g = (_g + 1)
            # src/Utils.hx:212
            Utils.cleanComponent(component)

    @staticmethod
    def cleanComponent(component):
        # src/Utils.hx:217
        props = Reflect.field(component,"props")
        # src/Utils.hx:218
        if (Reflect.field(props,"label") is not None):
            # src/Utils.hx:219
            value = Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(Reflect.field(props,"label"),"toLowerCase")(),"replace")(" ","_"),"replace")(" ","_"),"replace")(" ","_"),"replace")(" ","_"),"replace")(".",""),"replace")("\n","_")
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)
        else:
            # src/Utils.hx:220
            value = Std.string(Reflect.field(component,"id"))
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)
        # src/Utils.hx:222
        this1 = host__UIDefs_UIDefs_Fields_.parameterNames
        if (Reflect.field(props,"param_name") in this1.h):
            # src/Utils.hx:223
            print(str(Reflect.field(props,"param_name")))
            # src/Utils.hx:224
            # src/Utils.hx:224
            this1 = host__UIDefs_UIDefs_Fields_.parameterNames
            key = Reflect.field(props,"param_name")
            value = this1.h.get(key,None)
            setattr(props,(("_hx_" + "param_name") if (("param_name" in python_Boot.keywords)) else (("_hx_" + "param_name") if (((((len("param_name") > 2) and ((ord("param_name"[0]) == 95))) and ((ord("param_name"[1]) == 95))) and ((ord("param_name"[(len("param_name") - 1)]) != 95)))) else "param_name")),value)

    @staticmethod
    def fastdecode64(data):
        # src/Utils.hx:232
        import base64
        # src/Utils.hx:233
        _hx_bytes = base64.decodebytes(data.encode("utf-8"))
        # src/Utils.hx:239
        return _hx_bytes

    @staticmethod
    def fastencode64(data):
        # src/Utils.hx:250
        return str(data.toBase64(), "utf-8")
Utils._hx_class = Utils


class cloner_Cloner:
    _hx_class_name = "cloner.Cloner"
    __slots__ = ("cache", "classHandles", "stringMapCloner", "intMapCloner")
    _hx_fields = ["cache", "classHandles", "stringMapCloner", "intMapCloner"]
    _hx_methods = ["returnString", "clone", "_clone", "handleAnonymous", "handleClass", "cloneArray", "cloneClass"]

    def __init__(self):
        # lib/cloner/Cloner.hx:12
        self.intMapCloner = None
        # lib/cloner/Cloner.hx:11
        self.stringMapCloner = None
        # lib/cloner/Cloner.hx:10
        self.classHandles = None
        # lib/cloner/Cloner.hx:9
        self.cache = None
        # lib/cloner/Cloner.hx:15
        self.stringMapCloner = cloner_MapCloner(self,haxe_ds_StringMap)
        # lib/cloner/Cloner.hx:16
        self.intMapCloner = cloner_MapCloner(self,haxe_ds_IntMap)
        # lib/cloner/Cloner.hx:17
        self.classHandles = haxe_ds_StringMap()
        # lib/cloner/Cloner.hx:18
        self.classHandles.h["String"] = self.returnString
        # lib/cloner/Cloner.hx:19
        self.classHandles.h["Array"] = self.cloneArray
        # lib/cloner/Cloner.hx:20
        self.classHandles.h["haxe.ds.StringMap"] = self.stringMapCloner.clone
        # lib/cloner/Cloner.hx:21
        self.classHandles.h["haxe.ds.IntMap"] = self.intMapCloner.clone

    def returnString(self,v):
        # lib/cloner/Cloner.hx:25
        return v

    def clone(self,v):
        # lib/cloner/Cloner.hx:29
        self.cache = haxe_ds_ObjectMap()
        # lib/cloner/Cloner.hx:30
        outcome = self._clone(v)
        # lib/cloner/Cloner.hx:31
        self.cache = None
        # lib/cloner/Cloner.hx:32
        return outcome

    def _clone(self,v):
        # lib/cloner/Cloner.hx:47
        if (Type.getClassName(v) is not None):
            return v
        # lib/cloner/Cloner.hx:50
        _g = Type.typeof(v)
        tmp = _g.index
        # lib/cloner/Cloner.hx:52
        if (tmp == 0):
            return None
        elif (tmp == 1):
            return v
        elif (tmp == 2):
            return v
        elif (tmp == 3):
            return v
        elif (tmp == 4):
            return self.handleAnonymous(v)
        elif (tmp == 5):
            return None
        elif (tmp == 6):
            # lib/cloner/Cloner.hx:63
            c = _g.params[0]
            # lib/cloner/Cloner.hx:64
            if (not (v in self.cache.h)):
                self.cache.set(v,self.handleClass(c,v))
            # lib/cloner/Cloner.hx:66
            return self.cache.h.get(v,None)
        elif (tmp == 7):
            # lib/cloner/Cloner.hx:67
            e = _g.params[0]
            # lib/cloner/Cloner.hx:68
            return v
        elif (tmp == 8):
            return None
        else:
            pass

    def handleAnonymous(self,v):
        # lib/cloner/Cloner.hx:75
        properties = python_Boot.fields(v)
        # lib/cloner/Cloner.hx:76
        anonymous = _hx_AnonObject({})
        # lib/cloner/Cloner.hx:77
        # lib/cloner/Cloner.hx:77
        _g = 0
        _g1 = len(properties)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # lib/cloner/Cloner.hx:78
            property = (properties[i] if i >= 0 and i < len(properties) else None)
            # lib/cloner/Cloner.hx:79
            # lib/cloner/Cloner.hx:79
            value = self._clone(Reflect.getProperty(v,property))
            setattr(anonymous,(("_hx_" + property) if ((property in python_Boot.keywords)) else (("_hx_" + property) if (((((len(property) > 2) and ((ord(property[0]) == 95))) and ((ord(property[1]) == 95))) and ((ord(property[(len(property) - 1)]) != 95)))) else property)),value)
        # lib/cloner/Cloner.hx:81
        return anonymous

    def handleClass(self,c,inValue):
        # lib/cloner/Cloner.hx:85
        this1 = self.classHandles
        key = Type.getClassName(c)
        handle = this1.h.get(key,None)
        # lib/cloner/Cloner.hx:86
        if (handle is None):
            handle = self.cloneClass
        # lib/cloner/Cloner.hx:88
        return handle(inValue)

    def cloneArray(self,inValue):
        # lib/cloner/Cloner.hx:92
        array = list(inValue)
        # lib/cloner/Cloner.hx:93
        # lib/cloner/Cloner.hx:93
        _g = 0
        _g1 = len(array)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # lib/cloner/Cloner.hx:94
            python_internal_ArrayImpl._set(array, i, self._clone((array[i] if i >= 0 and i < len(array) else None)))
        # lib/cloner/Cloner.hx:95
        return array

    def cloneClass(self,inValue):
        # lib/cloner/Cloner.hx:99
        outValue = Type.createEmptyInstance(Type.getClass(inValue))
        # lib/cloner/Cloner.hx:100
        fields = python_Boot.fields(inValue)
        # lib/cloner/Cloner.hx:101
        # lib/cloner/Cloner.hx:101
        _g = 0
        _g1 = len(fields)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # lib/cloner/Cloner.hx:102
            field = (fields[i] if i >= 0 and i < len(fields) else None)
            # lib/cloner/Cloner.hx:103
            property = Reflect.getProperty(inValue,field)
            # lib/cloner/Cloner.hx:104
            # lib/cloner/Cloner.hx:104
            value = self._clone(property)
            setattr(outValue,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)),value)
        # lib/cloner/Cloner.hx:106
        return outValue

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.cache = None
        _hx_o.classHandles = None
        _hx_o.stringMapCloner = None
        _hx_o.intMapCloner = None
cloner_Cloner._hx_class = cloner_Cloner


class cloner_MapCloner:
    _hx_class_name = "cloner.MapCloner"
    __slots__ = ("cloner", "type", "noArgs")
    _hx_fields = ["cloner", "type", "noArgs"]
    _hx_methods = ["clone"]

    def __init__(self,cloner,_hx_type):
        # lib/cloner/MapCloner.hx:12
        self.cloner = cloner
        # lib/cloner/MapCloner.hx:13
        self.type = _hx_type
        # lib/cloner/MapCloner.hx:14
        self.noArgs = []

    def clone(self,inValue):
        # lib/cloner/MapCloner.hx:18
        inMap = inValue
        # lib/cloner/MapCloner.hx:19
        _hx_map = self.type(*self.noArgs)
        # lib/cloner/MapCloner.hx:20
        # lib/cloner/MapCloner.hx:20
        key = inMap.keys()
        while key.hasNext():
            key1 = key.next()
            # lib/cloner/MapCloner.hx:21
            _hx_map.set(key1,self.cloner._clone(inMap.get(key1)))
        # lib/cloner/MapCloner.hx:23
        return _hx_map

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.cloner = None
        _hx_o.type = None
        _hx_o.noArgs = None
cloner_MapCloner._hx_class = cloner_MapCloner


class haxe_Exception(Exception):
    _hx_class_name = "haxe.Exception"
    __slots__ = ("_hx___nativeStack", "_hx___skipStack", "_hx___nativeException", "_hx___previousException")
    _hx_fields = ["__nativeStack", "__skipStack", "__nativeException", "__previousException"]
    _hx_methods = ["unwrap", "toString", "get_message", "get_native"]
    _hx_statics = ["caught", "thrown"]
    _hx_interfaces = []
    _hx_super = Exception


    def __init__(self,message,previous = None,native = None):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:21
        self._hx___previousException = None
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:20
        self._hx___nativeException = None
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:18
        self._hx___nativeStack = None
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:19
        self._hx___skipStack = 0
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:46
        super().__init__(message)
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:47
        self._hx___previousException = previous
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:48
        if ((native is not None) and Std.isOfType(native,BaseException)):
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:49
            self._hx___nativeException = native
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:50
            self._hx___nativeStack = haxe_NativeStackTrace.exceptionStack()
        else:
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:52
            self._hx___nativeException = self
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:53
            infos = python_lib_Traceback.extract_stack()
            if (len(infos) != 0):
                infos.pop()
            infos.reverse()
            self._hx___nativeStack = infos

    def unwrap(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:58
        return self._hx___nativeException

    def toString(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:62
        return self.get_message()

    def get_message(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:76
        return str(self)

    def get_native(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:84
        return self._hx___nativeException

    @staticmethod
    def caught(value):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:24
        if Std.isOfType(value,haxe_Exception):
            return value
        elif Std.isOfType(value,BaseException):
            return haxe_Exception(str(value),None,value)
        else:
            return haxe_ValueException(value,None,value)

    @staticmethod
    def thrown(value):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:34
        if Std.isOfType(value,haxe_Exception):
            return value.get_native()
        elif Std.isOfType(value,BaseException):
            return value
        else:
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:39
            e = haxe_ValueException(value)
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:40
            e._hx___skipStack = (e._hx___skipStack + 1)
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/Exception.hx:41
            return e

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___nativeStack = None
        _hx_o._hx___skipStack = None
        _hx_o._hx___nativeException = None
        _hx_o._hx___previousException = None
haxe_Exception._hx_class = haxe_Exception


class haxe_NativeStackTrace:
    _hx_class_name = "haxe.NativeStackTrace"
    __slots__ = ()
    _hx_statics = ["saveStack", "exceptionStack"]

    @staticmethod
    def saveStack(exception):
        pass

    @staticmethod
    def exceptionStack():
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/NativeStackTrace.hx:25
        exc = python_lib_Sys.exc_info()
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/NativeStackTrace.hx:26
        if (exc[2] is not None):
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/NativeStackTrace.hx:27
            infos = python_lib_Traceback.extract_tb(exc[2])
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/NativeStackTrace.hx:28
            infos.reverse()
            # C:\HaxeToolkit\haxe\std/python/_std/haxe/NativeStackTrace.hx:29
            return infos
        else:
            return []
haxe_NativeStackTrace._hx_class = haxe_NativeStackTrace


class haxe_ValueException(haxe_Exception):
    _hx_class_name = "haxe.ValueException"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["unwrap"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,value,previous = None,native = None):
        # C:\HaxeToolkit\haxe\std/haxe/ValueException.hx:21
        self.value = None
        # C:\HaxeToolkit\haxe\std/haxe/ValueException.hx:24
        super().__init__(Std.string(value),previous,native)
        # C:\HaxeToolkit\haxe\std/haxe/ValueException.hx:25
        self.value = value

    def unwrap(self):
        # C:\HaxeToolkit\haxe\std/haxe/ValueException.hx:36
        return self.value

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.value = None
haxe_ValueException._hx_class = haxe_ValueException


class haxe_io_Bytes:
    _hx_class_name = "haxe.io.Bytes"
    __slots__ = ("length", "b")
    _hx_fields = ["length", "b"]
    _hx_methods = ["sub", "getString", "toString"]
    _hx_statics = ["alloc", "ofString"]

    def __init__(self,length,b):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:35
        self.length = length
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:36
        self.b = b

    def sub(self,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:157
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:176
        return haxe_io_Bytes(_hx_len,self.b[pos:(pos + _hx_len)])

    def getString(self,pos,_hx_len,encoding = None):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:416
        tmp = (encoding is None)
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:419
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > self.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:450
        return self.b[pos:pos+_hx_len].decode('UTF-8','replace')

    def toString(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:516
        return self.getString(0,self.length)

    @staticmethod
    def alloc(length):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:566
        return haxe_io_Bytes(length,bytearray(length))

    @staticmethod
    def ofString(s,encoding = None):
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:615
        b = bytearray(s,"UTF-8")
        # C:\HaxeToolkit\haxe\std/haxe/io/Bytes.hx:616
        return haxe_io_Bytes(len(b),b)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.length = None
        _hx_o.b = None
haxe_io_Bytes._hx_class = haxe_io_Bytes


class haxe_ds_IntMap:
    _hx_class_name = "haxe.ds.IntMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/IntMap.hx:32
        self.h = dict()

    def set(self,key,value):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/IntMap.hx:36
        self.h[key] = value

    def get(self,key):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/IntMap.hx:40
        return self.h.get(key,None)

    def keys(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/IntMap.hx:55
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_IntMap._hx_class = haxe_ds_IntMap


class haxe_ds_ObjectMap:
    _hx_class_name = "haxe.ds.ObjectMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["set", "get", "keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/ObjectMap.hx:31
        self.h = dict()

    def set(self,key,value):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/ObjectMap.hx:35
        self.h[key] = value

    def get(self,key):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/ObjectMap.hx:39
        return self.h.get(key,None)

    def keys(self):
        # C:\HaxeToolkit\haxe\std/python/_std/haxe/ds/ObjectMap.hx:54
        return python_HaxeIterator(iter(self.h.keys()))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.h = None
haxe_ds_ObjectMap._hx_class = haxe_ds_ObjectMap


class haxe_exceptions_PosException(haxe_Exception):
    _hx_class_name = "haxe.exceptions.PosException"
    __slots__ = ("posInfos",)
    _hx_fields = ["posInfos"]
    _hx_methods = ["toString"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,message,previous = None,pos = None):
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/PosException.hx:10
        self.posInfos = None
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/PosException.hx:13
        super().__init__(message,previous)
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/PosException.hx:14
        if (pos is None):
            self.posInfos = _hx_AnonObject({'fileName': "(unknown)", 'lineNumber': 0, 'className': "(unknown)", 'methodName': "(unknown)"})
        else:
            self.posInfos = pos

    def toString(self):
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/PosException.hx:25
        return ((((((((("" + HxOverrides.stringOrNull(super().toString())) + " in ") + HxOverrides.stringOrNull(self.posInfos.className)) + ".") + HxOverrides.stringOrNull(self.posInfos.methodName)) + " at ") + HxOverrides.stringOrNull(self.posInfos.fileName)) + ":") + Std.string(self.posInfos.lineNumber))

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.posInfos = None
haxe_exceptions_PosException._hx_class = haxe_exceptions_PosException


class haxe_exceptions_NotImplementedException(haxe_exceptions_PosException):
    _hx_class_name = "haxe.exceptions.NotImplementedException"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_exceptions_PosException


    def __init__(self,message = None,previous = None,pos = None):
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/NotImplementedException.hx:7
        if (message is None):
            message = "Not implemented"
        # C:\HaxeToolkit\haxe\std/haxe/exceptions/NotImplementedException.hx:8
        super().__init__(message,previous,pos)
haxe_exceptions_NotImplementedException._hx_class = haxe_exceptions_NotImplementedException


class haxe_format_JsonPrinter:
    _hx_class_name = "haxe.format.JsonPrinter"
    __slots__ = ("buf", "replacer", "indent", "pretty", "nind")
    _hx_fields = ["buf", "replacer", "indent", "pretty", "nind"]
    _hx_methods = ["write", "classString", "fieldsString", "quote"]
    _hx_statics = ["print"]

    def __init__(self,replacer,space):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:57
        self.replacer = replacer
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:58
        self.indent = space
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:59
        self.pretty = (space is not None)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:60
        self.nind = 0
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:67
        self.buf = StringBuf()

    def write(self,k,v):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:82
        if (self.replacer is not None):
            v = self.replacer(k,v)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:84
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:84
        _g = Type.typeof(v)
        tmp = _g.index
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:136
        if (tmp == 0):
            self.buf.b.write("null")
        elif (tmp == 1):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:90
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 2):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:92
            f = v
            v1 = (Std.string(v) if ((((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))) else "null")
            _this = self.buf
            s = Std.string(v1)
            _this.b.write(s)
        elif (tmp == 3):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:134
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 4):
            self.fieldsString(v,python_Boot.fields(v))
        elif (tmp == 5):
            self.buf.b.write("\"<fun>\"")
        elif (tmp == 6):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:95
            c = _g.params[0]
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:96
            if (c == str):
                self.quote(v)
            elif (c == list):
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:99
                v1 = v
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:100
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:100
                _this = self.buf
                s = "".join(map(chr,[91]))
                _this.b.write(s)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:102
                _hx_len = len(v1)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:103
                last = (_hx_len - 1)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:104
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:104
                _g1 = 0
                _g2 = _hx_len
                while (_g1 < _g2):
                    i = _g1
                    _g1 = (_g1 + 1)
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:105
                    if (i > 0):
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:106
                        _this = self.buf
                        s = "".join(map(chr,[44]))
                        _this.b.write(s)
                    else:
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:108
                        _hx_local_0 = self
                        _hx_local_1 = _hx_local_0.nind
                        _hx_local_0.nind = (_hx_local_1 + 1)
                        _hx_local_1
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:109
                    if self.pretty:
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:109
                        _this1 = self.buf
                        s1 = "".join(map(chr,[10]))
                        _this1.b.write(s1)
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:110
                    if self.pretty:
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:110
                        v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                        _this2 = self.buf
                        s2 = Std.string(v2)
                        _this2.b.write(s2)
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:111
                    self.write(i,(v1[i] if i >= 0 and i < len(v1) else None))
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:112
                    if (i == last):
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:113
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:113
                        _hx_local_2 = self
                        _hx_local_3 = _hx_local_2.nind
                        _hx_local_2.nind = (_hx_local_3 - 1)
                        _hx_local_3
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:114
                        if self.pretty:
                            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:114
                            _this3 = self.buf
                            s3 = "".join(map(chr,[10]))
                            _this3.b.write(s3)
                        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:115
                        if self.pretty:
                            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:115
                            v3 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                            _this4 = self.buf
                            s4 = Std.string(v3)
                            _this4.b.write(s4)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:118
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:118
                _this = self.buf
                s = "".join(map(chr,[93]))
                _this.b.write(s)
            elif (c == haxe_ds_StringMap):
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:120
                v1 = v
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:121
                o = _hx_AnonObject({})
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:122
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:122
                k = v1.keys()
                while k.hasNext():
                    k1 = k.next()
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:123
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:123
                    value = v1.h.get(k1,None)
                    setattr(o,(("_hx_" + k1) if ((k1 in python_Boot.keywords)) else (("_hx_" + k1) if (((((len(k1) > 2) and ((ord(k1[0]) == 95))) and ((ord(k1[1]) == 95))) and ((ord(k1[(len(k1) - 1)]) != 95)))) else k1)),value)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:124
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:124
                v1 = o
                self.fieldsString(v1,python_Boot.fields(v1))
            elif (c == Date):
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:126
                v1 = v
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:127
                self.quote(v1.toString())
            else:
                self.classString(v)
        elif (tmp == 7):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:130
            _g1 = _g.params[0]
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:131
            i = v.index
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:132
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:132
            _this = self.buf
            s = Std.string(i)
            _this.b.write(s)
        elif (tmp == 8):
            self.buf.b.write("\"???\"")
        else:
            pass

    def classString(self,v):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:158
        self.fieldsString(v,python_Boot.getInstanceFields(Type.getClass(v)))

    def fieldsString(self,v,fields):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:166
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:166
        _this = self.buf
        s = "".join(map(chr,[123]))
        _this.b.write(s)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:167
        _hx_len = len(fields)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:168
        last = (_hx_len - 1)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:169
        first = True
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:170
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:170
        _g = 0
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:171
            f = (fields[i] if i >= 0 and i < len(fields) else None)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:172
            value = Reflect.field(v,f)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:173
            if Reflect.isFunction(value):
                continue
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:175
            if first:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:176
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:176
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.nind
                _hx_local_0.nind = (_hx_local_1 + 1)
                _hx_local_1
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:177
                first = False
            else:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:179
                _this = self.buf
                s = "".join(map(chr,[44]))
                _this.b.write(s)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:180
            if self.pretty:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:180
                _this1 = self.buf
                s1 = "".join(map(chr,[10]))
                _this1.b.write(s1)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:181
            if self.pretty:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:181
                v1 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                _this2 = self.buf
                s2 = Std.string(v1)
                _this2.b.write(s2)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:182
            self.quote(f)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:183
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:183
            _this3 = self.buf
            s3 = "".join(map(chr,[58]))
            _this3.b.write(s3)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:184
            if self.pretty:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:185
                _this4 = self.buf
                s4 = "".join(map(chr,[32]))
                _this4.b.write(s4)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:186
            self.write(f,value)
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:187
            if (i == last):
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:188
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:188
                _hx_local_2 = self
                _hx_local_3 = _hx_local_2.nind
                _hx_local_2.nind = (_hx_local_3 - 1)
                _hx_local_3
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:189
                if self.pretty:
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:189
                    _this5 = self.buf
                    s5 = "".join(map(chr,[10]))
                    _this5.b.write(s5)
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:190
                if self.pretty:
                    # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:190
                    v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                    _this6 = self.buf
                    s6 = Std.string(v2)
                    _this6.b.write(s6)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:193
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:193
        _this = self.buf
        s = "".join(map(chr,[125]))
        _this.b.write(s)

    def quote(self,s):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:203
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:203
        _this = self.buf
        s1 = "".join(map(chr,[34]))
        _this.b.write(s1)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:204
        i = 0
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:205
        length = len(s)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:209
        while (i < length):
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:210
            index = i
            i = (i + 1)
            c = ord(s[index])
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:211
            c1 = c
            # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:223
            if (c1 == 8):
                self.buf.b.write("\\b")
            elif (c1 == 9):
                self.buf.b.write("\\t")
            elif (c1 == 10):
                self.buf.b.write("\\n")
            elif (c1 == 12):
                self.buf.b.write("\\f")
            elif (c1 == 13):
                self.buf.b.write("\\r")
            elif (c1 == 34):
                self.buf.b.write("\\\"")
            elif (c1 == 92):
                self.buf.b.write("\\\\")
            else:
                # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:248
                _this = self.buf
                s1 = "".join(map(chr,[c]))
                _this.b.write(s1)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:256
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:256
        _this = self.buf
        s = "".join(map(chr,[34]))
        _this.b.write(s)

    @staticmethod
    def print(o,replacer = None,space = None):
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:45
        printer = haxe_format_JsonPrinter(replacer,space)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:46
        printer.write("",o)
        # C:\HaxeToolkit\haxe\std/haxe/format/JsonPrinter.hx:47
        return printer.buf.b.getvalue()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.buf = None
        _hx_o.replacer = None
        _hx_o.indent = None
        _hx_o.pretty = None
        _hx_o.nind = None
haxe_format_JsonPrinter._hx_class = haxe_format_JsonPrinter


class haxe_http_HttpBase:
    _hx_class_name = "haxe.http.HttpBase"
    _hx_fields = ["url", "responseBytes", "responseAsString", "postData", "postBytes", "headers", "params", "emptyOnData"]
    _hx_methods = ["addHeader", "setPostData", "onData", "onBytes", "onError", "onStatus", "hasOnData", "success", "get_responseData"]

    def __init__(self,url):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:58
        self.emptyOnData = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:54
        self.postBytes = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:53
        self.postData = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:52
        self.responseAsString = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:50
        self.responseBytes = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:72
        self.url = url
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:73
        self.headers = []
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:74
        self.params = []
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:75
        self.emptyOnData = self.onData

    def addHeader(self,header,value):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:99
        _this = self.headers
        _this.append(_hx_AnonObject({'name': header, 'value': value}))

    def setPostData(self,data):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:143
        self.postData = data
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:144
        self.postBytes = None

    def onData(self,data):
        pass

    def onBytes(self,data):
        pass

    def onError(self,msg):
        pass

    def onStatus(self,status):
        pass

    def hasOnData(self):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:229
        return (not Reflect.compareMethods(self.onData,self.emptyOnData))

    def success(self,data):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:233
        self.responseBytes = data
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:234
        self.responseAsString = None
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:235
        if self.hasOnData():
            self.onData(self.get_responseData())
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:238
        self.onBytes(self.responseBytes)

    def get_responseData(self):
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:242
        if ((self.responseAsString is None) and ((self.responseBytes is not None))):
            self.responseAsString = self.responseBytes.getString(0,self.responseBytes.length,haxe_io_Encoding.UTF8)
        # C:\HaxeToolkit\haxe\std/haxe/http/HttpBase.hx:249
        return self.responseAsString

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.url = None
        _hx_o.responseBytes = None
        _hx_o.responseAsString = None
        _hx_o.postData = None
        _hx_o.postBytes = None
        _hx_o.headers = None
        _hx_o.params = None
        _hx_o.emptyOnData = None
haxe_http_HttpBase._hx_class = haxe_http_HttpBase


class haxe_io_BytesBuffer:
    _hx_class_name = "haxe.io.BytesBuffer"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["getBytes"]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesBuffer.hx:58
        self.b = bytearray()

    def getBytes(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesBuffer.hx:216
        _hx_bytes = haxe_io_Bytes(len(self.b),self.b)
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesBuffer.hx:222
        self.b = None
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesBuffer.hx:223
        return _hx_bytes

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
haxe_io_BytesBuffer._hx_class = haxe_io_BytesBuffer


class haxe_io_Output:
    _hx_class_name = "haxe.io.Output"
    __slots__ = ("bigEndian",)
    _hx_fields = ["bigEndian"]
    _hx_methods = ["writeByte", "writeBytes", "close", "set_bigEndian", "writeFullBytes", "prepare", "writeString"]

    def writeByte(self,c):
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:47
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Output.hx", 'lineNumber': 47, 'className': "haxe.io.Output", 'methodName': "writeByte"}))

    def writeBytes(self,s,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:59
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:62
        b = s.b
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:63
        k = _hx_len
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:64
        while (k > 0):
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:74
            self.writeByte(b[pos])
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:76
            pos = (pos + 1)
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:77
            k = (k - 1)
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:79
        return _hx_len

    def close(self):
        pass

    def set_bigEndian(self,b):
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:95
        self.bigEndian = b
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:96
        return b

    def writeFullBytes(self,s,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:121
        while (_hx_len > 0):
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:122
            k = self.writeBytes(s,pos,_hx_len)
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:123
            pos = (pos + k)
            # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:124
            _hx_len = (_hx_len - k)

    def prepare(self,nbytes):
        pass

    def writeString(self,s,encoding = None):
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:282
        b = haxe_io_Bytes.ofString(s,encoding)
        # C:\HaxeToolkit\haxe\std/haxe/io/Output.hx:284
        self.writeFullBytes(b,0,b.length)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.bigEndian = None
haxe_io_Output._hx_class = haxe_io_Output


class haxe_io_BytesOutput(haxe_io_Output):
    _hx_class_name = "haxe.io.BytesOutput"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["writeByte", "writeBytes", "getBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:40
        self.b = haxe_io_BytesBuffer()
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:43
        self.set_bigEndian(False)

    def writeByte(self,c):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:55
        self.b.b.append(c)

    def writeBytes(self,buf,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:65
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:65
        _this = self.b
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > buf.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        _this.b.extend(buf.b[pos:(pos + _hx_len)])
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:67
        return _hx_len

    def getBytes(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/BytesOutput.hx:143
        return self.b.getBytes()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.b = None
haxe_io_BytesOutput._hx_class = haxe_io_BytesOutput

class haxe_io_Encoding(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Encoding"
    _hx_constructs = ["UTF8", "RawNative"]
haxe_io_Encoding.UTF8 = haxe_io_Encoding("UTF8", 0, ())
haxe_io_Encoding.RawNative = haxe_io_Encoding("RawNative", 1, ())
haxe_io_Encoding._hx_class = haxe_io_Encoding


class haxe_io_Eof:
    _hx_class_name = "haxe.io.Eof"
    __slots__ = ()
    _hx_methods = ["toString"]

    def __init__(self):
        pass

    def toString(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/Eof.hx:33
        return "Eof"

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_io_Eof._hx_class = haxe_io_Eof

class haxe_io_Error(Enum):
    __slots__ = ()
    _hx_class_name = "haxe.io.Error"
    _hx_constructs = ["Blocked", "Overflow", "OutsideBounds", "Custom"]

    @staticmethod
    def Custom(e):
        return haxe_io_Error("Custom", 3, (e,))
haxe_io_Error.Blocked = haxe_io_Error("Blocked", 0, ())
haxe_io_Error.Overflow = haxe_io_Error("Overflow", 1, ())
haxe_io_Error.OutsideBounds = haxe_io_Error("OutsideBounds", 2, ())
haxe_io_Error._hx_class = haxe_io_Error


class haxe_io_Input:
    _hx_class_name = "haxe.io.Input"
    __slots__ = ()
    _hx_methods = ["readByte", "readBytes"]

    def readByte(self):
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:53
        raise haxe_exceptions_NotImplementedException(None,None,_hx_AnonObject({'fileName': "haxe/io/Input.hx", 'lineNumber': 53, 'className': "haxe.io.Input", 'methodName': "readByte"}))

    def readBytes(self,s,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:65
        k = _hx_len
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:66
        b = s.b
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:67
        if (((pos < 0) or ((_hx_len < 0))) or (((pos + _hx_len) > s.length))):
            raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:69
        try:
            while (k > 0):
                # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:78
                b[pos] = self.readByte()
                # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:80
                pos = (pos + 1)
                # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:81
                k = (k - 1)
        except BaseException as _g:
            if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                raise _g
        # C:\HaxeToolkit\haxe\std/haxe/io/Input.hx:84
        return (_hx_len - k)

    @staticmethod
    def _hx_empty_init(_hx_o):        pass
haxe_io_Input._hx_class = haxe_io_Input


class haxe_iterators_ArrayIterator:
    _hx_class_name = "haxe.iterators.ArrayIterator"
    __slots__ = ("array", "current")
    _hx_fields = ["array", "current"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:30
        self.current = 0
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:37
        self.array = array

    def hasNext(self):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:45
        return (self.current < len(self.array))

    def next(self):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:53
        def _hx_local_3():
            # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:53
            def _hx_local_2():
                # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayIterator.hx:53
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return python_internal_ArrayImpl._get(self.array, _hx_local_2())
        return _hx_local_3()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.array = None
        _hx_o.current = None
haxe_iterators_ArrayIterator._hx_class = haxe_iterators_ArrayIterator


class haxe_iterators_ArrayKeyValueIterator:
    _hx_class_name = "haxe.iterators.ArrayKeyValueIterator"
    __slots__ = ("current", "array")
    _hx_fields = ["current", "array"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:27
        self.current = 0
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:32
        self.array = array

    def hasNext(self):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:37
        return (self.current < len(self.array))

    def next(self):
        # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:42
        def _hx_local_3():
            # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:42
            def _hx_local_2():
                # C:\HaxeToolkit\haxe\std/haxe/iterators/ArrayKeyValueIterator.hx:42
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return _hx_AnonObject({'value': python_internal_ArrayImpl._get(self.array, self.current), 'key': _hx_local_2()})
        return _hx_local_3()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.current = None
        _hx_o.array = None
haxe_iterators_ArrayKeyValueIterator._hx_class = haxe_iterators_ArrayKeyValueIterator


class host_App:
    _hx_class_name = "host.App"
    __slots__ = ()
    _hx_statics = ["__meta__", "gradio_components", "gradio_dependencies", "init", "getDocumentState", "setDocumentState", "setLayerName", "docker"]
    _hx_interfaces = [hxasync_Asyncable]
    docker = None

    @staticmethod
    def init(v):
        # src/host/App.hx:42
        host_App.docker = v
        # src/host/App.hx:45
        req = sys_Http((HxOverrides.stringOrNull(_Defs_Defs_Fields_.baseurl) + "/"))
        # src/host/App.hx:47
        def _hx_local_15(data_out):
            # src/host/App.hx:49
            _this = HxOverrides.arrayGet(data_out.split("<script>window.gradio_config = "), 1)
            gradio_props = python_lib_Json.loads(python_internal_ArrayImpl._get(_this.split(";</script>"), 0),**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
            # src/host/App.hx:50
            host_App.gradio_components = Reflect.field(gradio_props,"components")
            # src/host/App.hx:52
            def _hx_local_0(a,b):
                # src/host/App.hx:52
                x = (Reflect.field(a,"id") - Reflect.field(b,"id"))
                try:
                    return int(x)
                except BaseException as _g:
                    # C:\HaxeToolkit\haxe\std/python/_std/Std.hx:128
                    None
                    # src/host/App.hx:52
                    return None
            host_App.gradio_components.sort(key= python_lib_Functools.cmp_to_key(_hx_local_0))
            # src/host/App.hx:56
            # src/host/App.hx:56
            _g = 0
            _g1 = host_App.gradio_components
            while (_g < len(_g1)):
                component = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/App.hx:57
                comp = component
                # src/host/App.hx:58
                props = Reflect.field(comp,"props")
                # src/host/App.hx:59
                if (Reflect.field(props,"elem_id") == "txt2img_generate"):
                    host_UI.txt2img_generate_fn_index = Reflect.field(comp,"id")
            # src/host/App.hx:63
            dep = None
            # src/host/App.hx:64
            dependencies = Reflect.field(gradio_props,"dependencies")
            # src/host/App.hx:69
            # src/host/App.hx:69
            _g = 0
            _g1 = len(dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # src/host/App.hx:70
                dep = (dependencies[i] if i >= 0 and i < len(dependencies) else None)
                # src/host/App.hx:71
                if (HxOverrides.arrayGet(Reflect.field(dep,"targets"), 0) == host_UI.txt2img_generate_fn_index):
                    # src/host/App.hx:72
                    host_UI.txt2img_data_inputs = Reflect.field(dep,"inputs")
                    # src/host/App.hx:73
                    host_UI.txt2img_data_outputs = Reflect.field(dep,"outputs")
                    # src/host/App.hx:74
                    host_UI.txt2img_generate_fn_index = i
                    # src/host/App.hx:75
                    break
            # src/host/App.hx:83
            # src/host/App.hx:83
            _g = 0
            _g1 = host_UI.txt2img_data_inputs
            while (_g < len(_g1)):
                id = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                # src/host/App.hx:84
                # src/host/App.hx:84
                _this = host_UI.tags.h.get("txt2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_4(id):
                    def _hx_local_3(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_3
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_4(id),_this1)), 0)
                _this.append(x)
            # src/host/App.hx:88
            # src/host/App.hx:88
            _g = 0
            _g1 = host_UI.txt2img_data_outputs
            while (_g < len(_g1)):
                id1 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                # src/host/App.hx:89
                # src/host/App.hx:89
                _this = host_UI.tags.h.get("txt2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_7(id):
                    def _hx_local_6(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_6
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_7(id1),_this1)), 0)
                _this.append(x)
            # src/host/App.hx:92
            print(str(host_UI.tags.h.get("txt2img",None)))
            # src/host/App.hx:97
            # src/host/App.hx:97
            _g = 0
            _g1 = host_App.gradio_components
            while (_g < len(_g1)):
                component = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/App.hx:98
                comp = component
                # src/host/App.hx:99
                props = Reflect.field(comp,"props")
                # src/host/App.hx:100
                if (Reflect.field(props,"elem_id") == "img2img_generate"):
                    # src/host/App.hx:101
                    host_UI.img2img_generate_fn_index = Reflect.field(comp,"id")
                    # src/host/App.hx:102
                    print(str(comp))
            # src/host/App.hx:105
            dep = None
            # src/host/App.hx:106
            host_App.gradio_dependencies = Reflect.field(gradio_props,"dependencies")
            # src/host/App.hx:111
            # src/host/App.hx:111
            _g = 0
            _g1 = len(host_App.gradio_dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # src/host/App.hx:112
                dep = python_internal_ArrayImpl._get(host_App.gradio_dependencies, i)
                # src/host/App.hx:113
                if (HxOverrides.arrayGet(Reflect.field(dep,"targets"), 0) == host_UI.img2img_generate_fn_index):
                    # src/host/App.hx:114
                    host_UI.img2img_data_inputs = Reflect.field(dep,"inputs")
                    # src/host/App.hx:115
                    host_UI.img2img_data_outputs = Reflect.field(dep,"outputs")
                    # src/host/App.hx:116
                    host_UI.img2img_generate_fn_index = i
                    # src/host/App.hx:117
                    break
            # src/host/App.hx:124
            # src/host/App.hx:124
            _g = 0
            _g1 = host_UI.img2img_data_inputs
            while (_g < len(_g1)):
                id2 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                # src/host/App.hx:125
                # src/host/App.hx:125
                _this = host_UI.tags.h.get("img2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_11(id):
                    def _hx_local_10(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_10
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_11(id2),_this1)), 0)
                _this.append(x)
            # src/host/App.hx:129
            # src/host/App.hx:129
            _g = 0
            _g1 = host_UI.img2img_data_outputs
            while (_g < len(_g1)):
                id3 = [(_g1[_g] if _g >= 0 and _g < len(_g1) else None)]
                _g = (_g + 1)
                # src/host/App.hx:130
                # src/host/App.hx:130
                _this = host_UI.tags.h.get("img2img",None)
                _this1 = host_App.gradio_components
                def _hx_local_14(id):
                    def _hx_local_13(a):
                        return (Reflect.field(a,"id") == (id[0] if 0 < len(id) else None))
                    return _hx_local_13
                x = python_internal_ArrayImpl._get(list(filter(_hx_local_14(id3),_this1)), 0)
                _this.append(x)
            # src/host/App.hx:134
            print(str(host_UI.tags.h.get("img2img",None)))
            # src/host/App.hx:137
            host_UI.createInterface()
        req.onData = _hx_local_15
        # src/host/App.hx:140
        req.request(False)
        # src/host/App.hx:143
        v.setWindowTitle("Defuser")

    @staticmethod
    def getDocumentState():
        # src/host/App.hx:151
        d = Krita.instance().activeDocument()
        # src/host/App.hx:152
        if (d is None):
            # src/host/App.hx:153
            print("returning 3none")
            # src/host/App.hx:154
            state = _hx_AnonObject({'document': None, 'layer': None, 'selection': None})
            # src/host/App.hx:155
            return state
        # src/host/App.hx:157
        n = d.activeNode()
        # src/host/App.hx:158
        layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
        # src/host/App.hx:159
        s = d.selection()
        # src/host/App.hx:160
        selection = None
        # src/host/App.hx:161
        if (s is not None):
            selection = _hx_AnonObject({'x': s.x(), 'y': s.y(), 'width': s.width(), 'height': s.height()})
        # src/host/App.hx:167
        state = _hx_AnonObject({'document': d, 'layer': layer, 'selection': selection})
        # src/host/App.hx:168
        return state

    @staticmethod
    def setDocumentState(state):
        # src/host/App.hx:177
        s = Selection()
        # src/host/App.hx:178
        s.select(Reflect.field(state,"selection").x,Reflect.field(state,"selection").y,Reflect.field(state,"selection").width,Reflect.field(state,"selection").height,255)
        # src/host/App.hx:179
        Krita.instance().activeDocument().setSelection(s)

    @staticmethod
    def setLayerName(layer,layer_name):
        # src/host/App.hx:188
        layer._internal.setName(layer_name)
host_App._hx_class = host_App


class host__Docker_Docker_Fields_:
    _hx_class_name = "host._Docker.Docker_Fields_"
    __slots__ = ()
    _hx_statics = ["myDocker"]
    myDocker = None
host__Docker_Docker_Fields_._hx_class = host__Docker_Docker_Fields_


class host_Image:
    _hx_class_name = "host.Image"
    __slots__ = ()
    _hx_statics = ["layerByName", "pngFromSelection", "layerFromPng"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def layerByName(name):
        # src/host/Image.python.hx:20
        n = Krita.instance().activeDocument().nodeByName(name)
        # src/host/Image.python.hx:21
        if (n is not None):
            # src/host/Image.python.hx:22
            layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
            # src/host/Image.python.hx:23
            return layer
        else:
            return None

    @staticmethod
    def pngFromSelection(s,layer = None):
        # src/host/Image.python.hx:30
        d = Krita.instance().activeDocument()
        # src/host/Image.python.hx:31
        d.refreshProjection()
        # src/host/Image.python.hx:33
        pixel_data = None
        # src/host/Image.python.hx:34
        if (layer is not None):
            # src/host/Image.python.hx:35
            n = Krita.instance().activeDocument().nodeByName(layer.name)
            # src/host/Image.python.hx:36
            pixel_data = n.pixelData(s.x,s.y,s.width,s.height)
        else:
            pixel_data = d.pixelData(s.x,s.y,s.width,s.height)
        # src/host/Image.python.hx:40
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import base64
        # src/host/Image.python.hx:44
        image = QImage(pixel_data.data(),s.width,s.height,QImage.Format_RGBA8888).rgbSwapped()
        # src/host/Image.python.hx:46
        data = QByteArray()
        # src/host/Image.python.hx:47
        buf = QBuffer(data)
        # src/host/Image.python.hx:48
        image.save(buf, "PNG")
        # src/host/Image.python.hx:50
        return data

    @staticmethod
    def layerFromPng(_hx_bytes,layer_name = None):
        # src/host/Image.python.hx:53
        if (layer_name is None):
            layer_name = "SD"
        # src/host/Image.python.hx:54
        
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import json
        imagen = QImage()
        imagen.loadFromData(_hx_bytes, "PNG" )
        ptr = imagen.bits()
        ptr.setsize(imagen.byteCount())
        d= Krita.instance().activeDocument()
        root = d.rootNode()
        n = d.createNode(layer_name, "paintLayer")
        s = d.selection()
        root.addChildNode(n, None)

        size = imagen.rect()
        #write pixels and refresh 
        #TODO clean this up a little for async receive. might be possible that s = None
        n.setPixelData(QByteArray(ptr.asstring()),s.x(),s.y(),size.width(),size.height())
        d.waitForDone()
        
        
        # src/host/Image.python.hx:76
        d = Krita.instance().activeDocument()
        # src/host/Image.python.hx:77
        d.refreshProjection()
host_Image._hx_class = host_Image


class host_UI:
    _hx_class_name = "host.UI"
    __slots__ = ()
    _hx_statics = ["__meta__", "txt2img_generate_fn_index", "txt2img_data_inputs", "txt2img_data_outputs", "img2img_generate_fn_index", "img2img_data_inputs", "img2img_data_outputs", "is_inpainting", "tags", "uitop", "createInterface", "makeTab", "asyncfetch", "makeComponent", "toast", "setParameter", "gatherParameter", "insertValue", "extractValue", "gatherSpecialParameter"]
    _hx_interfaces = [hxasync_Asyncable]
    uitop = None

    @staticmethod
    def createInterface():
        # src/host/UI.python.hx:48
        cloner = cloner_Cloner()
        # src/host/UI.python.hx:52
        tabWidget = QTabWidget()
        # src/host/UI.python.hx:54
        host_UI.uitop = tabWidget
        # src/host/UI.python.hx:56
        widget = QWidget()
        # src/host/UI.python.hx:57
        layout = QVBoxLayout()
        # src/host/UI.python.hx:59
        layout.addWidget(tabWidget)
        # src/host/UI.python.hx:60
        widget.setLayout(layout)
        # src/host/UI.python.hx:61
        host_App.docker.setWidget(widget)
        # src/host/UI.python.hx:65
        host_UI.makeTab("txt2img")
        # src/host/UI.python.hx:66
        host_UI.makeTab("img2img")
        # src/host/UI.python.hx:69
        # src/host/UI.python.hx:69
        _g = 0
        _g1 = host_UI.tags.h.get("img2img",None)
        while (_g < len(_g1)):
            tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:70
            # src/host/UI.python.hx:70
            _this = host_UI.tags.h.get("inpaint",None)
            x = Reflect.copy(tag)
            _this.append(x)
        # src/host/UI.python.hx:72
        # src/host/UI.python.hx:72
        _g = 0
        _g1 = host_UI.tags.h.get("img2img",None)
        while (_g < len(_g1)):
            tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:73
            # src/host/UI.python.hx:73
            _this = host_UI.tags.h.get("outpainting_mk2",None)
            x = Reflect.copy(tag)
            _this.append(x)
        # src/host/UI.python.hx:76
        host_UI.makeTab("inpaint")
        # src/host/UI.python.hx:77
        host_UI.makeTab("outpainting_mk2")

    @staticmethod
    def makeTab(mode):
        # src/host/UI.python.hx:83
        tab = QWidget()
        # src/host/UI.python.hx:84
        layout_inner = QVBoxLayout()
        # src/host/UI.python.hx:86
        headerlayout = QHBoxLayout()
        # src/host/UI.python.hx:87
        btn_recycle = QPushButton("♻️")
        # src/host/UI.python.hx:88
        btn_recycle.setMaximumWidth(64)
        # src/host/UI.python.hx:90
        def _hx_local_0(_hx_bool):
            # src/host/UI.python.hx:90
            host_UI.asyncfetch(host_UI.tags.h.get(mode,None))
        # src/host/UI.python.hx:89
        f_recycle = _hx_local_0
        # src/host/UI.python.hx:92
        btn_recycle.clicked.connect(f_recycle)
        # src/host/UI.python.hx:96
        headerlayout.addWidget(btn_recycle)
        # src/host/UI.python.hx:98
        btn_run = QPushButton("Generate")
        # src/host/UI.python.hx:99
        btn_run.setStyleSheet("background-color: rgb(255, 153, 28); color: black; font: 14px;")
        # src/host/UI.python.hx:101
        def _hx_local_1(_hx_bool):
            # src/host/UI.python.hx:101
            host_App.docker.generate2(mode,host_UI.tags.h.get(mode,None))
        # src/host/UI.python.hx:100
        f = _hx_local_1
        # src/host/UI.python.hx:103
        btn_run.clicked.connect(f)
        # src/host/UI.python.hx:104
        headerlayout.addWidget(btn_run)
        # src/host/UI.python.hx:106
        layout_inner.addLayout(headerlayout)
        # src/host/UI.python.hx:110
        tabform = QWidget()
        # src/host/UI.python.hx:111
        formlayout = QVBoxLayout()
        # src/host/UI.python.hx:113
        Utils.cleanTags(host_UI.tags.h.get(mode,None))
        # src/host/UI.python.hx:115
        # src/host/UI.python.hx:115
        _g = 0
        _g1 = host_UI.tags.h.get(mode,None)
        while (_g < len(_g1)):
            comp = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:116
            widget = host_UI.makeComponent(comp,mode)
            # src/host/UI.python.hx:117
            formlayout.addWidget(widget)
        # src/host/UI.python.hx:121
        tabform.setLayout(formlayout)
        # src/host/UI.python.hx:123
        scroll = QScrollArea()
        # src/host/UI.python.hx:124
        scroll.setWidget(tabform)
        # src/host/UI.python.hx:125
        scroll.setWidgetResizable(True)
        # src/host/UI.python.hx:128
        layout_inner.addWidget(scroll)
        # src/host/UI.python.hx:132
        tab.setLayout(layout_inner)
        # src/host/UI.python.hx:133
        host_UI.uitop.addTab(tab,mode)
        # src/host/UI.python.hx:135
        if (mode == "outpainting_mk2"):
            # src/host/UI.python.hx:136
            scriptcomponent = None
            # src/host/UI.python.hx:137
            temp_props = None
            # src/host/UI.python.hx:138
            # src/host/UI.python.hx:138
            _g = 0
            _g1 = host_UI.tags.h.get("outpainting_mk2",None)
            while (_g < len(_g1)):
                tag = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/UI.python.hx:139
                temp_props = Reflect.field(tag,"props")
                # src/host/UI.python.hx:141
                if (Reflect.field(temp_props,"param_name") == "script"):
                    scriptcomponent = tag
            # src/host/UI.python.hx:145
            print(str(scriptcomponent))
            # src/host/UI.python.hx:146
            Reflect.field(scriptcomponent,"setter")("Outpainting mk2")
            # src/host/UI.python.hx:147
            scriptdep = None
            # src/host/UI.python.hx:148
            fni = None
            # src/host/UI.python.hx:149
            # src/host/UI.python.hx:149
            _g = 0
            _g1 = len(host_App.gradio_dependencies)
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # src/host/UI.python.hx:150
                if (HxOverrides.arrayGet(Reflect.field(python_internal_ArrayImpl._get(host_App.gradio_dependencies, i),"targets"), 0) == Reflect.field(scriptcomponent,"id")):
                    fni = i
            # src/host/UI.python.hx:154
            print(str(("Script dropdown fnid: " + Std.string(fni))))
            # src/host/UI.python.hx:156
            outputs = Reflect.field(python_internal_ArrayImpl._get(host_App.gradio_dependencies, fni),"outputs")
            # src/host/UI.python.hx:159
            req = sys_Http((HxOverrides.stringOrNull(_Defs_Defs_Fields_.baseurl) + "/api/predict"))
            # src/host/UI.python.hx:160
            req.addHeader("Content-Type","application/json")
            # src/host/UI.python.hx:161
            post_data = haxe_format_JsonPrinter.print(_hx_AnonObject({'fn_index': fni, 'data': ["Outpainting mk2"], 'session_hash': None}),None,None)
            # src/host/UI.python.hx:165
            print(str(post_data))
            # src/host/UI.python.hx:166
            req.setPostData(post_data)
            # src/host/UI.python.hx:167
            def _hx_local_5(data_out):
                # src/host/UI.python.hx:169
                vismap = []
                # src/host/UI.python.hx:170
                props = None
                # src/host/UI.python.hx:171
                # src/host/UI.python.hx:171
                _g = 0
                _g1 = host_UI.tags.h.get("outpainting_mk2",None)
                while (_g < len(_g1)):
                    comp = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                    _g = (_g + 1)
                    # src/host/UI.python.hx:173
                    if (Reflect.field(comp,"id") in outputs):
                        vismap.append(comp)
                # src/host/UI.python.hx:179
                print(str(len(vismap)))
                # src/host/UI.python.hx:180
                jdata = python_lib_Json.loads(data_out,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
                # src/host/UI.python.hx:181
                data = Reflect.field(jdata,"data")
                # src/host/UI.python.hx:182
                print(str(len(data)))
                # src/host/UI.python.hx:184
                tag_props = None
                # src/host/UI.python.hx:185
                # src/host/UI.python.hx:185
                _g = 0
                _g1 = len(data)
                while (_g < _g1):
                    i = _g
                    _g = (_g + 1)
                    # src/host/UI.python.hx:186
                    tag_props = Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"props")
                    # src/host/UI.python.hx:187
                    # src/host/UI.python.hx:187
                    value = Reflect.field((data[i] if i >= 0 and i < len(data) else None),"visible")
                    setattr(tag_props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),value)
                    # src/host/UI.python.hx:188
                    if (Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container") is not None):
                        if (Reflect.field((data[i] if i >= 0 and i < len(data) else None),"visible") and (not Reflect.field(tag_props,"forcehidden"))):
                            Reflect.field(Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container"),"setVisible")(True)
                        else:
                            Reflect.field(Reflect.field((vismap[i] if i >= 0 and i < len(vismap) else None),"container"),"setVisible")(False)
            req.onData = _hx_local_5
            # src/host/UI.python.hx:200
            def _hx_local_6(status):
                # src/host/UI.python.hx:200
                print(str(status))
            # src/host/UI.python.hx:199
            req.onStatus = _hx_local_6
            # src/host/UI.python.hx:203
            req.request(True)

    @staticmethod
    def asyncfetch(components):
        # src/host/UI.python.hx:210
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        # src/host/UI.python.hx:211
        if (layer is None):
            host_UI.toast("Please select a layer to fetch from")
        else:
            Utils.fetchAndInsert(layer,components)

    @staticmethod
    def makeComponent(component,mode):
        # src/host/UI.python.hx:220
        itype = Reflect.field(component,"type")
        # src/host/UI.python.hx:221
        props = Reflect.field(component,"props")
        # src/host/UI.python.hx:222
        param_name = Reflect.field(props,"param_name")
        # src/host/UI.python.hx:224
        groupbox = QGroupBox(Std.string(param_name))
        # src/host/UI.python.hx:225
        hbox = QHBoxLayout()
        # src/host/UI.python.hx:227
        groupbox.setLayout(hbox)
        # src/host/UI.python.hx:231
        if (param_name == "extra"):
            # src/host/UI.python.hx:232
            setattr(props,(("_hx_" + "value") if (("value" in python_Boot.keywords)) else (("_hx_" + "value") if (((((len("value") > 2) and ((ord("value"[0]) == 95))) and ((ord("value"[1]) == 95))) and ((ord("value"[(len("value") - 1)]) != 95)))) else "value")),True)
            # src/host/UI.python.hx:233
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        # src/host/UI.python.hx:235
        if (param_name == "resize_mode"):
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        # src/host/UI.python.hx:237
        if (((((param_name == "mask_blur") or ((param_name == "masked_content"))) or ((param_name == "masking_mode"))) or ((param_name == "inpaint_at_full_resolution"))) or ((param_name == "inpaint_at_full_resolution_padding,_pixels"))):
            if (mode != "inpaint"):
                setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
            else:
                setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),True)
        # src/host/UI.python.hx:245
        if (param_name == "mask_mode"):
            # src/host/UI.python.hx:246
            # src/host/UI.python.hx:246
            value = ["Upload mask"]
            setattr(props,(("_hx_" + "choices") if (("choices" in python_Boot.keywords)) else (("_hx_" + "choices") if (((((len("choices") > 2) and ((ord("choices"[0]) == 95))) and ((ord("choices"[1]) == 95))) and ((ord("choices"[(len("choices") - 1)]) != 95)))) else "choices")),value)
            # src/host/UI.python.hx:247
            setattr(props,(("_hx_" + "value") if (("value" in python_Boot.keywords)) else (("_hx_" + "value") if (((((len("value") > 2) and ((ord("value"[0]) == 95))) and ((ord("value"[1]) == 95))) and ((ord("value"[(len("value") - 1)]) != 95)))) else "value")),"Upload mask")
            # src/host/UI.python.hx:248
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        # src/host/UI.python.hx:249
        if ((param_name == "input_directory") or ((param_name == "output_directory"))):
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        # src/host/UI.python.hx:253
        if (param_name == "height"):
            # src/host/UI.python.hx:255
            def _hx_local_0():
                # src/host/UI.python.hx:255
                return host_UI.gatherSpecialParameter("height")
            # src/host/UI.python.hx:254
            getter = _hx_local_0
            # src/host/UI.python.hx:258
            # src/host/UI.python.hx:258
            value = getter
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:259
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (param_name == "width"):
            # src/host/UI.python.hx:264
            def _hx_local_1():
                # src/host/UI.python.hx:264
                return host_UI.gatherSpecialParameter("width")
            # src/host/UI.python.hx:263
            getter1 = _hx_local_1
            # src/host/UI.python.hx:267
            # src/host/UI.python.hx:267
            value = getter1
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:268
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "image"):
            # src/host/UI.python.hx:273
            def _hx_local_2():
                # src/host/UI.python.hx:273
                return host_UI.gatherSpecialParameter(Reflect.field(props,"elem_id"))
            # src/host/UI.python.hx:272
            getter2 = _hx_local_2
            # src/host/UI.python.hx:276
            # src/host/UI.python.hx:276
            value = getter2
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:278
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "label"):
            # src/host/UI.python.hx:284
            def _hx_local_3():
                # src/host/UI.python.hx:284
                return host_UI.is_inpainting
            # src/host/UI.python.hx:282
            getter3 = _hx_local_3
            # src/host/UI.python.hx:287
            # src/host/UI.python.hx:287
            value = getter3
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:288
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif ((itype == "file") or ((itype == "html"))):
            # src/host/UI.python.hx:291
            setattr(props,(("_hx_" + "forcehidden") if (("forcehidden" in python_Boot.keywords)) else (("_hx_" + "forcehidden") if (((((len("forcehidden") > 2) and ((ord("forcehidden"[0]) == 95))) and ((ord("forcehidden"[1]) == 95))) and ((ord("forcehidden"[(len("forcehidden") - 1)]) != 95)))) else "forcehidden")),True)
            # src/host/UI.python.hx:293
            def _hx_local_4():
                # src/host/UI.python.hx:293
                return None
            # src/host/UI.python.hx:292
            getter4 = _hx_local_4
            # src/host/UI.python.hx:296
            # src/host/UI.python.hx:296
            value = getter4
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:297
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif ((itype == "gallery") or ((itype == "html"))):
            # src/host/UI.python.hx:302
            def _hx_local_5():
                # src/host/UI.python.hx:302
                return ""
            # src/host/UI.python.hx:301
            getter5 = _hx_local_5
            # src/host/UI.python.hx:305
            # src/host/UI.python.hx:305
            value = getter5
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:306
            setattr(props,(("_hx_" + "visible") if (("visible" in python_Boot.keywords)) else (("_hx_" + "visible") if (((((len("visible") > 2) and ((ord("visible"[0]) == 95))) and ((ord("visible"[1]) == 95))) and ((ord("visible"[(len("visible") - 1)]) != 95)))) else "visible")),False)
        elif (itype == "textbox"):
            # src/host/UI.python.hx:309
            input = QPlainTextEdit(Reflect.field(props,"value"))
            # src/host/UI.python.hx:310
            hbox.addWidget(input)
            # src/host/UI.python.hx:313
            def _hx_local_6():
                # src/host/UI.python.hx:313
                return input.toPlainText()
            # src/host/UI.python.hx:312
            getter6 = _hx_local_6
            # src/host/UI.python.hx:316
            def _hx_local_7(val):
                # src/host/UI.python.hx:316
                input.setPlainText(val)
            # src/host/UI.python.hx:315
            setter = _hx_local_7
            # src/host/UI.python.hx:319
            # src/host/UI.python.hx:319
            value = getter6
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:320
            # src/host/UI.python.hx:320
            value = setter
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif ((itype == "dropdown") or ((itype == "radio"))):
            # src/host/UI.python.hx:323
            input1 = QComboBox()
            # src/host/UI.python.hx:324
            input1.addItems(Reflect.field(props,"choices"))
            # src/host/UI.python.hx:325
            hbox.addWidget(input1)
            # src/host/UI.python.hx:328
            def _hx_local_8():
                # src/host/UI.python.hx:328
                return input1.currentText()
            # src/host/UI.python.hx:327
            getter7 = _hx_local_8
            # src/host/UI.python.hx:331
            def _hx_local_9(val):
                # src/host/UI.python.hx:331
                input1.setCurrentText(val)
            # src/host/UI.python.hx:330
            setter1 = _hx_local_9
            # src/host/UI.python.hx:334
            # src/host/UI.python.hx:334
            value = getter7
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:335
            # src/host/UI.python.hx:335
            value = setter1
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
            # src/host/UI.python.hx:336
            if (param_name == "script"):
                input1.setDisabled(True)
        elif (itype == "slider"):
            # src/host/UI.python.hx:340
            try:
                # src/host/UI.python.hx:341
                _hx_local_10 = Reflect.field(props,"step")
                if (Std.isOfType(_hx_local_10,Int) or ((_hx_local_10 is None))):
                    _hx_local_10
                else:
                    raise "Class cast error"
                _hx_local_10
            except BaseException as _g:
                # src/host/UI.python.hx:343
                input2 = QDoubleSpinBox()
                # src/host/UI.python.hx:344
                def _hx_local_12():
                    # src/host/UI.python.hx:344
                    _hx_local_11 = Reflect.field(props,"minimum")
                    if (Std.isOfType(_hx_local_11,Float) or ((_hx_local_11 is None))):
                        _hx_local_11
                    else:
                        raise "Class cast error"
                    return _hx_local_11
                input2.setMinimum(_hx_local_12())
                # src/host/UI.python.hx:345
                def _hx_local_14():
                    # src/host/UI.python.hx:345
                    _hx_local_13 = Reflect.field(props,"maximum")
                    if (Std.isOfType(_hx_local_13,Float) or ((_hx_local_13 is None))):
                        _hx_local_13
                    else:
                        raise "Class cast error"
                    return _hx_local_13
                input2.setMaximum(_hx_local_14())
                # src/host/UI.python.hx:346
                def _hx_local_16():
                    # src/host/UI.python.hx:346
                    _hx_local_15 = Reflect.field(props,"step")
                    if (Std.isOfType(_hx_local_15,Float) or ((_hx_local_15 is None))):
                        _hx_local_15
                    else:
                        raise "Class cast error"
                    return _hx_local_15
                input2.setSingleStep(_hx_local_16())
                # src/host/UI.python.hx:347
                def _hx_local_18():
                    # src/host/UI.python.hx:347
                    _hx_local_17 = Reflect.field(props,"value")
                    if (Std.isOfType(_hx_local_17,Float) or ((_hx_local_17 is None))):
                        _hx_local_17
                    else:
                        raise "Class cast error"
                    return _hx_local_17
                input2.setValue(_hx_local_18())
                # src/host/UI.python.hx:348
                hbox.addWidget(input2)
                # src/host/UI.python.hx:350
                def _hx_local_19():
                    # src/host/UI.python.hx:350
                    return input2.value()
                getter8 = _hx_local_19
                # src/host/UI.python.hx:351
                def _hx_local_20(val):
                    # src/host/UI.python.hx:351
                    input2.setValue(val)
                setter2 = _hx_local_20
                # src/host/UI.python.hx:352
                # src/host/UI.python.hx:352
                value = getter8
                setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
                # src/host/UI.python.hx:353
                # src/host/UI.python.hx:353
                value = setter2
                setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
                # src/host/UI.python.hx:355
                return groupbox
            # src/host/UI.python.hx:359
            input3 = QSpinBox()
            # src/host/UI.python.hx:360
            def _hx_local_22():
                # src/host/UI.python.hx:360
                _hx_local_21 = Reflect.field(props,"minimum")
                if (Std.isOfType(_hx_local_21,Int) or ((_hx_local_21 is None))):
                    _hx_local_21
                else:
                    raise "Class cast error"
                return _hx_local_21
            input3.setMinimum(_hx_local_22())
            # src/host/UI.python.hx:361
            def _hx_local_24():
                # src/host/UI.python.hx:361
                _hx_local_23 = Reflect.field(props,"maximum")
                if (Std.isOfType(_hx_local_23,Int) or ((_hx_local_23 is None))):
                    _hx_local_23
                else:
                    raise "Class cast error"
                return _hx_local_23
            input3.setMaximum(_hx_local_24())
            # src/host/UI.python.hx:362
            def _hx_local_26():
                # src/host/UI.python.hx:362
                _hx_local_25 = Reflect.field(props,"step")
                if (Std.isOfType(_hx_local_25,Int) or ((_hx_local_25 is None))):
                    _hx_local_25
                else:
                    raise "Class cast error"
                return _hx_local_25
            input3.setSingleStep(_hx_local_26())
            # src/host/UI.python.hx:363
            def _hx_local_28():
                # src/host/UI.python.hx:363
                _hx_local_27 = Reflect.field(props,"value")
                if (Std.isOfType(_hx_local_27,Int) or ((_hx_local_27 is None))):
                    _hx_local_27
                else:
                    raise "Class cast error"
                return _hx_local_27
            input3.setValue(_hx_local_28())
            # src/host/UI.python.hx:364
            hbox.addWidget(input3)
            # src/host/UI.python.hx:366
            def _hx_local_29():
                # src/host/UI.python.hx:366
                return input3.value()
            getter9 = _hx_local_29
            # src/host/UI.python.hx:367
            def _hx_local_30(val):
                # src/host/UI.python.hx:367
                input3.setValue(val)
            setter3 = _hx_local_30
            # src/host/UI.python.hx:368
            # src/host/UI.python.hx:368
            value = getter9
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:369
            # src/host/UI.python.hx:369
            value = setter3
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif (itype == "checkbox"):
            # src/host/UI.python.hx:371
            input4 = QCheckBox()
            # src/host/UI.python.hx:372
            def _hx_local_32():
                # src/host/UI.python.hx:372
                _hx_local_31 = Reflect.field(props,"value")
                if (Std.isOfType(_hx_local_31,Bool) or ((_hx_local_31 is None))):
                    _hx_local_31
                else:
                    raise "Class cast error"
                return _hx_local_31
            input4.setChecked(_hx_local_32())
            # src/host/UI.python.hx:373
            hbox.addWidget(input4)
            # src/host/UI.python.hx:376
            def _hx_local_33():
                # src/host/UI.python.hx:376
                return input4.isChecked()
            # src/host/UI.python.hx:375
            getter10 = _hx_local_33
            # src/host/UI.python.hx:379
            def _hx_local_34(val):
                # src/host/UI.python.hx:379
                if val:
                    input4.setCheckState(Qt.Checked)
                else:
                    input4.setCheckState(Qt.Unchecked)
            # src/host/UI.python.hx:378
            setter4 = _hx_local_34
            # src/host/UI.python.hx:386
            # src/host/UI.python.hx:386
            value = getter10
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:387
            # src/host/UI.python.hx:387
            value = setter4
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
        elif (itype == "number"):
            # src/host/UI.python.hx:390
            input5 = QLineEdit()
            # src/host/UI.python.hx:391
            input5.setText("-1")
            # src/host/UI.python.hx:392
            hbox.addWidget(input5)
            # src/host/UI.python.hx:395
            def _hx_local_35():
                # src/host/UI.python.hx:395
                return input5.text()
            # src/host/UI.python.hx:394
            getter11 = _hx_local_35
            # src/host/UI.python.hx:398
            def _hx_local_36(val):
                # src/host/UI.python.hx:398
                input5.setText(Std.string(val))
            # src/host/UI.python.hx:397
            setter5 = _hx_local_36
            # src/host/UI.python.hx:401
            # src/host/UI.python.hx:401
            value = getter11
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
            # src/host/UI.python.hx:402
            # src/host/UI.python.hx:402
            value = setter5
            setattr(component,(("_hx_" + "setter") if (("setter" in python_Boot.keywords)) else (("_hx_" + "setter") if (((((len("setter") > 2) and ((ord("setter"[0]) == 95))) and ((ord("setter"[1]) == 95))) and ((ord("setter"[(len("setter") - 1)]) != 95)))) else "setter")),value)
            # src/host/UI.python.hx:404
            reset = QPushButton("🎲")
            # src/host/UI.python.hx:407
            def _hx_local_37(_hx_bool):
                # src/host/UI.python.hx:407
                Reflect.field(component,"setter")(-1)
            # src/host/UI.python.hx:405
            reset.clicked.connect(_hx_local_37)
            # src/host/UI.python.hx:410
            hbox.addWidget(reset)
            # src/host/UI.python.hx:412
            keep = QPushButton("♻️")
            # src/host/UI.python.hx:414
            def _hx_local_38(_hx_bool):
                # src/host/UI.python.hx:414
                if (Reflect.field(host_App.getDocumentState(),"layer") is None):
                    # src/host/UI.python.hx:415
                    host_UI.toast("No Layer selected?")
                    # src/host/UI.python.hx:416
                    return
                else:
                    Utils.fetchAndInsert(Reflect.field(host_App.getDocumentState(),"layer"),[component])
            # src/host/UI.python.hx:413
            f_rec = _hx_local_38
            # src/host/UI.python.hx:421
            keep.clicked.connect(f_rec)
            # src/host/UI.python.hx:422
            hbox.addWidget(keep)
        elif (itype == "checkboxgroup"):
            # src/host/UI.python.hx:424
            choices = Reflect.field(props,"choices")
            # src/host/UI.python.hx:425
            checks = []
            # src/host/UI.python.hx:426
            # src/host/UI.python.hx:426
            _g = 0
            while (_g < len(choices)):
                name = (choices[_g] if _g >= 0 and _g < len(choices) else None)
                _g = (_g + 1)
                # src/host/UI.python.hx:427
                chk = QCheckBox(name)
                # src/host/UI.python.hx:428
                chk.setChecked(True)
                # src/host/UI.python.hx:429
                hbox.addWidget(chk)
                # src/host/UI.python.hx:430
                checks.append(chk)
            # src/host/UI.python.hx:433
            def _hx_local_40():
                # src/host/UI.python.hx:434
                toggledopts = []
                # src/host/UI.python.hx:435
                # src/host/UI.python.hx:435
                _g = 0
                _g1 = len(choices)
                while (_g < _g1):
                    i = _g
                    _g = (_g + 1)
                    # src/host/UI.python.hx:436
                    if (checks[i] if i >= 0 and i < len(checks) else None).isChecked():
                        toggledopts.append((choices[i] if i >= 0 and i < len(choices) else None))
                # src/host/UI.python.hx:440
                return toggledopts
            getter12 = _hx_local_40
            # src/host/UI.python.hx:442
            # src/host/UI.python.hx:442
            value = getter12
            setattr(component,(("_hx_" + "getter") if (("getter" in python_Boot.keywords)) else (("_hx_" + "getter") if (((((len("getter") > 2) and ((ord("getter"[0]) == 95))) and ((ord("getter"[1]) == 95))) and ((ord("getter"[(len("getter") - 1)]) != 95)))) else "getter")),value)
        # src/host/UI.python.hx:445
        tmp = None
        if (Reflect.field(props,"visible") != False):
            _this = host_UI.txt2img_data_outputs
            tmp = (Reflect.field(component,"id") in _this)
        else:
            tmp = True
        if tmp:
            groupbox.setVisible(False)
        # src/host/UI.python.hx:449
        setattr(component,(("_hx_" + "container") if (("container" in python_Boot.keywords)) else (("_hx_" + "container") if (((((len("container") > 2) and ((ord("container"[0]) == 95))) and ((ord("container"[1]) == 95))) and ((ord("container"[(len("container") - 1)]) != 95)))) else "container")),groupbox)
        # src/host/UI.python.hx:450
        if (mode == "inpaint"):
            # src/host/UI.python.hx:451
            print(str(param_name))
            # src/host/UI.python.hx:452
            print(("visible: " + Std.string(Reflect.field(props,"visible"))))
        # src/host/UI.python.hx:454
        return groupbox

    @staticmethod
    def toast(msg):
        # src/host/UI.python.hx:556
        Krita.instance().activeWindow().activeView().showFloatingMessage(("" + Std.string(msg)),QIcon(),2000,1)

    @staticmethod
    def setParameter(param_name,value):
        # src/host/UI.python.hx:560
        tab = host_UI.uitop.currentWidget()
        # src/host/UI.python.hx:561
        # src/host/UI.python.hx:561
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:562
            def _hx_local_2():
                # src/host/UI.python.hx:562
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                # src/host/UI.python.hx:563
                def _hx_local_4():
                    # src/host/UI.python.hx:563
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                host_UI.insertValue(_hx_local_4(),value)

    @staticmethod
    def gatherParameter(param_name):
        # src/host/UI.python.hx:572
        tab = host_UI.uitop.currentWidget()
        # src/host/UI.python.hx:573
        param = None
        # src/host/UI.python.hx:574
        # src/host/UI.python.hx:574
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:575
            def _hx_local_2():
                # src/host/UI.python.hx:575
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                # src/host/UI.python.hx:576
                def _hx_local_4():
                    # src/host/UI.python.hx:576
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                param = host_UI.extractValue(_hx_local_4())
        # src/host/UI.python.hx:580
        if (param is None):
            param = host_UI.gatherSpecialParameter(param_name)
        # src/host/UI.python.hx:585
        if (param is None):
            # src/host/UI.python.hx:586
            print("\nerror in gatherParameter")
            # src/host/UI.python.hx:587
            print(str(param_name))
        # src/host/UI.python.hx:591
        return param

    @staticmethod
    def insertValue(groupBox,value):
        # src/host/UI.python.hx:597
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        winfo = this1.h.get(key,None)
        # src/host/UI.python.hx:599
        itype = winfo.inputtype
        # src/host/UI.python.hx:601
        # src/host/UI.python.hx:601
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:602
            def _hx_local_2():
                # src/host/UI.python.hx:602
                _hx_local_1 = widget
                if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            (_hx_local_2()).setPlainText(value)
            # src/host/UI.python.hx:603
            return
        # src/host/UI.python.hx:605
        # src/host/UI.python.hx:605
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:606
            def _hx_local_5():
                # src/host/UI.python.hx:606
                _hx_local_4 = widget
                if (Std.isOfType(_hx_local_4,QSpinBox) or ((_hx_local_4 is None))):
                    _hx_local_4
                else:
                    raise "Class cast error"
                return _hx_local_4
            (_hx_local_5()).setValue(value)
            # src/host/UI.python.hx:607
            return
        # src/host/UI.python.hx:609
        # src/host/UI.python.hx:609
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:610
            def _hx_local_8():
                # src/host/UI.python.hx:610
                _hx_local_7 = widget
                if (Std.isOfType(_hx_local_7,QDoubleSpinBox) or ((_hx_local_7 is None))):
                    _hx_local_7
                else:
                    raise "Class cast error"
                return _hx_local_7
            (_hx_local_8()).setValue(value)
            # src/host/UI.python.hx:611
            return
        # src/host/UI.python.hx:613
        # src/host/UI.python.hx:613
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:614
            def _hx_local_11():
                # src/host/UI.python.hx:614
                _hx_local_10 = widget
                if (Std.isOfType(_hx_local_10,QComboBox) or ((_hx_local_10 is None))):
                    _hx_local_10
                else:
                    raise "Class cast error"
                return _hx_local_10
            (_hx_local_11()).setCurrentText(value)
            # src/host/UI.python.hx:615
            return
        # src/host/UI.python.hx:617
        # src/host/UI.python.hx:617
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:618
            def _hx_local_14():
                # src/host/UI.python.hx:618
                _hx_local_13 = widget
                if (Std.isOfType(_hx_local_13,QLineEdit) or ((_hx_local_13 is None))):
                    _hx_local_13
                else:
                    raise "Class cast error"
                return _hx_local_13
            (_hx_local_14()).setText(Std.string(value))
            # src/host/UI.python.hx:619
            return
        # src/host/UI.python.hx:622
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            return
        else:
            # src/host/UI.python.hx:627
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/UI.python.hx:628
                if value:
                    # src/host/UI.python.hx:629
                    def _hx_local_17():
                        # src/host/UI.python.hx:629
                        _hx_local_16 = widget
                        if (Std.isOfType(_hx_local_16,QCheckBox) or ((_hx_local_16 is None))):
                            _hx_local_16
                        else:
                            raise "Class cast error"
                        return _hx_local_16
                    (_hx_local_17()).setCheckState(Qt.Checked)
                else:
                    # src/host/UI.python.hx:631
                    def _hx_local_19():
                        # src/host/UI.python.hx:631
                        _hx_local_18 = widget
                        if (Std.isOfType(_hx_local_18,QCheckBox) or ((_hx_local_18 is None))):
                            _hx_local_18
                        else:
                            raise "Class cast error"
                        return _hx_local_18
                    (_hx_local_19()).setCheckState(Qt.Unchecked)
                # src/host/UI.python.hx:633
                return

    @staticmethod
    def extractValue(groupBox):
        # src/host/UI.python.hx:643
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        widgetinfo = this1.h.get(key,None)
        # src/host/UI.python.hx:644
        # src/host/UI.python.hx:644
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:645
            def _hx_local_3():
                # src/host/UI.python.hx:645
                def _hx_local_2():
                    # src/host/UI.python.hx:645
                    _hx_local_1 = widget
                    if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                        _hx_local_1
                    else:
                        raise "Class cast error"
                    return _hx_local_1
                return (_hx_local_2()).toPlainText()
            return _hx_local_3()
        # src/host/UI.python.hx:647
        # src/host/UI.python.hx:647
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:648
            def _hx_local_7():
                # src/host/UI.python.hx:648
                def _hx_local_6():
                    # src/host/UI.python.hx:648
                    _hx_local_5 = widget
                    if (Std.isOfType(_hx_local_5,QSpinBox) or ((_hx_local_5 is None))):
                        _hx_local_5
                    else:
                        raise "Class cast error"
                    return _hx_local_5
                return (_hx_local_6()).value()
            return _hx_local_7()
        # src/host/UI.python.hx:650
        # src/host/UI.python.hx:650
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:651
            def _hx_local_11():
                # src/host/UI.python.hx:651
                def _hx_local_10():
                    # src/host/UI.python.hx:651
                    _hx_local_9 = widget
                    if (Std.isOfType(_hx_local_9,QDoubleSpinBox) or ((_hx_local_9 is None))):
                        _hx_local_9
                    else:
                        raise "Class cast error"
                    return _hx_local_9
                return (_hx_local_10()).value()
            return _hx_local_11()
        # src/host/UI.python.hx:653
        # src/host/UI.python.hx:653
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:654
            def _hx_local_15():
                # src/host/UI.python.hx:654
                def _hx_local_14():
                    # src/host/UI.python.hx:654
                    _hx_local_13 = widget
                    if (Std.isOfType(_hx_local_13,QComboBox) or ((_hx_local_13 is None))):
                        _hx_local_13
                    else:
                        raise "Class cast error"
                    return _hx_local_13
                return (_hx_local_14()).currentText()
            return _hx_local_15()
        # src/host/UI.python.hx:657
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            # src/host/UI.python.hx:658
            checklist = []
            # src/host/UI.python.hx:659
            # src/host/UI.python.hx:659
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/UI.python.hx:660
                def _hx_local_18():
                    # src/host/UI.python.hx:660
                    _hx_local_17 = widget
                    if (Std.isOfType(_hx_local_17,QCheckBox) or ((_hx_local_17 is None))):
                        _hx_local_17
                    else:
                        raise "Class cast error"
                    return _hx_local_17
                if (_hx_local_18()).isChecked():
                    # src/host/UI.python.hx:661
                    def _hx_local_20():
                        # src/host/UI.python.hx:661
                        _hx_local_19 = widget
                        if (Std.isOfType(_hx_local_19,QCheckBox) or ((_hx_local_19 is None))):
                            _hx_local_19
                        else:
                            raise "Class cast error"
                        return _hx_local_19
                    x = (_hx_local_20()).text()
                    checklist.append(x)
            # src/host/UI.python.hx:664
            return checklist
        else:
            # src/host/UI.python.hx:667
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # src/host/UI.python.hx:668
                def _hx_local_24():
                    # src/host/UI.python.hx:668
                    def _hx_local_23():
                        # src/host/UI.python.hx:668
                        _hx_local_22 = widget
                        if (Std.isOfType(_hx_local_22,QCheckBox) or ((_hx_local_22 is None))):
                            _hx_local_22
                        else:
                            raise "Class cast error"
                        return _hx_local_22
                    return (_hx_local_23()).isChecked()
                return _hx_local_24()
        # src/host/UI.python.hx:671
        # src/host/UI.python.hx:671
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # src/host/UI.python.hx:672
            if ((groupBox.title() == "seed") or ((groupBox.title() == "subseed"))):
                # src/host/UI.python.hx:673
                def _hx_local_28():
                    # src/host/UI.python.hx:673
                    def _hx_local_27():
                        # src/host/UI.python.hx:673
                        _hx_local_26 = widget
                        if (Std.isOfType(_hx_local_26,QLineEdit) or ((_hx_local_26 is None))):
                            _hx_local_26
                        else:
                            raise "Class cast error"
                        return _hx_local_26
                    return Std.parseInt((_hx_local_27()).text())
                return _hx_local_28()
            else:
                # src/host/UI.python.hx:675
                def _hx_local_31():
                    # src/host/UI.python.hx:675
                    def _hx_local_30():
                        # src/host/UI.python.hx:675
                        _hx_local_29 = widget
                        if (Std.isOfType(_hx_local_29,QLineEdit) or ((_hx_local_29 is None))):
                            _hx_local_29
                        else:
                            raise "Class cast error"
                        return _hx_local_29
                    return (_hx_local_30()).text()
                return _hx_local_31()
        # src/host/UI.python.hx:680
        return None

    @staticmethod
    def gatherSpecialParameter(param_name):
        # src/host/UI.python.hx:684
        print(str(("gathering special parameter: " + ("null" if param_name is None else param_name))))
        # src/host/UI.python.hx:686
        state = host_App.getDocumentState()
        # src/host/UI.python.hx:687
        s = Krita.instance().activeDocument().selection()
        # src/host/UI.python.hx:691
        if (((param_name == "img2img_image") and ((host_UI.is_inpainting == 0))) or (((param_name == "img_inpaint_base") and ((host_UI.is_inpainting == 1))))):
            # src/host/UI.python.hx:695
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            # src/host/UI.python.hx:696
            if (mask is not None):
                mask.setVisible(False)
            # src/host/UI.python.hx:701
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"))
            # src/host/UI.python.hx:703
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            # src/host/UI.python.hx:705
            return base64string
        # src/host/UI.python.hx:708
        if (param_name == "img2maskimg"):
            return None
        # src/host/UI.python.hx:712
        if ((param_name == "img_inpaint_mask") and ((host_UI.is_inpainting == 1))):
            # src/host/UI.python.hx:713
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            # src/host/UI.python.hx:714
            mask.setVisible(True)
            # src/host/UI.python.hx:716
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"),Reflect.field(state,"layer"))
            # src/host/UI.python.hx:718
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            # src/host/UI.python.hx:720
            return base64string
        # src/host/UI.python.hx:723
        if (param_name == "width"):
            return s.width()
        # src/host/UI.python.hx:726
        if (param_name == "height"):
            # src/host/UI.python.hx:727
            print("getting height special")
            # src/host/UI.python.hx:728
            return s.height()
        # src/host/UI.python.hx:730
        return None
host_UI._hx_class = host_UI


class host__UIDefs_UIDefs_Fields_:
    _hx_class_name = "host._UIDefs.UIDefs_Fields_"
    __slots__ = ()
    _hx_statics = ["samplers", "widgetinfo", "parameterNames"]
host__UIDefs_UIDefs_Fields_._hx_class = host__UIDefs_UIDefs_Fields_


class pyqt5_qtcore__QMap_QMapIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapIterator"
    __slots__ = ("checked", "has", "it", "x")
    _hx_fields = ["checked", "has", "it", "x"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,q):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:64
        self.x = None
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:62
        self.has = False
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:61
        self.checked = False
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:67
        self.it = q

    def hasNext(self):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:71
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except StopIteration:
                self.has = False
                self.x = None
            self.checked = True

        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:80
        return self.has

    def next(self):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:84
        if (not self.checked):
            self.hasNext()
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:85
        self.checked = False
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:86
        return self.x

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.checked = None
        _hx_o.has = None
        _hx_o.it = None
        _hx_o.x = None
pyqt5_qtcore__QMap_QMapIterator._hx_class = pyqt5_qtcore__QMap_QMapIterator


class pyqt5_qtcore__QMap_QMapKeyValueIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapKeyValueIterator"
    __slots__ = ("map", "keys")
    _hx_fields = ["map", "keys"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,_hx_map):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:95
        self.map = _hx_map
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:96
        self.keys = pyqt5_qtcore__QMap_QMapIterator(iter(_hx_map.keys()))

    def hasNext(self):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:100
        return self.keys.hasNext()

    def next(self):
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:104
        key = self.keys.next()
        # C:\HaxeToolkit\haxe\lib\krita_externs/0,0,3/pyqt5/qtcore/QMap.hx:105
        return _hx_AnonObject({'value': self.map[key], 'key': key})

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.map = None
        _hx_o.keys = None
pyqt5_qtcore__QMap_QMapKeyValueIterator._hx_class = pyqt5_qtcore__QMap_QMapKeyValueIterator


class python_Boot:
    _hx_class_name = "python.Boot"
    __slots__ = ()
    _hx_statics = ["keywords", "_add_dynamic", "toString1", "fields", "simpleField", "hasField", "field", "getInstanceFields", "getSuperClass", "getClassFields", "prefixLength", "unhandleKeywords"]

    @staticmethod
    def _add_dynamic(a,b):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:73
        if (isinstance(a,str) and isinstance(b,str)):
            return (a + b)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:76
        if (isinstance(a,str) or isinstance(b,str)):
            return (python_Boot.toString1(a,"") + python_Boot.toString1(b,""))
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:79
        return (a + b)

    @staticmethod
    def toString1(o,s):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:87
        if (o is None):
            return "null"
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:90
        if isinstance(o,str):
            return o
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:93
        if (s is None):
            s = ""
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:95
        if (len(s) >= 5):
            return "<...>"
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:98
        if isinstance(o,bool):
            if o:
                return "true"
            else:
                return "false"
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:104
        if (isinstance(o,int) and (not isinstance(o,bool))):
            return str(o)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:108
        if isinstance(o,float):
            try:
                if (o == int(o)):
                    return str(Math.floor((o + 0.5)))
                else:
                    return str(o)
            except BaseException as _g:
                return str(o)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:120
        if isinstance(o,list):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:121
            o1 = o
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:123
            l = len(o1)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:125
            st = "["
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:126
            s = (("null" if s is None else s) + "\t")
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:127
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:127
            _g = 0
            _g1 = l
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:128
                prefix = ""
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:129
                if (i > 0):
                    prefix = ","
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:132
                st = (("null" if st is None else st) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1((o1[i] if i >= 0 and i < len(o1) else None),s))))))
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:134
            st = (("null" if st is None else st) + "]")
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:135
            return st
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:138
        try:
            if hasattr(o,"toString"):
                return o.toString()
        except BaseException as _g:
            pass
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:143
        if hasattr(o,"__class__"):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:144
            if isinstance(o,_hx_AnonObject):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:145
                toStr = None
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:146
                try:
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:147
                    fields = python_Boot.fields(o)
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:148
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:149
                    toStr = (("{ " + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " }")
                except BaseException as _g:
                    return "{ ... }"
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:154
                if (toStr is None):
                    return "{ ... }"
                else:
                    return toStr
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:160
            if isinstance(o,Enum):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:161
                o1 = o
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:163
                l = len(o1.params)
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:164
                hasParams = (l > 0)
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:165
                if hasParams:
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:166
                    paramsStr = ""
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:167
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:167
                    _g = 0
                    _g1 = l
                    while (_g < _g1):
                        i = _g
                        _g = (_g + 1)
                        # C:\HaxeToolkit\haxe\std/python/Boot.hx:168
                        prefix = ""
                        # C:\HaxeToolkit\haxe\std/python/Boot.hx:169
                        if (i > 0):
                            prefix = ","
                        # C:\HaxeToolkit\haxe\std/python/Boot.hx:172
                        paramsStr = (("null" if paramsStr is None else paramsStr) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1(o1.params[i],s))))))
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:174
                    return (((HxOverrides.stringOrNull(o1.tag) + "(") + ("null" if paramsStr is None else paramsStr)) + ")")
                else:
                    return o1.tag
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:180
            if hasattr(o,"_hx_class_name"):
                if (o.__class__.__name__ != "type"):
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:182
                    fields = python_Boot.getInstanceFields(o)
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:183
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:185
                    toStr = (((HxOverrides.stringOrNull(o._hx_class_name) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:186
                    return toStr
                else:
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:188
                    fields = python_Boot.getClassFields(o)
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:189
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:190
                    toStr = (((("#" + HxOverrides.stringOrNull(o._hx_class_name)) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:191
                    return toStr
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:195
            if ((type(o) == type) and (o == str)):
                return "#String"
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:199
            if ((type(o) == type) and (o == list)):
                return "#Array"
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:203
            if callable(o):
                return "function"
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:206
            try:
                if hasattr(o,"__repr__"):
                    return o.__repr__()
            except BaseException as _g:
                pass
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:212
            if hasattr(o,"__str__"):
                return o.__str__([])
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:216
            if hasattr(o,"__name__"):
                return o.__name__
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:219
            return "???"
        else:
            return str(o)

    @staticmethod
    def fields(o):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:231
        a = []
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:232
        if (o is not None):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:233
            if hasattr(o,"_hx_fields"):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:234
                fields = o._hx_fields
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:235
                if (fields is not None):
                    return list(fields)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:239
            if isinstance(o,_hx_AnonObject):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:240
                d = o.__dict__
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:241
                keys = d.keys()
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:242
                handler = python_Boot.unhandleKeywords
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:244
                for k in keys:
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:245
                    if (k != '_hx_disable_getattr'):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:246
                        a.append(handler(k))
            elif hasattr(o,"__dict__"):
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:249
                d = o.__dict__
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:250
                keys1 = d.keys()
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:251
                for k in keys1:
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:252
                    a.append(k)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:255
        return a

    @staticmethod
    def simpleField(o,field):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:267
        if (field is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:270
        field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:271
        if hasattr(o,field1):
            return getattr(o,field1)
        else:
            return None

    @staticmethod
    def hasField(o,field):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:280
        if isinstance(o,_hx_AnonObject):
            return o._hx_hasattr(field)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:283
        return hasattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)))

    @staticmethod
    def field(o,field):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:287
        if (field is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:295
        if isinstance(o,str):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:296
            field1 = field
            _hx_local_0 = len(field1)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:306
            if (_hx_local_0 == 10):
                if (field1 == "charCodeAt"):
                    return python_internal_MethodClosure(o,HxString.charCodeAt)
                else:
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:320
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,HxString.lastIndexOf)
                elif (field1 == "toLowerCase"):
                    return python_internal_MethodClosure(o,HxString.toLowerCase)
                elif (field1 == "toUpperCase"):
                    return python_internal_MethodClosure(o,HxString.toUpperCase)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 9):
                if (field1 == "substring"):
                    return python_internal_MethodClosure(o,HxString.substring)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 5):
                if (field1 == "split"):
                    return python_internal_MethodClosure(o,HxString.split)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,HxString.indexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 8):
                if (field1 == "toString"):
                    return python_internal_MethodClosure(o,HxString.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 6):
                if (field1 == "charAt"):
                    return python_internal_MethodClosure(o,HxString.charAt)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "substr"):
                    return python_internal_MethodClosure(o,HxString.substr)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        elif isinstance(o,list):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:323
            field1 = field
            _hx_local_1 = len(field1)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:353
            if (_hx_local_1 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.lastIndexOf)
                else:
                    # C:\HaxeToolkit\haxe\std/python/Boot.hx:369
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 4):
                if (field1 == "copy"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.copy)
                elif (field1 == "join"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.join)
                elif (field1 == "push"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.push)
                elif (field1 == "sort"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.sort)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 5):
                if (field1 == "shift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.shift)
                elif (field1 == "slice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.slice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.indexOf)
                elif (field1 == "reverse"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.reverse)
                elif (field1 == "unshift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.unshift)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 3):
                if (field1 == "map"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.map)
                elif (field1 == "pop"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.pop)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 8):
                if (field1 == "contains"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.contains)
                elif (field1 == "iterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.iterator)
                elif (field1 == "toString"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 16):
                if (field1 == "keyValueIterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.keyValueIterator)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 6):
                if (field1 == "concat"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.concat)
                elif (field1 == "filter"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.filter)
                elif (field1 == "insert"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.insert)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "remove"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.remove)
                elif (field1 == "splice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.splice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        else:
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:372
            field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
            if hasattr(o,field1):
                return getattr(o,field1)
            else:
                return None

    @staticmethod
    def getInstanceFields(c):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:377
        f = (list(c._hx_fields) if (hasattr(c,"_hx_fields")) else [])
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:378
        if hasattr(c,"_hx_methods"):
            f = (f + c._hx_methods)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:381
        sc = python_Boot.getSuperClass(c)
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:383
        if (sc is None):
            return f
        else:
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:386
            scArr = python_Boot.getInstanceFields(sc)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:387
            scMap = set(scArr)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:388
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:388
            _g = 0
            while (_g < len(f)):
                f1 = (f[_g] if _g >= 0 and _g < len(f) else None)
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/python/Boot.hx:389
                if (not (f1 in scMap)):
                    scArr.append(f1)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:394
            return scArr

    @staticmethod
    def getSuperClass(c):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:399
        if (c is None):
            return None
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:402
        try:
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:403
            if hasattr(c,"_hx_super"):
                return c._hx_super
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:406
            return None
        except BaseException as _g:
            pass
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:408
        return None

    @staticmethod
    def getClassFields(c):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:412
        if hasattr(c,"_hx_statics"):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:413
            x = c._hx_statics
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:414
            return list(x)
        else:
            return []

    @staticmethod
    def unhandleKeywords(name):
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:439
        if (HxString.substr(name,0,python_Boot.prefixLength) == "_hx_"):
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:440
            real = HxString.substr(name,python_Boot.prefixLength,None)
            # C:\HaxeToolkit\haxe\std/python/Boot.hx:441
            if (real in python_Boot.keywords):
                return real
        # C:\HaxeToolkit\haxe\std/python/Boot.hx:444
        return name
python_Boot._hx_class = python_Boot


class python_HaxeIterator:
    _hx_class_name = "python.HaxeIterator"
    __slots__ = ("it", "x", "has", "checked")
    _hx_fields = ["it", "x", "has", "checked"]
    _hx_methods = ["next", "hasNext"]

    def __init__(self,it):
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:32
        self.checked = False
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:31
        self.has = False
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:30
        self.x = None
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:35
        self.it = it

    def next(self):
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:39
        if (not self.checked):
            self.hasNext()
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:41
        self.checked = False
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:42
        return self.x

    def hasNext(self):
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:46
        if (not self.checked):
            # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:47
            try:
                # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:48
                self.x = self.it.__next__()
                # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:49
                self.has = True
            except BaseException as _g:
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),StopIteration):
                    # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:51
                    self.has = False
                    # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:52
                    self.x = None
                else:
                    raise _g
            # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:54
            self.checked = True
        # C:\HaxeToolkit\haxe\std/python/HaxeIterator.hx:56
        return self.has

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.it = None
        _hx_o.x = None
        _hx_o.has = None
        _hx_o.checked = None
python_HaxeIterator._hx_class = python_HaxeIterator


class python__KwArgs_KwArgs_Impl_:
    _hx_class_name = "python._KwArgs.KwArgs_Impl_"
    __slots__ = ()
    _hx_statics = ["fromT"]

    @staticmethod
    def fromT(d):
        # C:\HaxeToolkit\haxe\std/python/KwArgs.hx:59
        this1 = python_Lib.anonAsDict(d)
        return this1
python__KwArgs_KwArgs_Impl_._hx_class = python__KwArgs_KwArgs_Impl_


class HxString:
    _hx_class_name = "HxString"
    __slots__ = ()
    _hx_statics = ["split", "charCodeAt", "charAt", "lastIndexOf", "toUpperCase", "toLowerCase", "indexOf", "indexOfImpl", "toString", "substring", "substr"]

    @staticmethod
    def split(s,d):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:31
        if (d == ""):
            return list(s)
        else:
            return s.split(d)

    @staticmethod
    def charCodeAt(s,index):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:36
        if ((((s is None) or ((len(s) == 0))) or ((index < 0))) or ((index >= len(s)))):
            return None
        else:
            return ord(s[index])

    @staticmethod
    def charAt(s,index):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:41
        if ((index < 0) or ((index >= len(s)))):
            return ""
        else:
            return s[index]

    @staticmethod
    def lastIndexOf(s,_hx_str,startIndex = None):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:46
        if (startIndex is None):
            return s.rfind(_hx_str, 0, len(s))
        elif (_hx_str == ""):
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:49
            length = len(s)
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:50
            if (startIndex < 0):
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:51
                startIndex = (length + startIndex)
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:52
                if (startIndex < 0):
                    startIndex = 0
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:54
            if (startIndex > length):
                return length
            else:
                return startIndex
        else:
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:56
            i = s.rfind(_hx_str, 0, (startIndex + 1))
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:57
            startLeft = (max(0,((startIndex + 1) - len(_hx_str))) if ((i == -1)) else (i + 1))
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:58
            check = s.find(_hx_str, startLeft, len(s))
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:59
            if ((check > i) and ((check <= startIndex))):
                return check
            else:
                return i

    @staticmethod
    def toUpperCase(s):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:69
        return s.upper()

    @staticmethod
    def toLowerCase(s):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:74
        return s.lower()

    @staticmethod
    def indexOf(s,_hx_str,startIndex = None):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:79
        if (startIndex is None):
            return s.find(_hx_str)
        else:
            return HxString.indexOfImpl(s,_hx_str,startIndex)

    @staticmethod
    def indexOfImpl(s,_hx_str,startIndex):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:86
        if (_hx_str == ""):
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:87
            length = len(s)
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:88
            if (startIndex < 0):
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:89
                startIndex = (length + startIndex)
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:90
                if (startIndex < 0):
                    startIndex = 0
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:92
            if (startIndex > length):
                return length
            else:
                return startIndex
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:94
        return s.find(_hx_str, startIndex)

    @staticmethod
    def toString(s):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:99
        return s

    @staticmethod
    def substring(s,startIndex,endIndex = None):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:118
        if (startIndex < 0):
            startIndex = 0
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:120
        if (endIndex is None):
            return s[startIndex:]
        else:
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:123
            if (endIndex < 0):
                endIndex = 0
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:125
            if (endIndex < startIndex):
                return s[endIndex:startIndex]
            else:
                return s[startIndex:endIndex]

    @staticmethod
    def substr(s,startIndex,_hx_len = None):
        # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:135
        if (_hx_len is None):
            return s[startIndex:]
        else:
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:138
            if (_hx_len == 0):
                return ""
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:140
            if (startIndex < 0):
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:141
                startIndex = (len(s) + startIndex)
                # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:142
                if (startIndex < 0):
                    startIndex = 0
            # C:\HaxeToolkit\haxe\std/python/internal/StringImpl.hx:145
            return s[startIndex:(startIndex + _hx_len)]
HxString._hx_class = HxString


class python_Lib:
    _hx_class_name = "python.Lib"
    __slots__ = ()
    _hx_statics = ["dictToAnon", "anonToDict", "anonAsDict"]

    @staticmethod
    def dictToAnon(v):
        # C:\HaxeToolkit\haxe\std/python/Lib.hx:67
        return _hx_AnonObject(v.copy())

    @staticmethod
    def anonToDict(o):
        # C:\HaxeToolkit\haxe\std/python/Lib.hx:75
        if isinstance(o,_hx_AnonObject):
            return o.__dict__.copy()
        else:
            return None

    @staticmethod
    def anonAsDict(o):
        # C:\HaxeToolkit\haxe\std/python/Lib.hx:86
        if isinstance(o,_hx_AnonObject):
            return o.__dict__
        else:
            return None
python_Lib._hx_class = python_Lib


class python_internal_ArrayImpl:
    _hx_class_name = "python.internal.ArrayImpl"
    __slots__ = ()
    _hx_statics = ["concat", "copy", "iterator", "keyValueIterator", "indexOf", "lastIndexOf", "join", "toString", "pop", "push", "unshift", "remove", "contains", "shift", "slice", "sort", "splice", "map", "filter", "insert", "reverse", "_get", "_set"]

    @staticmethod
    def concat(a1,a2):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:35
        return (a1 + a2)

    @staticmethod
    def copy(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:40
        return list(x)

    @staticmethod
    def iterator(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:45
        return python_HaxeIterator(x.__iter__())

    @staticmethod
    def keyValueIterator(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:50
        return haxe_iterators_ArrayKeyValueIterator(x)

    @staticmethod
    def indexOf(a,x,fromIndex = None):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:55
        _hx_len = len(a)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:56
        l = (0 if ((fromIndex is None)) else ((_hx_len + fromIndex) if ((fromIndex < 0)) else fromIndex))
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:57
        if (l < 0):
            l = 0
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:59
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:59
        _g = l
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:60
            if HxOverrides.eq(a[i],x):
                return i
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:63
        return -1

    @staticmethod
    def lastIndexOf(a,x,fromIndex = None):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:68
        _hx_len = len(a)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:69
        l = (_hx_len if ((fromIndex is None)) else (((_hx_len + fromIndex) + 1) if ((fromIndex < 0)) else (fromIndex + 1)))
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:70
        if (l > _hx_len):
            l = _hx_len
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:72
        while True:
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:72
            l = (l - 1)
            tmp = l
            if (not ((tmp > -1))):
                break
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:73
            if HxOverrides.eq(a[l],x):
                return l
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:76
        return -1

    @staticmethod
    def join(x,sep):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:82
        return sep.join([python_Boot.toString1(x1,'') for x1 in x])

    @staticmethod
    def toString(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:87
        return (("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in x]))) + "]")

    @staticmethod
    def pop(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:92
        if (len(x) == 0):
            return None
        else:
            return x.pop()

    @staticmethod
    def push(x,e):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:97
        x.append(e)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:98
        return len(x)

    @staticmethod
    def unshift(x,e):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:103
        x.insert(0, e)

    @staticmethod
    def remove(x,e):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:108
        try:
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:109
            x.remove(e)
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:110
            return True
        except BaseException as _g:
            return False

    @staticmethod
    def contains(x,e):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:118
        return (e in x)

    @staticmethod
    def shift(x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:123
        if (len(x) == 0):
            return None
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:125
        return x.pop(0)

    @staticmethod
    def slice(x,pos,end = None):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:130
        return x[pos:end]

    @staticmethod
    def sort(x,f):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:135
        x.sort(key= python_lib_Functools.cmp_to_key(f))

    @staticmethod
    def splice(x,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:140
        if (pos < 0):
            pos = (len(x) + pos)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:142
        if (pos < 0):
            pos = 0
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:144
        res = x[pos:(pos + _hx_len)]
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:145
        del x[pos:(pos + _hx_len)]
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:146
        return res

    @staticmethod
    def map(x,f):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:151
        return list(map(f,x))

    @staticmethod
    def filter(x,f):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:156
        return list(filter(f,x))

    @staticmethod
    def insert(a,pos,x):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:161
        a.insert(pos, x)

    @staticmethod
    def reverse(a):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:166
        a.reverse()

    @staticmethod
    def _get(x,idx):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:171
        if ((idx > -1) and ((idx < len(x)))):
            return x[idx]
        else:
            return None

    @staticmethod
    def _set(x,idx,v):
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:176
        l = len(x)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:177
        while (l < idx):
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:178
            x.append(None)
            # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:179
            l = (l + 1)
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:181
        if (l == idx):
            x.append(v)
        else:
            x[idx] = v
        # C:\HaxeToolkit\haxe\std/python/internal/ArrayImpl.hx:186
        return v
python_internal_ArrayImpl._hx_class = python_internal_ArrayImpl


class HxOverrides:
    _hx_class_name = "HxOverrides"
    __slots__ = ()
    _hx_statics = ["iterator", "eq", "stringOrNull", "toLowerCase", "modf", "mod", "arrayGet", "mapKwArgs"]

    @staticmethod
    def iterator(x):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:37
        if isinstance(x,list):
            return haxe_iterators_ArrayIterator(x)
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:40
        return x.iterator()

    @staticmethod
    def eq(a,b):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:53
        if (isinstance(a,list) or isinstance(b,list)):
            return a is b
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:56
        return (a == b)

    @staticmethod
    def stringOrNull(s):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:61
        if (s is None):
            return "null"
        else:
            return s

    @staticmethod
    def toLowerCase(x):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:122
        if isinstance(x,str):
            return x.lower()
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:125
        return x.toLowerCase()

    @staticmethod
    def modf(a,b):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:153
        if (b == 0.0):
            return float('nan')
        elif (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mod(a,b):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:170
        if (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def arrayGet(a,i):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:185
        if isinstance(a,list):
            # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:186
            x = a
            if ((i > -1) and ((i < len(x)))):
                return x[i]
            else:
                return None
        else:
            return a[i]

    @staticmethod
    def mapKwArgs(a,v):
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:204
        a1 = _hx_AnonObject(python_Lib.anonToDict(a))
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:205
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:205
        k = python_HaxeIterator(iter(v.keys()))
        while k.hasNext():
            k1 = k.next()
            # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:206
            val = v.get(k1)
            # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:207
            if a1._hx_hasattr(k1):
                # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:208
                x = getattr(a1,k1)
                # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:209
                setattr(a1,val,x)
                # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:210
                delattr(a1,k1)
        # C:\HaxeToolkit\haxe\std/python/internal/HxOverrides.hx:213
        return a1
HxOverrides._hx_class = HxOverrides


class python_internal_MethodClosure:
    _hx_class_name = "python.internal.MethodClosure"
    __slots__ = ("obj", "func")
    _hx_fields = ["obj", "func"]
    _hx_methods = ["__call__"]

    def __init__(self,obj,func):
        # C:\HaxeToolkit\haxe\std/python/internal/MethodClosure.hx:30
        self.obj = obj
        # C:\HaxeToolkit\haxe\std/python/internal/MethodClosure.hx:31
        self.func = func

    def __call__(self,*args):
        # C:\HaxeToolkit\haxe\std/python/internal/MethodClosure.hx:35
        return self.func(self.obj,*args)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.obj = None
        _hx_o.func = None
python_internal_MethodClosure._hx_class = python_internal_MethodClosure


class sys_net_Socket:
    _hx_class_name = "sys.net.Socket"
    __slots__ = ("_hx___s", "input", "output")
    _hx_fields = ["__s", "input", "output"]
    _hx_methods = ["__initSocket", "close", "connect", "shutdown", "setTimeout", "fileno"]

    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:115
        self.output = None
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:113
        self.input = None
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:111
        self._hx___s = None
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:120
        self._hx___initSocket()
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:121
        self.input = sys_net__Socket_SocketInput(self._hx___s)
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:122
        self.output = sys_net__Socket_SocketOutput(self._hx___s)

    def _hx___initSocket(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:126
        self._hx___s = python_lib_socket_Socket()

    def close(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:130
        self._hx___s.close()

    def connect(self,host,port):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:142
        host_str = host.toString()
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:143
        self._hx___s.connect((host_str, port))

    def shutdown(self,read,write):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:151
        self._hx___s.shutdown((python_lib_Socket.SHUT_RDWR if ((read and write)) else (python_lib_Socket.SHUT_RD if read else python_lib_Socket.SHUT_WR)))

    def setTimeout(self,timeout):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:178
        self._hx___s.settimeout(timeout)

    def fileno(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:194
        return self._hx___s.fileno()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
        _hx_o.input = None
        _hx_o.output = None
sys_net_Socket._hx_class = sys_net_Socket


class python_net_SslSocket(sys_net_Socket):
    _hx_class_name = "python.net.SslSocket"
    __slots__ = ("hostName",)
    _hx_fields = ["hostName"]
    _hx_methods = ["__initSocket", "connect"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = sys_net_Socket


    def __init__(self):
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:31
        self.hostName = None
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:30
        super().__init__()

    def _hx___initSocket(self):
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:38
        context = python_lib_ssl_SSLContext(python_lib_Ssl.PROTOCOL_SSLv23)
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:39
        context.verify_mode = python_lib_Ssl.CERT_REQUIRED
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:40
        context.set_default_verify_paths()
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:41
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv2)
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:42
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv3)
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:43
        context.options = (context.options | python_lib_Ssl.OP_NO_COMPRESSION)
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:45
        context.options = (context.options | python_lib_Ssl.OP_NO_TLSv1)
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:46
        self._hx___s = python_lib_socket_Socket()
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:47
        self._hx___s = context.wrap_socket(self._hx___s,False,True,True,self.hostName)

    def connect(self,host,port):
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:51
        self.hostName = host.host
        # C:\HaxeToolkit\haxe\std/python/net/SslSocket.hx:52
        super().connect(host,port)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.hostName = None
python_net_SslSocket._hx_class = python_net_SslSocket


class sys_Http(haxe_http_HttpBase):
    _hx_class_name = "sys.Http"
    __slots__ = ("noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file")
    _hx_fields = ["noShutdown", "cnxTimeout", "responseHeaders", "chunk_size", "chunk_buf", "file"]
    _hx_methods = ["request", "customRequest", "writeBody", "readHttpResponse", "readChunk"]
    _hx_statics = ["PROXY"]
    _hx_interfaces = []
    _hx_super = haxe_http_HttpBase


    def __init__(self,url):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:38
        self.file = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:37
        self.chunk_buf = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:36
        self.chunk_size = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:34
        self.responseHeaders = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:32
        self.noShutdown = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:49
        self.cnxTimeout = 10
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:53
        super().__init__(url)

    def request(self,post = None):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:56
        _gthis = self
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:57
        output = haxe_io_BytesOutput()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:58
        old = self.onError
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:59
        err = False
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:60
        def _hx_local_0(e):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:60
            nonlocal err
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:61
            _gthis.responseBytes = output.getBytes()
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:62
            err = True
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:64
            _gthis.onError = old
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:65
            _gthis.onError(e)
        self.onError = _hx_local_0
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:67
        post = ((post or ((self.postBytes is not None))) or ((self.postData is not None)))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:68
        self.customRequest(post,output)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:69
        if (not err):
            self.success(output.getBytes())

    def customRequest(self,post,api,sock = None,method = None):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:91
        self.responseAsString = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:92
        self.responseBytes = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:93
        url_regexp = EReg("^(https?://)?([a-zA-Z\\.0-9_-]+)(:[0-9]+)?(.*)$","")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:94
        url_regexp.matchObj = python_lib_Re.search(url_regexp.pattern,self.url)
        if (url_regexp.matchObj is None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:95
            self.onError("Invalid URL")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:96
            return
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:98
        secure = (url_regexp.matchObj.group(1) == "https://")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:99
        if (sock is None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:100
            if secure:
                sock = python_net_SslSocket()
            else:
                sock = sys_net_Socket()
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:117
            sock.setTimeout(self.cnxTimeout)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:119
        host = url_regexp.matchObj.group(2)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:120
        portString = url_regexp.matchObj.group(3)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:121
        request = url_regexp.matchObj.group(4)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:125
        if ((("" if ((0 >= len(request))) else request[0])) != "/"):
            request = ("/" + ("null" if request is None else request))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:128
        port = ((443 if secure else 80) if (((portString is None) or ((portString == "")))) else Std.parseInt(HxString.substr(portString,1,(len(portString) - 1))))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:130
        multipart = (self.file is not None)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:131
        boundary = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:132
        uri = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:133
        if multipart:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:134
            post = True
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:135
            boundary = (((Std.string(int((python_lib_Random.random() * 1000))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000)))) + Std.string(int((python_lib_Random.random() * 1000))))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:139
            while (len(boundary) < 38):
                boundary = ("-" + ("null" if boundary is None else boundary))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:141
            b_b = python_lib_io_StringIO()
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:142
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:142
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:143
                b_b.write("--")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:144
                b_b.write(Std.string(boundary))
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:145
                b_b.write("\r\n")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:146
                b_b.write("Content-Disposition: form-data; name=\"")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:147
                b_b.write(Std.string(p.name))
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:148
                b_b.write("\"")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:149
                b_b.write("\r\n")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:150
                b_b.write("\r\n")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:151
                b_b.write(Std.string(p.value))
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:152
                b_b.write("\r\n")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:154
            b_b.write("--")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:155
            b_b.write(Std.string(boundary))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:156
            b_b.write("\r\n")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:157
            b_b.write("Content-Disposition: form-data; name=\"")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:158
            b_b.write(Std.string(self.file.param))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:159
            b_b.write("\"; filename=\"")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:160
            b_b.write(Std.string(self.file.filename))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:161
            b_b.write("\"")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:162
            b_b.write("\r\n")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:163
            b_b.write(Std.string(((("Content-Type: " + HxOverrides.stringOrNull(self.file.mimeType)) + "\r\n") + "\r\n")))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:164
            uri = b_b.getvalue()
        else:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:166
            _g = 0
            _g1 = self.params
            while (_g < len(_g1)):
                p = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:167
                if (uri is None):
                    uri = ""
                else:
                    uri = (("null" if uri is None else uri) + "&")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:171
                uri = (("null" if uri is None else uri) + HxOverrides.stringOrNull((((HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(p.name,"")) + "=") + HxOverrides.stringOrNull(python_lib_urllib_Parse.quote(("" + HxOverrides.stringOrNull(p.value)),""))))))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:175
        b = haxe_io_BytesOutput()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:176
        if (method is not None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:177
            b.writeString(method)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:178
            b.writeString(" ")
        elif post:
            b.writeString("POST ")
        else:
            b.writeString("GET ")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:184
        if (sys_Http.PROXY is not None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:185
            b.writeString("http://")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:186
            b.writeString(host)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:187
            if (port != 80):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:188
                b.writeString(":")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:189
                b.writeString(("" + Std.string(port)))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:192
        b.writeString(request)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:194
        if ((not post) and ((uri is not None))):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:195
            if (HxString.indexOfImpl(request,"?",0) >= 0):
                b.writeString("&")
            else:
                b.writeString("?")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:199
            b.writeString(uri)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:201
        b.writeString(((" HTTP/1.1\r\nHost: " + ("null" if host is None else host)) + "\r\n"))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:202
        if (self.postData is not None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:203
            self.postBytes = haxe_io_Bytes.ofString(self.postData)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:204
            self.postData = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:206
        if (self.postBytes is not None):
            b.writeString((("Content-Length: " + Std.string(self.postBytes.length)) + "\r\n"))
        elif (post and ((uri is not None))):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:209
            def _hx_local_4(h):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:209
                return (h.name == "Content-Type")
            if (multipart or (not Lambda.exists(self.headers,_hx_local_4))):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:210
                b.writeString("Content-Type: ")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:211
                if multipart:
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:212
                    b.writeString("multipart/form-data")
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:213
                    b.writeString("; boundary=")
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:214
                    b.writeString(boundary)
                else:
                    b.writeString("application/x-www-form-urlencoded")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:217
                b.writeString("\r\n")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:219
            if multipart:
                b.writeString((("Content-Length: " + Std.string(((((len(uri) + self.file.size) + len(boundary)) + 6)))) + "\r\n"))
            else:
                b.writeString((("Content-Length: " + Std.string(len(uri))) + "\r\n"))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:224
        b.writeString("Connection: close\r\n")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:225
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:225
        _g = 0
        _g1 = self.headers
        while (_g < len(_g1)):
            h = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:226
            b.writeString(h.name)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:227
            b.writeString(": ")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:228
            b.writeString(h.value)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:229
            b.writeString("\r\n")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:231
        b.writeString("\r\n")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:232
        if (self.postBytes is not None):
            b.writeFullBytes(self.postBytes,0,self.postBytes.length)
        elif (post and ((uri is not None))):
            b.writeString(uri)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:236
        try:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:237
            if (sys_Http.PROXY is not None):
                sock.connect(sys_net_Host(sys_Http.PROXY.host),sys_Http.PROXY.port)
            else:
                sock.connect(sys_net_Host(host),port)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:241
            if multipart:
                self.writeBody(b,self.file.io,self.file.size,boundary,sock)
            else:
                self.writeBody(b,None,0,None,sock)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:245
            self.readHttpResponse(api,sock)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:246
            sock.close()
        except BaseException as _g:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:247
            e = haxe_Exception.caught(_g).unwrap()
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:248
            try:
                sock.close()
            except BaseException as _g:
                pass
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:251
            self.onError(Std.string(e))

    def writeBody(self,body,fileInput,fileSize,boundary,sock):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:256
        if (body is not None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:257
            _hx_bytes = body.getBytes()
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:258
            sock.output.writeFullBytes(_hx_bytes,0,_hx_bytes.length)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:260
        if (boundary is not None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:261
            bufsize = 4096
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:262
            buf = haxe_io_Bytes.alloc(bufsize)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:263
            while (fileSize > 0):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:264
                size = (bufsize if ((fileSize > bufsize)) else fileSize)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:265
                _hx_len = 0
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:266
                try:
                    _hx_len = fileInput.readBytes(buf,0,size)
                except BaseException as _g:
                    if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                        break
                    else:
                        raise _g
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:270
                sock.output.writeFullBytes(buf,0,_hx_len)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:271
                fileSize = (fileSize - _hx_len)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:273
            sock.output.writeString("\r\n")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:274
            sock.output.writeString("--")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:275
            sock.output.writeString(boundary)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:276
            sock.output.writeString("--")

    def readHttpResponse(self,api,sock):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:282
        b = haxe_io_BytesBuffer()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:283
        k = 4
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:284
        s = haxe_io_Bytes.alloc(4)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:285
        sock.setTimeout(self.cnxTimeout)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:286
        while True:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:287
            p = sock.input.readBytes(s,0,k)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:288
            while (p != k):
                p = (p + sock.input.readBytes(s,p,(k - p)))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:290
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:290
            if ((k < 0) or ((k > s.length))):
                raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
            b.b.extend(s.b[0:k])
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:291
            k1 = k
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:292
            if (k1 == 1):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:293
                c = s.b[0]
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:294
                if (c == 10):
                    break
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:296
                if (c == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 2):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:301
                c1 = s.b[1]
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:302
                if (c1 == 10):
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:303
                    if (s.b[0] == 13):
                        break
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:305
                    k = 4
                elif (c1 == 13):
                    k = 3
                else:
                    k = 4
            elif (k1 == 3):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:311
                c2 = s.b[2]
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:312
                if (c2 == 10):
                    if (s.b[1] != 13):
                        k = 4
                    elif (s.b[0] != 10):
                        k = 2
                    else:
                        break
                elif (c2 == 13):
                    if ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 1
                    else:
                        k = 3
                else:
                    k = 4
            elif (k1 == 4):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:327
                c3 = s.b[3]
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:328
                if (c3 == 10):
                    if (s.b[2] != 13):
                        continue
                    elif ((s.b[1] != 10) or ((s.b[0] != 13))):
                        k = 2
                    else:
                        break
                elif (c3 == 13):
                    if ((s.b[2] != 10) or ((s.b[1] != 13))):
                        k = 3
                    else:
                        k = 1
            else:
                pass
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:346
        _this = b.getBytes().toString()
        headers = _this.split("\r\n")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:348
        response = (None if ((len(headers) == 0)) else headers.pop(0))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:349
        rp = response.split(" ")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:350
        status = Std.parseInt((rp[1] if 1 < len(rp) else None))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:351
        if ((status == 0) or ((status is None))):
            raise haxe_Exception.thrown("Response status error")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:355
        if (len(headers) != 0):
            headers.pop()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:356
        if (len(headers) != 0):
            headers.pop()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:357
        self.responseHeaders = haxe_ds_StringMap()
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:358
        size = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:359
        chunked = False
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:360
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:360
        _g = 0
        while (_g < len(headers)):
            hline = (headers[_g] if _g >= 0 and _g < len(headers) else None)
            _g = (_g + 1)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:361
            a = hline.split(": ")
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:362
            hname = (None if ((len(a) == 0)) else a.pop(0))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:363
            hval = ((a[0] if 0 < len(a) else None) if ((len(a) == 1)) else ": ".join([python_Boot.toString1(x1,'') for x1 in a]))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:364
            hval = StringTools.ltrim(StringTools.rtrim(hval))
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:365
            self.responseHeaders.h[hname] = hval
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:366
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:366
            _g1 = hname.lower()
            _hx_local_2 = len(_g1)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:370
            if (_hx_local_2 == 17):
                if (_g1 == "transfer-encoding"):
                    chunked = (hval.lower() == "chunked")
            elif (_hx_local_2 == 14):
                if (_g1 == "content-length"):
                    size = Std.parseInt(hval)
            else:
                pass
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:374
        self.onStatus(status)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:376
        chunk_re = EReg("^([0-9A-Fa-f]+)[ ]*\r\n","m")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:377
        self.chunk_size = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:378
        self.chunk_buf = None
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:380
        bufsize = 1024
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:381
        buf = haxe_io_Bytes.alloc(bufsize)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:382
        if chunked:
            try:
                while True:
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:385
                    _hx_len = sock.input.readBytes(buf,0,bufsize)
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:386
                    if (not self.readChunk(chunk_re,api,buf,_hx_len)):
                        break
            except BaseException as _g:
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        elif (size is None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:393
            if (not self.noShutdown):
                sock.shutdown(False,True)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:395
            try:
                while True:
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:397
                    _hx_len = sock.input.readBytes(buf,0,bufsize)
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:398
                    if (_hx_len == 0):
                        break
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:400
                    api.writeBytes(buf,0,_hx_len)
            except BaseException as _g:
                if (not Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof)):
                    raise _g
        else:
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:404
            api.prepare(size)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:405
            try:
                while (size > 0):
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:407
                    _hx_len = sock.input.readBytes(buf,0,(bufsize if ((size > bufsize)) else size))
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:408
                    api.writeBytes(buf,0,_hx_len)
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:409
                    size = (size - _hx_len)
            except BaseException as _g:
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),haxe_io_Eof):
                    raise haxe_Exception.thrown("Transfer aborted")
                else:
                    raise _g
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:415
        if (chunked and (((self.chunk_size is not None) or ((self.chunk_buf is not None))))):
            raise haxe_Exception.thrown("Invalid chunk")
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:417
        if ((status < 200) or ((status >= 400))):
            raise haxe_Exception.thrown(("Http Error #" + Std.string(status)))
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:419
        api.close()

    def readChunk(self,chunk_re,api,buf,_hx_len):
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:423
        if (self.chunk_size is None):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:424
            if (self.chunk_buf is not None):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:425
                b = haxe_io_BytesBuffer()
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:426
                b.b.extend(self.chunk_buf.b)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:427
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:427
                if ((_hx_len < 0) or ((_hx_len > buf.length))):
                    raise haxe_Exception.thrown(haxe_io_Error.OutsideBounds)
                b.b.extend(buf.b[0:_hx_len])
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:428
                buf = b.getBytes()
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:429
                _hx_len = (_hx_len + self.chunk_buf.length)
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:430
                self.chunk_buf = None
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:435
            s = buf.toString()
            chunk_re.matchObj = python_lib_Re.search(chunk_re.pattern,s)
            if (chunk_re.matchObj is not None):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:437
                p_pos = chunk_re.matchObj.start()
                p_len = (chunk_re.matchObj.end() - chunk_re.matchObj.start())
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:438
                if (p_len <= _hx_len):
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:439
                    cstr = chunk_re.matchObj.group(1)
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:440
                    self.chunk_size = Std.parseInt(("0x" + ("null" if cstr is None else cstr)))
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:441
                    if (self.chunk_size == 0):
                        # C:\HaxeToolkit\haxe\std/sys/Http.hx:442
                        self.chunk_size = None
                        # C:\HaxeToolkit\haxe\std/sys/Http.hx:443
                        self.chunk_buf = None
                        # C:\HaxeToolkit\haxe\std/sys/Http.hx:444
                        return False
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:446
                    _hx_len = (_hx_len - p_len)
                    # C:\HaxeToolkit\haxe\std/sys/Http.hx:447
                    return self.readChunk(chunk_re,api,buf.sub(p_len,_hx_len),_hx_len)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:451
            if (_hx_len > 10):
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:452
                self.onError("Invalid chunk")
                # C:\HaxeToolkit\haxe\std/sys/Http.hx:453
                return False
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:455
            self.chunk_buf = buf.sub(0,_hx_len)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:456
            return True
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:459
        if (self.chunk_size > _hx_len):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:460
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:460
            _hx_local_2 = self
            _hx_local_3 = _hx_local_2.chunk_size
            _hx_local_2.chunk_size = (_hx_local_3 - _hx_len)
            _hx_local_2.chunk_size
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:461
            api.writeBytes(buf,0,_hx_len)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:462
            return True
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:464
        end = (self.chunk_size + 2)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:465
        if (_hx_len >= end):
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:466
            if (self.chunk_size > 0):
                api.writeBytes(buf,0,self.chunk_size)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:468
            _hx_len = (_hx_len - end)
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:469
            self.chunk_size = None
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:470
            if (_hx_len == 0):
                return True
            # C:\HaxeToolkit\haxe\std/sys/Http.hx:472
            return self.readChunk(chunk_re,api,buf.sub(end,_hx_len),_hx_len)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:474
        if (self.chunk_size > 0):
            api.writeBytes(buf,0,self.chunk_size)
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:476
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:476
        _hx_local_5 = self
        _hx_local_6 = _hx_local_5.chunk_size
        _hx_local_5.chunk_size = (_hx_local_6 - _hx_len)
        _hx_local_5.chunk_size
        # C:\HaxeToolkit\haxe\std/sys/Http.hx:477
        return True

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.noShutdown = None
        _hx_o.cnxTimeout = None
        _hx_o.responseHeaders = None
        _hx_o.chunk_size = None
        _hx_o.chunk_buf = None
        _hx_o.file = None
sys_Http._hx_class = sys_Http


class sys_net_Host:
    _hx_class_name = "sys.net.Host"
    __slots__ = ("host", "name")
    _hx_fields = ["host", "name"]
    _hx_methods = ["toString"]

    def __init__(self,name):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Host.hx:32
        self.host = name
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Host.hx:33
        self.name = name

    def toString(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Host.hx:37
        return self.name

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o.host = None
        _hx_o.name = None
sys_net_Host._hx_class = sys_net_Host


class sys_net__Socket_SocketInput(haxe_io_Input):
    _hx_class_name = "sys.net._Socket.SocketInput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["readByte", "readBytes"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,s):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:39
        self._hx___s = s

    def readByte(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:43
        r = None
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:44
        try:
            r = self._hx___s.recv(1,0)
        except BaseException as _g:
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:49
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:51
        return r[0]

    def readBytes(self,buf,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:55
        r = None
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:56
        data = buf.b
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:57
        try:
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:58
            r = self._hx___s.recv(_hx_len,0)
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:59
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:59
            _g = pos
            _g1 = (pos + len(r))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:60
                data.__setitem__(i,r[(i - pos)])
        except BaseException as _g:
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:65
        if (len(r) == 0):
            raise haxe_Exception.thrown(haxe_io_Eof())
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:67
        return len(r)

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
sys_net__Socket_SocketInput._hx_class = sys_net__Socket_SocketInput


class sys_net__Socket_SocketOutput(haxe_io_Output):
    _hx_class_name = "sys.net._Socket.SocketOutput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = ["writeByte", "writeBytes", "close"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self,s):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:81
        self._hx___s = s

    def writeByte(self,c):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:85
        try:
            self._hx___s.send(bytes([c]),0)
        except BaseException as _g:
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def writeBytes(self,buf,pos,_hx_len):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:93
        try:
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:94
            data = buf.b
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:95
            payload = data[pos:pos+_hx_len]
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:96
            r = self._hx___s.send(payload,0)
            # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:97
            return r
        except BaseException as _g:
            if Std.isOfType(haxe_Exception.caught(_g).unwrap(),BlockingIOError):
                raise haxe_Exception.thrown(haxe_io_Error.Blocked)
            else:
                raise _g

    def close(self):
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:104
        super().close()
        # C:\HaxeToolkit\haxe\std/python/_std/sys/net/Socket.hx:105
        if (self._hx___s is not None):
            self._hx___s.close()

    @staticmethod
    def _hx_empty_init(_hx_o):
        _hx_o._hx___s = None
sys_net__Socket_SocketOutput._hx_class = sys_net__Socket_SocketOutput


class tink_Clone:
    _hx_class_name = "tink.Clone"
    __slots__ = ()
tink_Clone._hx_class = tink_Clone

# C:\HaxeToolkit\haxe\std/python/_std/Math.hx:126
Math.NEGATIVE_INFINITY = float("-inf")
# C:\HaxeToolkit\haxe\std/python/_std/Math.hx:127
Math.POSITIVE_INFINITY = float("inf")
# C:\HaxeToolkit\haxe\std/python/_std/Math.hx:128
Math.NaN = float("nan")
# C:\HaxeToolkit\haxe\std/python/_std/Math.hx:129
Math.PI = python_lib_Math.pi

def _hx_init__Defs_Defs_Fields__fn_indices():
    # src/Defs.hx:3
    def _hx_local_0():
        # src/Defs.hx:3
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = 13
        _g.h["img2img"] = 33
        _g.h["inpaint"] = 33
        _g.h["Outpainting_mk2"] = 33
        _g.h["SD Upscale"] = 33
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.fn_indices = _hx_init__Defs_Defs_Fields__fn_indices()
_Defs_Defs_Fields_.baseurl = "http://localhost:7860"
def _hx_init__Defs_Defs_Fields__defaults():
    # src/Defs.hx:12
    def _hx_local_0():
        # src/Defs.hx:12
        _g = haxe_ds_StringMap()
        _g.h["Outpainting_mk2"] = [0, "a cute dog", "evil", "None", "None", "data:image/png;base64,", None, None, None, "Draw mask", 20, "Euler a", 4, "fill", False, False, 1, 1, 7, 0.75, -1, -1, 0, 0, 0, True, 512, 512, "Just resize", False, 32, "Inpaint masked", "", "", "Outpainting mk2", "Nonsense", True, True, "", "", True, 50, True, 1, 0, False, 4, 1, "Nonsense", 120, 7, ["left", "up", "down"], 1.02, 0.06, 128, 4, "fill", ["left", "right", "up", "down"], False, False, None, "", "Nonsense", 64, "None", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.defaults = _hx_init__Defs_Defs_Fields__defaults()
def _hx_init__Defs_Defs_Fields__ui_tags():
    # src/Defs.hx:68
    def _hx_local_0():
        # src/Defs.hx:68
        _g = haxe_ds_StringMap()
        _g.h["Outpainting_mk2"] = [None, "prompt", "negative_prompt", None, None, "!img_in", None, None, None, None, "steps", "sampler", None, None, "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "denoising_strength", "seed", "subseed", "subseed_strength", "seed_resize_from_w", "seed_resize_from_h", None, "!img_height", "!img_width", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, "outpainting_pixels_to_expand", "outpainting_mask_blur", "outpainting_directions", "outpainting_falloff_exponent", "outpainting_color_variation", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.ui_tags = _hx_init__Defs_Defs_Fields__ui_tags()
MyDocker.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'checkReady': _hx_AnonObject({'_hx_async': None})}), 'fields': _hx_AnonObject({'generate2': _hx_AnonObject({'_hx_async': None}), 'generate': _hx_AnonObject({'_hx_async': None})})})
Utils.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'receive': _hx_AnonObject({'_hx_async': None})})})
Utils.params_for_layer = []
host_App.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'getDocumentState': _hx_AnonObject({'_hx_async': None}), 'setDocumentState': _hx_AnonObject({'_hx_async': None})})})
host_App.gradio_components = []
host_App.gradio_dependencies = []
host_UI.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'asyncfetch': _hx_AnonObject({'_hx_async': None})})})
host_UI.txt2img_generate_fn_index = None
host_UI.txt2img_data_inputs = []
host_UI.txt2img_data_outputs = []
host_UI.img2img_generate_fn_index = None
host_UI.img2img_data_inputs = []
host_UI.img2img_data_outputs = []
host_UI.is_inpainting = 0
def _hx_init_host_UI_tags():
    # src/host/UI.python.hx:37
    def _hx_local_0():
        # src/host/UI.python.hx:37
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = []
        _g.h["img2img"] = []
        _g.h["inpaint"] = []
        _g.h["outpainting_mk2"] = []
        return _g
    return _hx_local_0()
host_UI.tags = _hx_init_host_UI_tags()
host__UIDefs_UIDefs_Fields_.samplers = ["Euler a", "Euler", "LMS", "Heun", "DPM2", "DPM2 a", "DPM fast", "DPM adaptive", "LMS Karras", "DPM2 Karras", "DPM2a Karras", "DDIM", "PLMS"]
def _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo():
    # src/host/UIDefs.hx:12
    def _hx_local_0():
        # src/host/UIDefs.hx:12
        _g = haxe_ds_StringMap()
        _g.h["prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "a cute dog"})
        _g.h["negative_prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "evil"})
        _g.h["steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 20, 'range': _hx_AnonObject({'min': 1, 'max': 200, 'step': 1})})
        _g.h["sampler"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "Euler a", 'comboBoxOptions': host__UIDefs_UIDefs_Fields_.samplers})
        _g.h["restore_faces"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["tiling"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["batch_count"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 32, 'step': 1})})
        _g.h["batch_size"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 16, 'step': 1})})
        _g.h["cfg_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 7, 'range': _hx_AnonObject({'min': -10, 'max': 64, 'step': 0.5})})
        _g.h["seed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.05})})
        _g.h["seed_resize_from_h"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["seed_resize_from_w"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["highres_fix"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_scale_latent"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_noise_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.7, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["denoising_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.75, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 512, 'step': 1})})
        _g.h["masked_content"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "fill", 'comboBoxOptions': ["fill", "original", "latent noise", "latent nothing"]})
        _g.h["inpaint_at_full_res"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["outpainting_pixels_to_expand"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 8, 'range': _hx_AnonObject({'min': 8, 'max': 128, 'step': 8})})
        _g.h["outpainting_mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 64, 'step': 1})})
        _g.h["outpainting_directions"] = _hx_AnonObject({'inputtype': "outpainting_directions", 'fdefault': ["left", "right", "up", "down"]})
        _g.h["outpainting_falloff_exponent"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 0, 'max': 4, 'step': 0.01})})
        _g.h["outpainting_color_variation"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.05, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["upscale_tile_overlap"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 64, 'range': _hx_AnonObject({'min': 16, 'max': 256, 'step': 16})})
        _g.h["upscaler"] = _hx_AnonObject({'inputtype': "ComboBox", 'comboBoxOptions': ["Lanczos", "None", "Real-ESRGAN 4x plus", "Real-ESRGAN 4x plus anime 6B", "LDSR"]})
        _g.h["firstpass_width"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["firstpass_height"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["Ae_learn_rate"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "0.0001"})
        _g.h["Ae_weight"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.9, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 5, 'range': _hx_AnonObject({'min': 0, 'max': 50, 'step': 1})})
        _g.h["Ae_embedding"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "None"})
        _g.h["Ae_slerp"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["Ae_text"] = _hx_AnonObject({'inputtype': "string", 'fdefault': ""})
        _g.h["Ae_slerp_angle"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.1, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_negative"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        return _g
    return _hx_local_0()
host__UIDefs_UIDefs_Fields_.widgetinfo = _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo()
def _hx_init_host__UIDefs_UIDefs_Fields__parameterNames():
    # src/host/UIDefs.hx:53
    def _hx_local_0():
        # src/host/UIDefs.hx:53
        _g = haxe_ds_StringMap()
        _g.h["variation_seed"] = "subseed"
        _g.h["variation_strength"] = "subseed_strength"
        _g.h["sampling_steps"] = "steps"
        _g.h["sampling_method"] = "sampler"
        _g.h["resize_seed_from_height"] = "resize_seed_from_h"
        _g.h["resize_seed_from_width"] = "resize_seed_from_w"
        return _g
    return _hx_local_0()
host__UIDefs_UIDefs_Fields_.parameterNames = _hx_init_host__UIDefs_UIDefs_Fields__parameterNames()
python_Boot.keywords = set(["and", "del", "from", "not", "with", "as", "elif", "global", "or", "yield", "assert", "else", "if", "pass", "None", "break", "except", "import", "raise", "True", "class", "exec", "in", "return", "False", "continue", "finally", "is", "try", "def", "for", "lambda", "while"])
python_Boot.prefixLength = len("_hx_")
sys_Http.PROXY = None