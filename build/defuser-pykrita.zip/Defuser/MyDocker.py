import sys

import math as python_lib_Math
import math as Math
from PyQt5.QtWidgets import QWidget
from krita import DockWidget
from krita import Extension
import inspect as python_lib_Inspect
from krita import Krita
from krita import ManagedColor
from krita import Selection
from PyQt5.QtCore import QBuffer
from PyQt5.QtCore import QByteArray
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QHBoxLayout
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5.QtWidgets import QCheckBox
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QGroupBox
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QPlainTextEdit
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QScrollArea
from PyQt5.QtWidgets import QSpinBox
from PyQt5.QtWidgets import QDoubleSpinBox
from PyQt5.QtWidgets import QTabWidget
import sys as python_lib_Sys
import traceback as python_lib_Traceback
import functools as python_lib_Functools
import json as python_lib_Json
import ssl as python_lib_Ssl
from datetime import datetime as python_lib_datetime_Datetime
from datetime import timezone as python_lib_datetime_Timezone
from io import StringIO as python_lib_io_StringIO
from socket import socket as python_lib_socket_Socket
from ssl import SSLContext as python_lib_ssl_SSLContext


class _hx_AnonObject:
    _hx_disable_getattr = False
    def __init__(self, fields):
        self.__dict__ = fields
    def __repr__(self):
        return repr(self.__dict__)
    def __contains__(self, item):
        return item in self.__dict__
    def __getitem__(self, item):
        return self.__dict__[item]
    def __getattr__(self, name):
        if (self._hx_disable_getattr):
            raise AttributeError('field does not exist')
        else:
            return None
    def _hx_hasattr(self,field):
        self._hx_disable_getattr = True
        try:
            getattr(self, field)
            self._hx_disable_getattr = False
            return True
        except AttributeError:
            self._hx_disable_getattr = False
            return False



class Enum:
    _hx_class_name = "Enum"
    __slots__ = ("tag", "index", "params")
    _hx_fields = ["tag", "index", "params"]
    _hx_methods = ["__str__"]

    def __init__(self,tag,index,params):
        self.tag = tag
        self.index = index
        self.params = params

    def __str__(self):
        if (self.params is None):
            return self.tag
        else:
            return self.tag + '(' + (', '.join(str(v) for v in self.params)) + ')'

Enum._hx_class = Enum


class Class: pass


class Date:
    _hx_class_name = "Date"
    __slots__ = ("date", "dateUTC")
    _hx_fields = ["date", "dateUTC"]
    _hx_methods = ["toString"]
    _hx_statics = ["makeLocal"]

    def __init__(self,year,month,day,hour,_hx_min,sec):
        self.dateUTC = None
        if (year < python_lib_datetime_Datetime.min.year):
            year = python_lib_datetime_Datetime.min.year
        if (day == 0):
            day = 1
        self.date = Date.makeLocal(python_lib_datetime_Datetime(year,(month + 1),day,hour,_hx_min,sec,0))
        self.dateUTC = self.date.astimezone(python_lib_datetime_Timezone.utc)

    def toString(self):
        return self.date.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def makeLocal(date):
        try:
            return date.astimezone()
        except BaseException as _g:
            tzinfo = python_lib_datetime_Datetime.now(python_lib_datetime_Timezone.utc).astimezone().tzinfo
            return date.replace(**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'tzinfo': tzinfo})))

Date._hx_class = Date


class haxe_IMap:
    _hx_class_name = "haxe.IMap"
    __slots__ = ()
haxe_IMap._hx_class = haxe_IMap


class haxe_ds_StringMap:
    _hx_class_name = "haxe.ds.StringMap"
    __slots__ = ("h",)
    _hx_fields = ["h"]
    _hx_methods = ["keys"]
    _hx_interfaces = [haxe_IMap]

    def __init__(self):
        self.h = dict()

    def keys(self):
        return python_HaxeIterator(iter(self.h.keys()))

haxe_ds_StringMap._hx_class = haxe_ds_StringMap


class _Defs_Defs_Fields_:
    _hx_class_name = "_Defs.Defs_Fields_"
    __slots__ = ()
    _hx_statics = ["fn_indices", "defaults", "ui_tags"]
_Defs_Defs_Fields_._hx_class = _Defs_Defs_Fields_


class host_Docker(DockWidget):
    _hx_class_name = "host.Docker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["canvasChanged"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = DockWidget


    def __init__(self):
        super().__init__()

    def canvasChanged(self,canvas):
        pass

host_Docker._hx_class = host_Docker


class hxasync_Asyncable:
    _hx_class_name = "hxasync.Asyncable"
    __slots__ = ()
hxasync_Asyncable._hx_class = hxasync_Asyncable


class MyDocker(host_Docker):
    _hx_class_name = "MyDocker"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = ["generate"]
    _hx_statics = ["__meta__", "checkReady"]
    _hx_interfaces = [hxasync_Asyncable]
    _hx_super = host_Docker


    def __init__(self):
        super().__init__()
        host_App.init(self)
        host_UI.createInterface()

    def generate(self,mode):
        ready = MyDocker.checkReady(mode)
        if ready:
            host_UI.toast(("READY - Generating " + ("null" if mode is None else mode)))
            apidata = []
            _g = 0
            _g1 = len(_Defs_Defs_Fields_.defaults.h.get(mode,None))
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                if (python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i) is not None):
                    print(str(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i)))
                    p = host_UI.gatherParameter(python_internal_ArrayImpl._get(_Defs_Defs_Fields_.ui_tags.h.get(mode,None), i))
                    print(str(p))
                    apidata.append(p)
                else:
                    x = python_internal_ArrayImpl._get(_Defs_Defs_Fields_.defaults.h.get(mode,None), i)
                    apidata.append(x)
            Utils.request(mode,apidata)

    @staticmethod
    def checkReady(mode):
        state = host_App.getDocumentState()
        if (Reflect.field(state,"selection") is None):
            selection = _hx_AnonObject({'x': 0, 'y': 0, 'width': 512, 'height': 512})
            Reflect.setField(state,"selection",selection)
            host_App.setDocumentState(state)
            host_UI.toast("NOT READY: no selection existed - defaulted to 512x512")
            return False
        elif ((HxOverrides.mod(Reflect.field(state,"selection").width, 64) != 0) or ((HxOverrides.mod(Reflect.field(state,"selection").height, 64) != 0))):
            host_UI.toast("NOT READY: resized selection to multiples of 64")
            x = (Reflect.field(state,"selection").width / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                tmp = None
            Reflect.field(state,"selection").width = (64 * ((1 + tmp)))
            x = (Reflect.field(state,"selection").height / 64)
            tmp = None
            try:
                tmp = int(x)
            except BaseException as _g:
                tmp = None
            Reflect.field(state,"selection").height = (64 * ((1 + tmp)))
            host_App.setDocumentState(state)
            return False
        if ("!mask_in" in _Defs_Defs_Fields_.ui_tags.h.get(mode,None)):
            mask = host_Image.layerByName("!sdmask")
            if (mask is None):
                host_UI.toast("mask needed - created visible layer called !sdmask")
                mask = Krita.instance().activeDocument().createNode("!sdmask","paintlayer")
                mask.setOpacity(128)
                col_white = ManagedColor("RGBA","U8","")
                col_white.setComponents([1.0, 1.0, 1.0, 1.0])
                Krita.instance().activeWindow().activeView().setForeGroundColor(col_white)
                Krita.instance().activeDocument().activeNode().parentNode().addChildNode(mask,python_internal_ArrayImpl._get(Krita.instance().activeDocument().topLevelNodes(), -1))
                Krita.instance().activeDocument().setActiveNode(mask)
                return False
        return True

MyDocker._hx_class = MyDocker


class MyExtension(Extension):
    _hx_class_name = "MyExtension"
    __slots__ = ()
    _hx_fields = []
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = Extension


    def __init__(self,parent = None):
        super().__init__(parent)
MyExtension._hx_class = MyExtension


class Reflect:
    _hx_class_name = "Reflect"
    __slots__ = ()
    _hx_statics = ["field", "setField", "isFunction"]

    @staticmethod
    def field(o,field):
        return python_Boot.field(o,field)

    @staticmethod
    def setField(o,field,value):
        setattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)),value)

    @staticmethod
    def isFunction(f):
        if (not ((python_lib_Inspect.isfunction(f) or python_lib_Inspect.ismethod(f)))):
            return python_Boot.hasField(f,"func_code")
        else:
            return True
Reflect._hx_class = Reflect


class Std:
    _hx_class_name = "Std"
    __slots__ = ()
    _hx_statics = ["is", "isOfType", "string", "parseInt"]

    @staticmethod
    def _hx_is(v,t):
        return Std.isOfType(v,t)

    @staticmethod
    def isOfType(v,t):
        if ((v is None) and ((t is None))):
            return False
        if (t is None):
            return False
        if ((type(t) == type) and (t == Dynamic)):
            return (v is not None)
        isBool = isinstance(v,bool)
        if (((type(t) == type) and (t == Bool)) and isBool):
            return True
        if ((((not isBool) and (not ((type(t) == type) and (t == Bool)))) and ((type(t) == type) and (t == Int))) and isinstance(v,int)):
            return True
        vIsFloat = isinstance(v,float)
        tmp = None
        tmp1 = None
        if (((not isBool) and vIsFloat) and ((type(t) == type) and (t == Int))):
            f = v
            tmp1 = (((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))
        else:
            tmp1 = False
        if tmp1:
            tmp1 = None
            try:
                tmp1 = int(v)
            except BaseException as _g:
                tmp1 = None
            tmp = (v == tmp1)
        else:
            tmp = False
        if ((tmp and ((v <= 2147483647))) and ((v >= -2147483648))):
            return True
        if (((not isBool) and ((type(t) == type) and (t == Float))) and isinstance(v,(float, int))):
            return True
        if ((type(t) == type) and (t == str)):
            return isinstance(v,str)
        isEnumType = ((type(t) == type) and (t == Enum))
        if ((isEnumType and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_constructs")):
            return True
        if isEnumType:
            return False
        isClassType = ((type(t) == type) and (t == Class))
        if ((((isClassType and (not isinstance(v,Enum))) and python_lib_Inspect.isclass(v)) and hasattr(v,"_hx_class_name")) and (not hasattr(v,"_hx_constructs"))):
            return True
        if isClassType:
            return False
        tmp = None
        try:
            tmp = isinstance(v,t)
        except BaseException as _g:
            tmp = False
        if tmp:
            return True
        if python_lib_Inspect.isclass(t):
            cls = t
            loop = None
            def _hx_local_1(intf):
                f = (intf._hx_interfaces if (hasattr(intf,"_hx_interfaces")) else [])
                if (f is not None):
                    _g = 0
                    while (_g < len(f)):
                        i = (f[_g] if _g >= 0 and _g < len(f) else None)
                        _g = (_g + 1)
                        if (i == cls):
                            return True
                        else:
                            l = loop(i)
                            if l:
                                return True
                    return False
                else:
                    return False
            loop = _hx_local_1
            currentClass = v.__class__
            result = False
            while (currentClass is not None):
                if loop(currentClass):
                    result = True
                    break
                currentClass = python_Boot.getSuperClass(currentClass)
            return result
        else:
            return False

    @staticmethod
    def string(s):
        return python_Boot.toString1(s,"")

    @staticmethod
    def parseInt(x):
        if (x is None):
            return None
        try:
            return int(x)
        except BaseException as _g:
            base = 10
            _hx_len = len(x)
            foundCount = 0
            sign = 0
            firstDigitIndex = 0
            lastDigitIndex = -1
            previous = 0
            _g = 0
            _g1 = _hx_len
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                c = (-1 if ((i >= len(x))) else ord(x[i]))
                if (((c > 8) and ((c < 14))) or ((c == 32))):
                    if (foundCount > 0):
                        return None
                    continue
                else:
                    c1 = c
                    if (c1 == 43):
                        if (foundCount == 0):
                            sign = 1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 45):
                        if (foundCount == 0):
                            sign = -1
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (c1 == 48):
                        if (not (((foundCount == 0) or (((foundCount == 1) and ((sign != 0))))))):
                            if (not (((48 <= c) and ((c <= 57))))):
                                if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                    break
                    elif ((c1 == 120) or ((c1 == 88))):
                        if ((previous == 48) and ((((foundCount == 1) and ((sign == 0))) or (((foundCount == 2) and ((sign != 0))))))):
                            base = 16
                        elif (not (((48 <= c) and ((c <= 57))))):
                            if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                                break
                    elif (not (((48 <= c) and ((c <= 57))))):
                        if (not (((base == 16) and ((((97 <= c) and ((c <= 122))) or (((65 <= c) and ((c <= 90))))))))):
                            break
                if (((foundCount == 0) and ((sign == 0))) or (((foundCount == 1) and ((sign != 0))))):
                    firstDigitIndex = i
                foundCount = (foundCount + 1)
                lastDigitIndex = i
                previous = c
            if (firstDigitIndex <= lastDigitIndex):
                digits = HxString.substring(x,firstDigitIndex,(lastDigitIndex + 1))
                try:
                    return (((-1 if ((sign == -1)) else 1)) * int(digits,base))
                except BaseException as _g:
                    return None
            return None
Std._hx_class = Std


class Float: pass


class Int: pass


class Bool: pass


class Dynamic: pass


class StringBuf:
    _hx_class_name = "StringBuf"
    __slots__ = ("b",)
    _hx_fields = ["b"]
    _hx_methods = ["get_length"]

    def __init__(self):
        self.b = python_lib_io_StringIO()

    def get_length(self):
        pos = self.b.tell()
        self.b.seek(0,2)
        _hx_len = self.b.tell()
        self.b.seek(pos,0)
        return _hx_len

StringBuf._hx_class = StringBuf


class StringTools:
    _hx_class_name = "StringTools"
    __slots__ = ()
    _hx_statics = ["lpad", "replace"]

    @staticmethod
    def lpad(s,c,l):
        if (len(c) <= 0):
            return s
        buf = StringBuf()
        l = (l - len(s))
        while (buf.get_length() < l):
            s1 = Std.string(c)
            buf.b.write(s1)
        s1 = Std.string(s)
        buf.b.write(s1)
        return buf.b.getvalue()

    @staticmethod
    def replace(s,sub,by):
        _this = (list(s) if ((sub == "")) else s.split(sub))
        return by.join([python_Boot.toString1(x1,'') for x1 in _this])
StringTools._hx_class = StringTools

class ValueType(Enum):
    __slots__ = ()
    _hx_class_name = "ValueType"
    _hx_constructs = ["TNull", "TInt", "TFloat", "TBool", "TObject", "TFunction", "TClass", "TEnum", "TUnknown"]

    @staticmethod
    def TClass(c):
        return ValueType("TClass", 6, (c,))

    @staticmethod
    def TEnum(e):
        return ValueType("TEnum", 7, (e,))
ValueType.TNull = ValueType("TNull", 0, ())
ValueType.TInt = ValueType("TInt", 1, ())
ValueType.TFloat = ValueType("TFloat", 2, ())
ValueType.TBool = ValueType("TBool", 3, ())
ValueType.TObject = ValueType("TObject", 4, ())
ValueType.TFunction = ValueType("TFunction", 5, ())
ValueType.TUnknown = ValueType("TUnknown", 8, ())
ValueType._hx_class = ValueType


class Type:
    _hx_class_name = "Type"
    __slots__ = ()
    _hx_statics = ["getClass", "typeof"]

    @staticmethod
    def getClass(o):
        if (o is None):
            return None
        o1 = o
        if ((o1 is not None) and ((HxOverrides.eq(o1,str) or python_lib_Inspect.isclass(o1)))):
            return None
        if isinstance(o,_hx_AnonObject):
            return None
        if hasattr(o,"_hx_class"):
            return o._hx_class
        if hasattr(o,"__class__"):
            return o.__class__
        else:
            return None

    @staticmethod
    def typeof(v):
        if (v is None):
            return ValueType.TNull
        elif isinstance(v,bool):
            return ValueType.TBool
        elif isinstance(v,int):
            return ValueType.TInt
        elif isinstance(v,float):
            return ValueType.TFloat
        elif isinstance(v,str):
            return ValueType.TClass(str)
        elif isinstance(v,list):
            return ValueType.TClass(list)
        elif (isinstance(v,_hx_AnonObject) or python_lib_Inspect.isclass(v)):
            return ValueType.TObject
        elif isinstance(v,Enum):
            return ValueType.TEnum(v.__class__)
        elif (isinstance(v,type) or hasattr(v,"_hx_class")):
            return ValueType.TClass(v.__class__)
        elif callable(v):
            return ValueType.TFunction
        else:
            return ValueType.TUnknown
Type._hx_class = Type


class Utils:
    _hx_class_name = "Utils"
    __slots__ = ()
    _hx_statics = ["__meta__", "params_for_layer", "request", "receive", "fetch_remote_png", "packInfo", "unpackInfo", "fetchAndInsert", "fastdecode64", "fastencode64"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def request(mode,in_data):
        data_formatted = haxe_format_JsonPrinter.print(_hx_AnonObject({'fn_index': _Defs_Defs_Fields_.fn_indices.h.get(mode,None), 'data': in_data, 'session_hash': None}),None,None)
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request('http://127.0.0.1:7860/api/predict')

        body_encoded = data_formatted.encode('utf-8')
        req.data=body_encoded
        req.add_header('Content-Type', 'application/json')
        req.add_header('Content-Length', str(len(body_encoded)))

        with urllib.request.urlopen(req) as res:
            Utils.receive(res.read())

        

    @staticmethod
    def receive(data):
        obj = python_lib_Json.loads(data,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        prefix = "data:image/png;base64,"
        string_array = (obj.data[0] if 0 < len(obj.data) else None)
        response_dict = python_lib_Json.loads((obj.data[1] if 1 < len(obj.data) else None),**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        _g = 0
        _g1 = len(string_array)
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            finfo = (string_array[i] if i >= 0 and i < len(string_array) else None)
            name = Utils.packInfo(response_dict)
            _hx_bytes = Utils.fetch_remote_png(Reflect.field(finfo,"name"))
            host_Image.layerFromPng(_hx_bytes,name)
            _g2 = response_dict
            value = python_Boot._add_dynamic(Reflect.field(_g2,"seed"),1)
            setattr(_g2,(("_hx_" + "seed") if (("seed" in python_Boot.keywords)) else (("_hx_" + "seed") if (((((len("seed") > 2) and ((ord("seed"[0]) == 95))) and ((ord("seed"[1]) == 95))) and ((ord("seed"[(len("seed") - 1)]) != 95)))) else "seed")),value)
            _g3 = response_dict
            value1 = python_Boot._add_dynamic(Reflect.field(_g3,"subseed"),1)
            setattr(_g3,(("_hx_" + "subseed") if (("subseed" in python_Boot.keywords)) else (("_hx_" + "subseed") if (((((len("subseed") > 2) and ((ord("subseed"[0]) == 95))) and ((ord("subseed"[1]) == 95))) and ((ord("subseed"[(len("subseed") - 1)]) != 95)))) else "subseed")),value1)
        host_UI.toast((("OK - Generation finished for " + Std.string(len(string_array))) + " image(s)!"))

    @staticmethod
    def fetch_remote_png(fname):
        data = None
        url = ("http://localhost:7860/file=" + ("null" if fname is None else fname))
        
            
        import urllib.parse
        import urllib.request
        import json
        req = urllib.request.Request(url)

        with urllib.request.urlopen(req) as res:
            data = res.read()

        
        return data

    @staticmethod
    def packInfo(info):
        info_stripped = _hx_AnonObject({})
        _g = 0
        _g1 = python_Boot.fields(info)
        while (_g < len(_g1)):
            key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if ((host__UIDefs_UIDefs_Fields_.widgetinfo.h.get(key,None) is not None) and ((Reflect.field(info,key) is not None))):
                value = Reflect.field(info,key)
                setattr(info_stripped,(("_hx_" + key) if ((key in python_Boot.keywords)) else (("_hx_" + key) if (((((len(key) > 2) and ((ord(key[0]) == 95))) and ((ord(key[1]) == 95))) and ((ord(key[(len(key) - 1)]) != 95)))) else key)),value)
        return haxe_format_JsonPrinter.print(info_stripped,None,None)

    @staticmethod
    def unpackInfo(layer):
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        host_App.setLayerName(layer,StringTools.replace(layer.name,"Copy of ",""))
        layer = Reflect.field(host_App.getDocumentState(),"layer")
        infoextract = layer._internal.name()
        jsonobj = python_lib_Json.loads(infoextract,**python__KwArgs_KwArgs_Impl_.fromT(_hx_AnonObject({'object_hook': python_Lib.dictToAnon})))
        return jsonobj

    @staticmethod
    def fetchAndInsert(layer,param_name):
        params = Utils.unpackInfo(layer)
        if (param_name is not None):
            host_UI.setParameter(param_name,Reflect.field(params,param_name))
        else:
            _g = 0
            _g1 = python_Boot.fields(params)
            while (_g < len(_g1)):
                key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if (Reflect.field(params,key) is not None):
                    host_UI.setParameter(key,Reflect.field(params,key))

    @staticmethod
    def fastdecode64(data):
        import base64
        _hx_bytes = base64.decodebytes(data.encode("utf-8"))
        return _hx_bytes

    @staticmethod
    def fastencode64(data):
        return str(data.toBase64(), "utf-8")
Utils._hx_class = Utils


class haxe_Exception(Exception):
    _hx_class_name = "haxe.Exception"
    __slots__ = ("_hx___nativeStack", "_hx___nativeException", "_hx___previousException")
    _hx_fields = ["__nativeStack", "__nativeException", "__previousException"]
    _hx_methods = ["unwrap"]
    _hx_statics = ["caught"]
    _hx_interfaces = []
    _hx_super = Exception


    def __init__(self,message,previous = None,native = None):
        self._hx___previousException = None
        self._hx___nativeException = None
        self._hx___nativeStack = None
        super().__init__(message)
        self._hx___previousException = previous
        if ((native is not None) and Std.isOfType(native,BaseException)):
            self._hx___nativeException = native
            self._hx___nativeStack = haxe_NativeStackTrace.exceptionStack()
        else:
            self._hx___nativeException = self
            infos = python_lib_Traceback.extract_stack()
            if (len(infos) != 0):
                infos.pop()
            infos.reverse()
            self._hx___nativeStack = infos

    def unwrap(self):
        return self._hx___nativeException

    @staticmethod
    def caught(value):
        if Std.isOfType(value,haxe_Exception):
            return value
        elif Std.isOfType(value,BaseException):
            return haxe_Exception(str(value),None,value)
        else:
            return haxe_ValueException(value,None,value)

haxe_Exception._hx_class = haxe_Exception


class haxe_NativeStackTrace:
    _hx_class_name = "haxe.NativeStackTrace"
    __slots__ = ()
    _hx_statics = ["saveStack", "exceptionStack"]

    @staticmethod
    def saveStack(exception):
        pass

    @staticmethod
    def exceptionStack():
        exc = python_lib_Sys.exc_info()
        if (exc[2] is not None):
            infos = python_lib_Traceback.extract_tb(exc[2])
            infos.reverse()
            return infos
        else:
            return []
haxe_NativeStackTrace._hx_class = haxe_NativeStackTrace


class haxe_ValueException(haxe_Exception):
    _hx_class_name = "haxe.ValueException"
    __slots__ = ("value",)
    _hx_fields = ["value"]
    _hx_methods = ["unwrap"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_Exception


    def __init__(self,value,previous = None,native = None):
        self.value = None
        super().__init__(Std.string(value),previous,native)
        self.value = value

    def unwrap(self):
        return self.value

haxe_ValueException._hx_class = haxe_ValueException


class haxe_format_JsonPrinter:
    _hx_class_name = "haxe.format.JsonPrinter"
    __slots__ = ("buf", "replacer", "indent", "pretty", "nind")
    _hx_fields = ["buf", "replacer", "indent", "pretty", "nind"]
    _hx_methods = ["write", "classString", "fieldsString", "quote"]
    _hx_statics = ["print"]

    def __init__(self,replacer,space):
        self.replacer = replacer
        self.indent = space
        self.pretty = (space is not None)
        self.nind = 0
        self.buf = StringBuf()

    def write(self,k,v):
        if (self.replacer is not None):
            v = self.replacer(k,v)
        _g = Type.typeof(v)
        tmp = _g.index
        if (tmp == 0):
            self.buf.b.write("null")
        elif (tmp == 1):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 2):
            f = v
            v1 = (Std.string(v) if ((((f != Math.POSITIVE_INFINITY) and ((f != Math.NEGATIVE_INFINITY))) and (not python_lib_Math.isnan(f)))) else "null")
            _this = self.buf
            s = Std.string(v1)
            _this.b.write(s)
        elif (tmp == 3):
            _this = self.buf
            s = Std.string(v)
            _this.b.write(s)
        elif (tmp == 4):
            self.fieldsString(v,python_Boot.fields(v))
        elif (tmp == 5):
            self.buf.b.write("\"<fun>\"")
        elif (tmp == 6):
            c = _g.params[0]
            if (c == str):
                self.quote(v)
            elif (c == list):
                v1 = v
                _this = self.buf
                s = "".join(map(chr,[91]))
                _this.b.write(s)
                _hx_len = len(v1)
                last = (_hx_len - 1)
                _g1 = 0
                _g2 = _hx_len
                while (_g1 < _g2):
                    i = _g1
                    _g1 = (_g1 + 1)
                    if (i > 0):
                        _this = self.buf
                        s = "".join(map(chr,[44]))
                        _this.b.write(s)
                    else:
                        _hx_local_0 = self
                        _hx_local_1 = _hx_local_0.nind
                        _hx_local_0.nind = (_hx_local_1 + 1)
                        _hx_local_1
                    if self.pretty:
                        _this1 = self.buf
                        s1 = "".join(map(chr,[10]))
                        _this1.b.write(s1)
                    if self.pretty:
                        v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                        _this2 = self.buf
                        s2 = Std.string(v2)
                        _this2.b.write(s2)
                    self.write(i,(v1[i] if i >= 0 and i < len(v1) else None))
                    if (i == last):
                        _hx_local_2 = self
                        _hx_local_3 = _hx_local_2.nind
                        _hx_local_2.nind = (_hx_local_3 - 1)
                        _hx_local_3
                        if self.pretty:
                            _this3 = self.buf
                            s3 = "".join(map(chr,[10]))
                            _this3.b.write(s3)
                        if self.pretty:
                            v3 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                            _this4 = self.buf
                            s4 = Std.string(v3)
                            _this4.b.write(s4)
                _this = self.buf
                s = "".join(map(chr,[93]))
                _this.b.write(s)
            elif (c == haxe_ds_StringMap):
                v1 = v
                o = _hx_AnonObject({})
                k = v1.keys()
                while k.hasNext():
                    k1 = k.next()
                    value = v1.h.get(k1,None)
                    setattr(o,(("_hx_" + k1) if ((k1 in python_Boot.keywords)) else (("_hx_" + k1) if (((((len(k1) > 2) and ((ord(k1[0]) == 95))) and ((ord(k1[1]) == 95))) and ((ord(k1[(len(k1) - 1)]) != 95)))) else k1)),value)
                v1 = o
                self.fieldsString(v1,python_Boot.fields(v1))
            elif (c == Date):
                v1 = v
                self.quote(v1.toString())
            else:
                self.classString(v)
        elif (tmp == 7):
            _g1 = _g.params[0]
            i = v.index
            _this = self.buf
            s = Std.string(i)
            _this.b.write(s)
        elif (tmp == 8):
            self.buf.b.write("\"???\"")
        else:
            pass

    def classString(self,v):
        self.fieldsString(v,python_Boot.getInstanceFields(Type.getClass(v)))

    def fieldsString(self,v,fields):
        _this = self.buf
        s = "".join(map(chr,[123]))
        _this.b.write(s)
        _hx_len = len(fields)
        last = (_hx_len - 1)
        first = True
        _g = 0
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            f = (fields[i] if i >= 0 and i < len(fields) else None)
            value = Reflect.field(v,f)
            if Reflect.isFunction(value):
                continue
            if first:
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.nind
                _hx_local_0.nind = (_hx_local_1 + 1)
                _hx_local_1
                first = False
            else:
                _this = self.buf
                s = "".join(map(chr,[44]))
                _this.b.write(s)
            if self.pretty:
                _this1 = self.buf
                s1 = "".join(map(chr,[10]))
                _this1.b.write(s1)
            if self.pretty:
                v1 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                _this2 = self.buf
                s2 = Std.string(v1)
                _this2.b.write(s2)
            self.quote(f)
            _this3 = self.buf
            s3 = "".join(map(chr,[58]))
            _this3.b.write(s3)
            if self.pretty:
                _this4 = self.buf
                s4 = "".join(map(chr,[32]))
                _this4.b.write(s4)
            self.write(f,value)
            if (i == last):
                _hx_local_2 = self
                _hx_local_3 = _hx_local_2.nind
                _hx_local_2.nind = (_hx_local_3 - 1)
                _hx_local_3
                if self.pretty:
                    _this5 = self.buf
                    s5 = "".join(map(chr,[10]))
                    _this5.b.write(s5)
                if self.pretty:
                    v2 = StringTools.lpad("",self.indent,(self.nind * len(self.indent)))
                    _this6 = self.buf
                    s6 = Std.string(v2)
                    _this6.b.write(s6)
        _this = self.buf
        s = "".join(map(chr,[125]))
        _this.b.write(s)

    def quote(self,s):
        _this = self.buf
        s1 = "".join(map(chr,[34]))
        _this.b.write(s1)
        i = 0
        length = len(s)
        while (i < length):
            index = i
            i = (i + 1)
            c = ord(s[index])
            c1 = c
            if (c1 == 8):
                self.buf.b.write("\\b")
            elif (c1 == 9):
                self.buf.b.write("\\t")
            elif (c1 == 10):
                self.buf.b.write("\\n")
            elif (c1 == 12):
                self.buf.b.write("\\f")
            elif (c1 == 13):
                self.buf.b.write("\\r")
            elif (c1 == 34):
                self.buf.b.write("\\\"")
            elif (c1 == 92):
                self.buf.b.write("\\\\")
            else:
                _this = self.buf
                s1 = "".join(map(chr,[c]))
                _this.b.write(s1)
        _this = self.buf
        s = "".join(map(chr,[34]))
        _this.b.write(s)

    @staticmethod
    def print(o,replacer = None,space = None):
        printer = haxe_format_JsonPrinter(replacer,space)
        printer.write("",o)
        return printer.buf.b.getvalue()

haxe_format_JsonPrinter._hx_class = haxe_format_JsonPrinter


class haxe_io_Output:
    _hx_class_name = "haxe.io.Output"
    __slots__ = ()
haxe_io_Output._hx_class = haxe_io_Output


class haxe_io_Input:
    _hx_class_name = "haxe.io.Input"
    __slots__ = ()
haxe_io_Input._hx_class = haxe_io_Input


class haxe_iterators_ArrayIterator:
    _hx_class_name = "haxe.iterators.ArrayIterator"
    __slots__ = ("array", "current")
    _hx_fields = ["array", "current"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return python_internal_ArrayImpl._get(self.array, _hx_local_2())
        return _hx_local_3()

haxe_iterators_ArrayIterator._hx_class = haxe_iterators_ArrayIterator


class haxe_iterators_ArrayKeyValueIterator:
    _hx_class_name = "haxe.iterators.ArrayKeyValueIterator"
    __slots__ = ("current", "array")
    _hx_fields = ["current", "array"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,array):
        self.current = 0
        self.array = array

    def hasNext(self):
        return (self.current < len(self.array))

    def next(self):
        def _hx_local_3():
            def _hx_local_2():
                _hx_local_0 = self
                _hx_local_1 = _hx_local_0.current
                _hx_local_0.current = (_hx_local_1 + 1)
                return _hx_local_1
            return _hx_AnonObject({'value': python_internal_ArrayImpl._get(self.array, self.current), 'key': _hx_local_2()})
        return _hx_local_3()

haxe_iterators_ArrayKeyValueIterator._hx_class = haxe_iterators_ArrayKeyValueIterator


class host_App:
    _hx_class_name = "host.App"
    __slots__ = ()
    _hx_statics = ["__meta__", "init", "getDocumentState", "setDocumentState", "setLayerName", "docker"]
    _hx_interfaces = [hxasync_Asyncable]
    docker = None

    @staticmethod
    def init(v):
        v.setWindowTitle("Defuser")
        host_App.docker = v

    @staticmethod
    def getDocumentState():
        d = Krita.instance().activeDocument()
        if (d is None):
            print("returning 3none")
            state = _hx_AnonObject({'document': None, 'layer': None, 'selection': None})
            return state
        n = d.activeNode()
        layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
        s = d.selection()
        selection = None
        if (s is not None):
            selection = _hx_AnonObject({'x': s.x(), 'y': s.y(), 'width': s.width(), 'height': s.height()})
        state = _hx_AnonObject({'document': d, 'layer': layer, 'selection': selection})
        return state

    @staticmethod
    def setDocumentState(state):
        s = Selection()
        s.select(Reflect.field(state,"selection").x,Reflect.field(state,"selection").y,Reflect.field(state,"selection").width,Reflect.field(state,"selection").height,255)
        Krita.instance().activeDocument().setSelection(s)

    @staticmethod
    def setLayerName(layer,layer_name):
        layer._internal.setName(layer_name)
host_App._hx_class = host_App


class host__Docker_Docker_Fields_:
    _hx_class_name = "host._Docker.Docker_Fields_"
    __slots__ = ()
    _hx_statics = ["myDocker"]
    myDocker = None
host__Docker_Docker_Fields_._hx_class = host__Docker_Docker_Fields_


class host_Image:
    _hx_class_name = "host.Image"
    __slots__ = ()
    _hx_statics = ["layerByName", "pngFromSelection", "layerFromPng"]
    _hx_interfaces = [hxasync_Asyncable]

    @staticmethod
    def layerByName(name):
        n = Krita.instance().activeDocument().nodeByName(name)
        if (n is not None):
            layer = _hx_AnonObject({'_internal': n, 'name': n.name(), 'id': n.index(), 'visible': n.visible()})
            return layer
        else:
            return None

    @staticmethod
    def pngFromSelection(s,layer = None):
        d = Krita.instance().activeDocument()
        d.refreshProjection()
        pixel_data = None
        if (layer is not None):
            n = Krita.instance().activeDocument().nodeByName(layer.name)
            pixel_data = n.pixelData(s.x,s.y,s.width,s.height)
        else:
            pixel_data = d.pixelData(s.x,s.y,s.width,s.height)
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import base64
        image = QImage(pixel_data.data(),s.width,s.height,QImage.Format_RGBA8888).rgbSwapped()
        data = QByteArray()
        buf = QBuffer(data)
        image.save(buf, "PNG")
        return data

    @staticmethod
    def layerFromPng(_hx_bytes,layer_name = None):
        if (layer_name is None):
            layer_name = "SD"
        
        from PyQt5.Qt import QByteArray
        from PyQt5.QtGui import QImage
        import krita
        import json
        imagen = QImage()
        imagen.loadFromData(_hx_bytes, "PNG" )
        ptr = imagen.bits()
        ptr.setsize(imagen.byteCount())
        d= Krita.instance().activeDocument()
        root = d.rootNode()
        n = d.createNode(layer_name, "paintLayer")
        s = d.selection()
        root.addChildNode(n, None)

        size = imagen.rect()
        #write pixels and refresh 
        #TODO clean this up a little for async receive. might be possible that s = None
        n.setPixelData(QByteArray(ptr.asstring()),s.x(),s.y(),size.width(),size.height())
        d.waitForDone()
        
        
        d = Krita.instance().activeDocument()
        d.refreshProjection()
host_Image._hx_class = host_Image


class host_UI:
    _hx_class_name = "host.UI"
    __slots__ = ()
    _hx_statics = ["uitop", "createInterface", "makeInput", "toast", "setParameter", "gatherParameter", "insertValue", "extractValue", "gatherSpecialParameters"]
    _hx_interfaces = [hxasync_Asyncable]
    uitop = None

    @staticmethod
    def createInterface():
        tabWidget = QTabWidget()
        host_UI.uitop = tabWidget
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(tabWidget)
        widget.setLayout(layout)
        host_App.docker.setWidget(widget)
        mode = _Defs_Defs_Fields_.ui_tags.keys()
        while mode.hasNext():
            mode1 = [mode.next()]
            tab = QWidget()
            layout_inner = QVBoxLayout()
            headerlayout = QHBoxLayout()
            btn_recycle = QPushButton("♻️")
            btn_recycle.setMaximumWidth(64)
            def _hx_local_1():
                def _hx_local_0(bool):
                    if (Reflect.field(host_App.getDocumentState(),"layer") is None):
                        host_UI.toast("No Layer selected?")
                        return
                    else:
                        Utils.fetchAndInsert(Reflect.field(host_App.getDocumentState(),"layer"),None)
                return _hx_local_0
            f_recycle = _hx_local_1()
            btn_recycle.clicked.connect(f_recycle)
            headerlayout.addWidget(btn_recycle)
            btn_run = QPushButton("Generate")
            btn_run.setStyleSheet("background-color: rgb(255, 153, 28); color: black; font: 14px;")
            def _hx_local_3(mode):
                def _hx_local_2(bool):
                    host_App.docker.generate((mode[0] if 0 < len(mode) else None))
                return _hx_local_2
            f = _hx_local_3(mode1)
            btn_run.clicked.connect(f)
            headerlayout.addWidget(btn_run)
            layout_inner.addLayout(headerlayout)
            tabform = QWidget()
            formlayout = QVBoxLayout()
            _g = 0
            _g1 = _Defs_Defs_Fields_.ui_tags.h.get((mode1[0] if 0 < len(mode1) else None),None)
            while (_g < len(_g1)):
                key = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if ((key is not None) and ((Reflect.field(key,"charAt")(0) != "!"))):
                    formlayout.addWidget(host_UI.makeInput(key,host__UIDefs_UIDefs_Fields_.widgetinfo.h.get(key,None),(mode1[0] if 0 < len(mode1) else None)))
            tabform.setLayout(formlayout)
            scroll = QScrollArea()
            scroll.setWidget(tabform)
            scroll.setWidgetResizable(True)
            layout_inner.addWidget(scroll)
            tab.setLayout(layout_inner)
            tabWidget.addTab(tab,(mode1[0] if 0 < len(mode1) else None))

    @staticmethod
    def makeInput(param,winfo,mode):
        itype = winfo.inputtype
        gbox = QGroupBox(param)
        hbox = QHBoxLayout()
        gbox.setLayout(hbox)
        if (winfo.inputtype == "prompt"):
            input = QPlainTextEdit(winfo.fdefault)
            hbox.addWidget(input)
        elif (itype == "seed"):
            line = QLineEdit()
            line.setText("-1")
            hbox.addWidget(line)
            reset = QPushButton("🎲")
            def _hx_local_0(_hx_bool):
                host_UI.insertValue(gbox,-1)
            reset.clicked.connect(_hx_local_0)
            hbox.addWidget(reset)
            keep = QPushButton("♻️")
            def _hx_local_1(_hx_bool):
                if (Reflect.field(host_App.getDocumentState(),"layer") is None):
                    host_UI.toast("No Layer selected?")
                    return
                else:
                    print(str(("resetting" + ("null" if param is None else param))))
                    Utils.fetchAndInsert(Reflect.field(host_App.getDocumentState(),"layer"),param)
            f_rec = _hx_local_1
            keep.clicked.connect(f_rec)
            hbox.addWidget(keep)
        elif (itype == "outpainting_directions"):
            checks = winfo.fdefault
            _g = 0
            while (_g < len(checks)):
                name = (checks[_g] if _g >= 0 and _g < len(checks) else None)
                _g = (_g + 1)
                chk = QCheckBox(name)
                chk.setChecked(True)
                hbox.addWidget(chk)
        elif (itype == "SpinBox"):
            try:
                _hx_local_3 = winfo.range.step
                if (Std.isOfType(_hx_local_3,Int) or ((_hx_local_3 is None))):
                    _hx_local_3
                else:
                    raise "Class cast error"
                _hx_local_3
            except BaseException as _g:
                doublespinbox = QDoubleSpinBox()
                def _hx_local_5():
                    _hx_local_4 = winfo.range.min
                    if (Std.isOfType(_hx_local_4,Float) or ((_hx_local_4 is None))):
                        _hx_local_4
                    else:
                        raise "Class cast error"
                    return _hx_local_4
                doublespinbox.setMinimum(_hx_local_5())
                def _hx_local_7():
                    _hx_local_6 = winfo.range.max
                    if (Std.isOfType(_hx_local_6,Float) or ((_hx_local_6 is None))):
                        _hx_local_6
                    else:
                        raise "Class cast error"
                    return _hx_local_6
                doublespinbox.setMaximum(_hx_local_7())
                def _hx_local_9():
                    _hx_local_8 = winfo.range.step
                    if (Std.isOfType(_hx_local_8,Float) or ((_hx_local_8 is None))):
                        _hx_local_8
                    else:
                        raise "Class cast error"
                    return _hx_local_8
                doublespinbox.setSingleStep(_hx_local_9())
                def _hx_local_11():
                    _hx_local_10 = winfo.fdefault
                    if (Std.isOfType(_hx_local_10,Float) or ((_hx_local_10 is None))):
                        _hx_local_10
                    else:
                        raise "Class cast error"
                    return _hx_local_10
                doublespinbox.setValue(_hx_local_11())
                hbox.addWidget(doublespinbox)
                return gbox
            spinbox = QSpinBox()
            def _hx_local_13():
                _hx_local_12 = winfo.range.min
                if (Std.isOfType(_hx_local_12,Int) or ((_hx_local_12 is None))):
                    _hx_local_12
                else:
                    raise "Class cast error"
                return _hx_local_12
            spinbox.setMinimum(_hx_local_13())
            def _hx_local_15():
                _hx_local_14 = winfo.range.max
                if (Std.isOfType(_hx_local_14,Int) or ((_hx_local_14 is None))):
                    _hx_local_14
                else:
                    raise "Class cast error"
                return _hx_local_14
            spinbox.setMaximum(_hx_local_15())
            def _hx_local_17():
                _hx_local_16 = winfo.range.step
                if (Std.isOfType(_hx_local_16,Int) or ((_hx_local_16 is None))):
                    _hx_local_16
                else:
                    raise "Class cast error"
                return _hx_local_16
            spinbox.setSingleStep(_hx_local_17())
            def _hx_local_19():
                _hx_local_18 = winfo.fdefault
                if (Std.isOfType(_hx_local_18,Int) or ((_hx_local_18 is None))):
                    _hx_local_18
                else:
                    raise "Class cast error"
                return _hx_local_18
            spinbox.setValue(_hx_local_19())
            hbox.addWidget(spinbox)
        elif (itype != "QDoubleSpinBox"):
            if (itype == "CheckBox"):
                chk = QCheckBox()
                def _hx_local_21():
                    _hx_local_20 = winfo.fdefault
                    if (Std.isOfType(_hx_local_20,Bool) or ((_hx_local_20 is None))):
                        _hx_local_20
                    else:
                        raise "Class cast error"
                    return _hx_local_20
                chk.setChecked(_hx_local_21())
                hbox.addWidget(chk)
            elif (itype == "ComboBox"):
                cb = QComboBox()
                cb.addItems(winfo.comboBoxOptions)
                hbox.addWidget(cb)
            elif (itype == "string"):
                line = QLineEdit()
                line.setText(winfo.fdefault)
                hbox.addWidget(line)
        return gbox

    @staticmethod
    def toast(msg):
        Krita.instance().activeWindow().activeView().showFloatingMessage(("" + Std.string(msg)),QIcon(),2000,1)

    @staticmethod
    def setParameter(param_name,value):
        tab = host_UI.uitop.currentWidget()
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                def _hx_local_4():
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                host_UI.insertValue(_hx_local_4(),value)

    @staticmethod
    def gatherParameter(param_name):
        tab = host_UI.uitop.currentWidget()
        param = None
        _g = 0
        _g1 = tab.findChildren(QGroupBox)
        while (_g < len(_g1)):
            child = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = child
                if (Std.isOfType(_hx_local_1,QGroupBox) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            if ((_hx_local_2()).title() == param_name):
                def _hx_local_4():
                    _hx_local_3 = child
                    if (Std.isOfType(_hx_local_3,QGroupBox) or ((_hx_local_3 is None))):
                        _hx_local_3
                    else:
                        raise "Class cast error"
                    return _hx_local_3
                param = host_UI.extractValue(_hx_local_4())
        if (param is None):
            param = host_UI.gatherSpecialParameters(param_name)
        if (param is None):
            print("\nerror in gatherParameter")
            print(str(param_name))
        return param

    @staticmethod
    def insertValue(groupBox,value):
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        winfo = this1.h.get(key,None)
        itype = winfo.inputtype
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_2():
                _hx_local_1 = widget
                if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                    _hx_local_1
                else:
                    raise "Class cast error"
                return _hx_local_1
            (_hx_local_2()).setPlainText(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_5():
                _hx_local_4 = widget
                if (Std.isOfType(_hx_local_4,QSpinBox) or ((_hx_local_4 is None))):
                    _hx_local_4
                else:
                    raise "Class cast error"
                return _hx_local_4
            (_hx_local_5()).setValue(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_8():
                _hx_local_7 = widget
                if (Std.isOfType(_hx_local_7,QDoubleSpinBox) or ((_hx_local_7 is None))):
                    _hx_local_7
                else:
                    raise "Class cast error"
                return _hx_local_7
            (_hx_local_8()).setValue(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_11():
                _hx_local_10 = widget
                if (Std.isOfType(_hx_local_10,QComboBox) or ((_hx_local_10 is None))):
                    _hx_local_10
                else:
                    raise "Class cast error"
                return _hx_local_10
            (_hx_local_11()).setCurrentText(value)
            return
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_14():
                _hx_local_13 = widget
                if (Std.isOfType(_hx_local_13,QLineEdit) or ((_hx_local_13 is None))):
                    _hx_local_13
                else:
                    raise "Class cast error"
                return _hx_local_13
            (_hx_local_14()).setText(Std.string(value))
            return
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            return
        else:
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                if value:
                    def _hx_local_17():
                        _hx_local_16 = widget
                        if (Std.isOfType(_hx_local_16,QCheckBox) or ((_hx_local_16 is None))):
                            _hx_local_16
                        else:
                            raise "Class cast error"
                        return _hx_local_16
                    (_hx_local_17()).setCheckState(Qt.Checked)
                else:
                    def _hx_local_19():
                        _hx_local_18 = widget
                        if (Std.isOfType(_hx_local_18,QCheckBox) or ((_hx_local_18 is None))):
                            _hx_local_18
                        else:
                            raise "Class cast error"
                        return _hx_local_18
                    (_hx_local_19()).setCheckState(Qt.Unchecked)
                return

    @staticmethod
    def extractValue(groupBox):
        this1 = host__UIDefs_UIDefs_Fields_.widgetinfo
        key = groupBox.title()
        widgetinfo = this1.h.get(key,None)
        _g = 0
        _g1 = groupBox.findChildren(QPlainTextEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_3():
                def _hx_local_2():
                    _hx_local_1 = widget
                    if (Std.isOfType(_hx_local_1,QPlainTextEdit) or ((_hx_local_1 is None))):
                        _hx_local_1
                    else:
                        raise "Class cast error"
                    return _hx_local_1
                return (_hx_local_2()).toPlainText()
            return _hx_local_3()
        _g = 0
        _g1 = groupBox.findChildren(QSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_7():
                def _hx_local_6():
                    _hx_local_5 = widget
                    if (Std.isOfType(_hx_local_5,QSpinBox) or ((_hx_local_5 is None))):
                        _hx_local_5
                    else:
                        raise "Class cast error"
                    return _hx_local_5
                return (_hx_local_6()).value()
            return _hx_local_7()
        _g = 0
        _g1 = groupBox.findChildren(QDoubleSpinBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_11():
                def _hx_local_10():
                    _hx_local_9 = widget
                    if (Std.isOfType(_hx_local_9,QDoubleSpinBox) or ((_hx_local_9 is None))):
                        _hx_local_9
                    else:
                        raise "Class cast error"
                    return _hx_local_9
                return (_hx_local_10()).value()
            return _hx_local_11()
        _g = 0
        _g1 = groupBox.findChildren(QComboBox)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            def _hx_local_15():
                def _hx_local_14():
                    _hx_local_13 = widget
                    if (Std.isOfType(_hx_local_13,QComboBox) or ((_hx_local_13 is None))):
                        _hx_local_13
                    else:
                        raise "Class cast error"
                    return _hx_local_13
                return (_hx_local_14()).currentText()
            return _hx_local_15()
        if (len(groupBox.findChildren(QCheckBox)) > 1):
            checklist = []
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                def _hx_local_18():
                    _hx_local_17 = widget
                    if (Std.isOfType(_hx_local_17,QCheckBox) or ((_hx_local_17 is None))):
                        _hx_local_17
                    else:
                        raise "Class cast error"
                    return _hx_local_17
                if (_hx_local_18()).isChecked():
                    def _hx_local_20():
                        _hx_local_19 = widget
                        if (Std.isOfType(_hx_local_19,QCheckBox) or ((_hx_local_19 is None))):
                            _hx_local_19
                        else:
                            raise "Class cast error"
                        return _hx_local_19
                    x = (_hx_local_20()).text()
                    checklist.append(x)
            return checklist
        else:
            _g = 0
            _g1 = groupBox.findChildren(QCheckBox)
            while (_g < len(_g1)):
                widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
                _g = (_g + 1)
                def _hx_local_24():
                    def _hx_local_23():
                        _hx_local_22 = widget
                        if (Std.isOfType(_hx_local_22,QCheckBox) or ((_hx_local_22 is None))):
                            _hx_local_22
                        else:
                            raise "Class cast error"
                        return _hx_local_22
                    return (_hx_local_23()).isChecked()
                return _hx_local_24()
        _g = 0
        _g1 = groupBox.findChildren(QLineEdit)
        while (_g < len(_g1)):
            widget = (_g1[_g] if _g >= 0 and _g < len(_g1) else None)
            _g = (_g + 1)
            if ((groupBox.title() == "seed") or ((groupBox.title() == "subseed"))):
                def _hx_local_28():
                    def _hx_local_27():
                        _hx_local_26 = widget
                        if (Std.isOfType(_hx_local_26,QLineEdit) or ((_hx_local_26 is None))):
                            _hx_local_26
                        else:
                            raise "Class cast error"
                        return _hx_local_26
                    return Std.parseInt((_hx_local_27()).text())
                return _hx_local_28()
            else:
                def _hx_local_31():
                    def _hx_local_30():
                        _hx_local_29 = widget
                        if (Std.isOfType(_hx_local_29,QLineEdit) or ((_hx_local_29 is None))):
                            _hx_local_29
                        else:
                            raise "Class cast error"
                        return _hx_local_29
                    return (_hx_local_30()).text()
                return _hx_local_31()
        return None

    @staticmethod
    def gatherSpecialParameters(param):
        state = host_App.getDocumentState()
        s = Krita.instance().activeDocument().selection()
        if (param == "!img_in"):
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            if (mask is not None):
                mask.setVisible(False)
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"))
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            return base64string
        elif (param == "!mask_in"):
            mask = Krita.instance().activeDocument().nodeByName("!sdmask")
            mask.setVisible(True)
            pngbytes = host_Image.pngFromSelection(Reflect.field(state,"selection"),Reflect.field(state,"layer"))
            base64string = ("data:image/png;base64," + HxOverrides.stringOrNull(Utils.fastencode64(pngbytes)))
            return base64string
        elif (param == "!img_width"):
            return s.width()
        elif (param == "!img_height"):
            return s.height()
        return None
host_UI._hx_class = host_UI


class host__UIDefs_UIDefs_Fields_:
    _hx_class_name = "host._UIDefs.UIDefs_Fields_"
    __slots__ = ()
    _hx_statics = ["samplers", "test", "widgetinfo"]
    test = None
host__UIDefs_UIDefs_Fields_._hx_class = host__UIDefs_UIDefs_Fields_


class pyqt5_qtcore__QMap_QMapIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapIterator"
    __slots__ = ("checked", "has", "it", "x")
    _hx_fields = ["checked", "has", "it", "x"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,q):
        self.x = None
        self.has = False
        self.checked = False
        self.it = q

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except StopIteration:
                self.has = False
                self.x = None
            self.checked = True

        return self.has

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

pyqt5_qtcore__QMap_QMapIterator._hx_class = pyqt5_qtcore__QMap_QMapIterator


class pyqt5_qtcore__QMap_QMapKeyValueIterator:
    _hx_class_name = "pyqt5.qtcore._QMap.QMapKeyValueIterator"
    __slots__ = ("map", "keys")
    _hx_fields = ["map", "keys"]
    _hx_methods = ["hasNext", "next"]

    def __init__(self,_hx_map):
        self.map = _hx_map
        self.keys = pyqt5_qtcore__QMap_QMapIterator(iter(_hx_map.keys()))

    def hasNext(self):
        return self.keys.hasNext()

    def next(self):
        key = self.keys.next()
        return _hx_AnonObject({'value': self.map[key], 'key': key})

pyqt5_qtcore__QMap_QMapKeyValueIterator._hx_class = pyqt5_qtcore__QMap_QMapKeyValueIterator


class python_Boot:
    _hx_class_name = "python.Boot"
    __slots__ = ()
    _hx_statics = ["keywords", "_add_dynamic", "toString1", "fields", "simpleField", "hasField", "field", "getInstanceFields", "getSuperClass", "getClassFields", "prefixLength", "unhandleKeywords"]

    @staticmethod
    def _add_dynamic(a,b):
        if (isinstance(a,str) and isinstance(b,str)):
            return (a + b)
        if (isinstance(a,str) or isinstance(b,str)):
            return (python_Boot.toString1(a,"") + python_Boot.toString1(b,""))
        return (a + b)

    @staticmethod
    def toString1(o,s):
        if (o is None):
            return "null"
        if isinstance(o,str):
            return o
        if (s is None):
            s = ""
        if (len(s) >= 5):
            return "<...>"
        if isinstance(o,bool):
            if o:
                return "true"
            else:
                return "false"
        if (isinstance(o,int) and (not isinstance(o,bool))):
            return str(o)
        if isinstance(o,float):
            try:
                if (o == int(o)):
                    return str(Math.floor((o + 0.5)))
                else:
                    return str(o)
            except BaseException as _g:
                return str(o)
        if isinstance(o,list):
            o1 = o
            l = len(o1)
            st = "["
            s = (("null" if s is None else s) + "\t")
            _g = 0
            _g1 = l
            while (_g < _g1):
                i = _g
                _g = (_g + 1)
                prefix = ""
                if (i > 0):
                    prefix = ","
                st = (("null" if st is None else st) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1((o1[i] if i >= 0 and i < len(o1) else None),s))))))
            st = (("null" if st is None else st) + "]")
            return st
        try:
            if hasattr(o,"toString"):
                return o.toString()
        except BaseException as _g:
            pass
        if hasattr(o,"__class__"):
            if isinstance(o,_hx_AnonObject):
                toStr = None
                try:
                    fields = python_Boot.fields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (("{ " + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " }")
                except BaseException as _g:
                    return "{ ... }"
                if (toStr is None):
                    return "{ ... }"
                else:
                    return toStr
            if isinstance(o,Enum):
                o1 = o
                l = len(o1.params)
                hasParams = (l > 0)
                if hasParams:
                    paramsStr = ""
                    _g = 0
                    _g1 = l
                    while (_g < _g1):
                        i = _g
                        _g = (_g + 1)
                        prefix = ""
                        if (i > 0):
                            prefix = ","
                        paramsStr = (("null" if paramsStr is None else paramsStr) + HxOverrides.stringOrNull(((("null" if prefix is None else prefix) + HxOverrides.stringOrNull(python_Boot.toString1(o1.params[i],s))))))
                    return (((HxOverrides.stringOrNull(o1.tag) + "(") + ("null" if paramsStr is None else paramsStr)) + ")")
                else:
                    return o1.tag
            if hasattr(o,"_hx_class_name"):
                if (o.__class__.__name__ != "type"):
                    fields = python_Boot.getInstanceFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((HxOverrides.stringOrNull(o._hx_class_name) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
                else:
                    fields = python_Boot.getClassFields(o)
                    _g = []
                    _g1 = 0
                    while (_g1 < len(fields)):
                        f = (fields[_g1] if _g1 >= 0 and _g1 < len(fields) else None)
                        _g1 = (_g1 + 1)
                        x = ((("" + ("null" if f is None else f)) + " : ") + HxOverrides.stringOrNull(python_Boot.toString1(python_Boot.simpleField(o,f),(("null" if s is None else s) + "\t"))))
                        _g.append(x)
                    fieldsStr = _g
                    toStr = (((("#" + HxOverrides.stringOrNull(o._hx_class_name)) + "( ") + HxOverrides.stringOrNull(", ".join([x1 for x1 in fieldsStr]))) + " )")
                    return toStr
            if ((type(o) == type) and (o == str)):
                return "#String"
            if ((type(o) == type) and (o == list)):
                return "#Array"
            if callable(o):
                return "function"
            try:
                if hasattr(o,"__repr__"):
                    return o.__repr__()
            except BaseException as _g:
                pass
            if hasattr(o,"__str__"):
                return o.__str__([])
            if hasattr(o,"__name__"):
                return o.__name__
            return "???"
        else:
            return str(o)

    @staticmethod
    def fields(o):
        a = []
        if (o is not None):
            if hasattr(o,"_hx_fields"):
                fields = o._hx_fields
                if (fields is not None):
                    return list(fields)
            if isinstance(o,_hx_AnonObject):
                d = o.__dict__
                keys = d.keys()
                handler = python_Boot.unhandleKeywords
                for k in keys:
                    if (k != '_hx_disable_getattr'):
                        a.append(handler(k))
            elif hasattr(o,"__dict__"):
                d = o.__dict__
                keys1 = d.keys()
                for k in keys1:
                    a.append(k)
        return a

    @staticmethod
    def simpleField(o,field):
        if (field is None):
            return None
        field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
        if hasattr(o,field1):
            return getattr(o,field1)
        else:
            return None

    @staticmethod
    def hasField(o,field):
        if isinstance(o,_hx_AnonObject):
            return o._hx_hasattr(field)
        return hasattr(o,(("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field)))

    @staticmethod
    def field(o,field):
        if (field is None):
            return None
        if isinstance(o,str):
            field1 = field
            _hx_local_0 = len(field1)
            if (_hx_local_0 == 10):
                if (field1 == "charCodeAt"):
                    return python_internal_MethodClosure(o,HxString.charCodeAt)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,HxString.lastIndexOf)
                elif (field1 == "toLowerCase"):
                    return python_internal_MethodClosure(o,HxString.toLowerCase)
                elif (field1 == "toUpperCase"):
                    return python_internal_MethodClosure(o,HxString.toUpperCase)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 9):
                if (field1 == "substring"):
                    return python_internal_MethodClosure(o,HxString.substring)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 5):
                if (field1 == "split"):
                    return python_internal_MethodClosure(o,HxString.split)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,HxString.indexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 8):
                if (field1 == "toString"):
                    return python_internal_MethodClosure(o,HxString.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_0 == 6):
                if (field1 == "charAt"):
                    return python_internal_MethodClosure(o,HxString.charAt)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "substr"):
                    return python_internal_MethodClosure(o,HxString.substr)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        elif isinstance(o,list):
            field1 = field
            _hx_local_1 = len(field1)
            if (_hx_local_1 == 11):
                if (field1 == "lastIndexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.lastIndexOf)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 4):
                if (field1 == "copy"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.copy)
                elif (field1 == "join"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.join)
                elif (field1 == "push"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.push)
                elif (field1 == "sort"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.sort)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 5):
                if (field1 == "shift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.shift)
                elif (field1 == "slice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.slice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 7):
                if (field1 == "indexOf"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.indexOf)
                elif (field1 == "reverse"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.reverse)
                elif (field1 == "unshift"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.unshift)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 3):
                if (field1 == "map"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.map)
                elif (field1 == "pop"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.pop)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 8):
                if (field1 == "contains"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.contains)
                elif (field1 == "iterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.iterator)
                elif (field1 == "toString"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.toString)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 16):
                if (field1 == "keyValueIterator"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.keyValueIterator)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            elif (_hx_local_1 == 6):
                if (field1 == "concat"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.concat)
                elif (field1 == "filter"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.filter)
                elif (field1 == "insert"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.insert)
                elif (field1 == "length"):
                    return len(o)
                elif (field1 == "remove"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.remove)
                elif (field1 == "splice"):
                    return python_internal_MethodClosure(o,python_internal_ArrayImpl.splice)
                else:
                    field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                    if hasattr(o,field1):
                        return getattr(o,field1)
                    else:
                        return None
            else:
                field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
                if hasattr(o,field1):
                    return getattr(o,field1)
                else:
                    return None
        else:
            field1 = (("_hx_" + field) if ((field in python_Boot.keywords)) else (("_hx_" + field) if (((((len(field) > 2) and ((ord(field[0]) == 95))) and ((ord(field[1]) == 95))) and ((ord(field[(len(field) - 1)]) != 95)))) else field))
            if hasattr(o,field1):
                return getattr(o,field1)
            else:
                return None

    @staticmethod
    def getInstanceFields(c):
        f = (list(c._hx_fields) if (hasattr(c,"_hx_fields")) else [])
        if hasattr(c,"_hx_methods"):
            f = (f + c._hx_methods)
        sc = python_Boot.getSuperClass(c)
        if (sc is None):
            return f
        else:
            scArr = python_Boot.getInstanceFields(sc)
            scMap = set(scArr)
            _g = 0
            while (_g < len(f)):
                f1 = (f[_g] if _g >= 0 and _g < len(f) else None)
                _g = (_g + 1)
                if (not (f1 in scMap)):
                    scArr.append(f1)
            return scArr

    @staticmethod
    def getSuperClass(c):
        if (c is None):
            return None
        try:
            if hasattr(c,"_hx_super"):
                return c._hx_super
            return None
        except BaseException as _g:
            pass
        return None

    @staticmethod
    def getClassFields(c):
        if hasattr(c,"_hx_statics"):
            x = c._hx_statics
            return list(x)
        else:
            return []

    @staticmethod
    def unhandleKeywords(name):
        if (HxString.substr(name,0,python_Boot.prefixLength) == "_hx_"):
            real = HxString.substr(name,python_Boot.prefixLength,None)
            if (real in python_Boot.keywords):
                return real
        return name
python_Boot._hx_class = python_Boot


class python_HaxeIterator:
    _hx_class_name = "python.HaxeIterator"
    __slots__ = ("it", "x", "has", "checked")
    _hx_fields = ["it", "x", "has", "checked"]
    _hx_methods = ["next", "hasNext"]

    def __init__(self,it):
        self.checked = False
        self.has = False
        self.x = None
        self.it = it

    def next(self):
        if (not self.checked):
            self.hasNext()
        self.checked = False
        return self.x

    def hasNext(self):
        if (not self.checked):
            try:
                self.x = self.it.__next__()
                self.has = True
            except BaseException as _g:
                if Std.isOfType(haxe_Exception.caught(_g).unwrap(),StopIteration):
                    self.has = False
                    self.x = None
                else:
                    raise _g
            self.checked = True
        return self.has

python_HaxeIterator._hx_class = python_HaxeIterator


class python__KwArgs_KwArgs_Impl_:
    _hx_class_name = "python._KwArgs.KwArgs_Impl_"
    __slots__ = ()
    _hx_statics = ["fromT"]

    @staticmethod
    def fromT(d):
        this1 = python_Lib.anonAsDict(d)
        return this1
python__KwArgs_KwArgs_Impl_._hx_class = python__KwArgs_KwArgs_Impl_


class HxString:
    _hx_class_name = "HxString"
    __slots__ = ()
    _hx_statics = ["split", "charCodeAt", "charAt", "lastIndexOf", "toUpperCase", "toLowerCase", "indexOf", "indexOfImpl", "toString", "substring", "substr"]

    @staticmethod
    def split(s,d):
        if (d == ""):
            return list(s)
        else:
            return s.split(d)

    @staticmethod
    def charCodeAt(s,index):
        if ((((s is None) or ((len(s) == 0))) or ((index < 0))) or ((index >= len(s)))):
            return None
        else:
            return ord(s[index])

    @staticmethod
    def charAt(s,index):
        if ((index < 0) or ((index >= len(s)))):
            return ""
        else:
            return s[index]

    @staticmethod
    def lastIndexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.rfind(_hx_str, 0, len(s))
        elif (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        else:
            i = s.rfind(_hx_str, 0, (startIndex + 1))
            startLeft = (max(0,((startIndex + 1) - len(_hx_str))) if ((i == -1)) else (i + 1))
            check = s.find(_hx_str, startLeft, len(s))
            if ((check > i) and ((check <= startIndex))):
                return check
            else:
                return i

    @staticmethod
    def toUpperCase(s):
        return s.upper()

    @staticmethod
    def toLowerCase(s):
        return s.lower()

    @staticmethod
    def indexOf(s,_hx_str,startIndex = None):
        if (startIndex is None):
            return s.find(_hx_str)
        else:
            return HxString.indexOfImpl(s,_hx_str,startIndex)

    @staticmethod
    def indexOfImpl(s,_hx_str,startIndex):
        if (_hx_str == ""):
            length = len(s)
            if (startIndex < 0):
                startIndex = (length + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            if (startIndex > length):
                return length
            else:
                return startIndex
        return s.find(_hx_str, startIndex)

    @staticmethod
    def toString(s):
        return s

    @staticmethod
    def substring(s,startIndex,endIndex = None):
        if (startIndex < 0):
            startIndex = 0
        if (endIndex is None):
            return s[startIndex:]
        else:
            if (endIndex < 0):
                endIndex = 0
            if (endIndex < startIndex):
                return s[endIndex:startIndex]
            else:
                return s[startIndex:endIndex]

    @staticmethod
    def substr(s,startIndex,_hx_len = None):
        if (_hx_len is None):
            return s[startIndex:]
        else:
            if (_hx_len == 0):
                return ""
            if (startIndex < 0):
                startIndex = (len(s) + startIndex)
                if (startIndex < 0):
                    startIndex = 0
            return s[startIndex:(startIndex + _hx_len)]
HxString._hx_class = HxString


class python_Lib:
    _hx_class_name = "python.Lib"
    __slots__ = ()
    _hx_statics = ["dictToAnon", "anonToDict", "anonAsDict"]

    @staticmethod
    def dictToAnon(v):
        return _hx_AnonObject(v.copy())

    @staticmethod
    def anonToDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__.copy()
        else:
            return None

    @staticmethod
    def anonAsDict(o):
        if isinstance(o,_hx_AnonObject):
            return o.__dict__
        else:
            return None
python_Lib._hx_class = python_Lib


class python_internal_ArrayImpl:
    _hx_class_name = "python.internal.ArrayImpl"
    __slots__ = ()
    _hx_statics = ["concat", "copy", "iterator", "keyValueIterator", "indexOf", "lastIndexOf", "join", "toString", "pop", "push", "unshift", "remove", "contains", "shift", "slice", "sort", "splice", "map", "filter", "insert", "reverse", "_get"]

    @staticmethod
    def concat(a1,a2):
        return (a1 + a2)

    @staticmethod
    def copy(x):
        return list(x)

    @staticmethod
    def iterator(x):
        return python_HaxeIterator(x.__iter__())

    @staticmethod
    def keyValueIterator(x):
        return haxe_iterators_ArrayKeyValueIterator(x)

    @staticmethod
    def indexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (0 if ((fromIndex is None)) else ((_hx_len + fromIndex) if ((fromIndex < 0)) else fromIndex))
        if (l < 0):
            l = 0
        _g = l
        _g1 = _hx_len
        while (_g < _g1):
            i = _g
            _g = (_g + 1)
            if HxOverrides.eq(a[i],x):
                return i
        return -1

    @staticmethod
    def lastIndexOf(a,x,fromIndex = None):
        _hx_len = len(a)
        l = (_hx_len if ((fromIndex is None)) else (((_hx_len + fromIndex) + 1) if ((fromIndex < 0)) else (fromIndex + 1)))
        if (l > _hx_len):
            l = _hx_len
        while True:
            l = (l - 1)
            tmp = l
            if (not ((tmp > -1))):
                break
            if HxOverrides.eq(a[l],x):
                return l
        return -1

    @staticmethod
    def join(x,sep):
        return sep.join([python_Boot.toString1(x1,'') for x1 in x])

    @staticmethod
    def toString(x):
        return (("[" + HxOverrides.stringOrNull(",".join([python_Boot.toString1(x1,'') for x1 in x]))) + "]")

    @staticmethod
    def pop(x):
        if (len(x) == 0):
            return None
        else:
            return x.pop()

    @staticmethod
    def push(x,e):
        x.append(e)
        return len(x)

    @staticmethod
    def unshift(x,e):
        x.insert(0, e)

    @staticmethod
    def remove(x,e):
        try:
            x.remove(e)
            return True
        except BaseException as _g:
            return False

    @staticmethod
    def contains(x,e):
        return (e in x)

    @staticmethod
    def shift(x):
        if (len(x) == 0):
            return None
        return x.pop(0)

    @staticmethod
    def slice(x,pos,end = None):
        return x[pos:end]

    @staticmethod
    def sort(x,f):
        x.sort(key= python_lib_Functools.cmp_to_key(f))

    @staticmethod
    def splice(x,pos,_hx_len):
        if (pos < 0):
            pos = (len(x) + pos)
        if (pos < 0):
            pos = 0
        res = x[pos:(pos + _hx_len)]
        del x[pos:(pos + _hx_len)]
        return res

    @staticmethod
    def map(x,f):
        return list(map(f,x))

    @staticmethod
    def filter(x,f):
        return list(filter(f,x))

    @staticmethod
    def insert(a,pos,x):
        a.insert(pos, x)

    @staticmethod
    def reverse(a):
        a.reverse()

    @staticmethod
    def _get(x,idx):
        if ((idx > -1) and ((idx < len(x)))):
            return x[idx]
        else:
            return None
python_internal_ArrayImpl._hx_class = python_internal_ArrayImpl


class HxOverrides:
    _hx_class_name = "HxOverrides"
    __slots__ = ()
    _hx_statics = ["eq", "stringOrNull", "modf", "mod", "mapKwArgs"]

    @staticmethod
    def eq(a,b):
        if (isinstance(a,list) or isinstance(b,list)):
            return a is b
        return (a == b)

    @staticmethod
    def stringOrNull(s):
        if (s is None):
            return "null"
        else:
            return s

    @staticmethod
    def modf(a,b):
        if (b == 0.0):
            return float('nan')
        elif (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mod(a,b):
        if (a < 0):
            if (b < 0):
                return -(-a % (-b))
            else:
                return -(-a % b)
        elif (b < 0):
            return a % (-b)
        else:
            return a % b

    @staticmethod
    def mapKwArgs(a,v):
        a1 = _hx_AnonObject(python_Lib.anonToDict(a))
        k = python_HaxeIterator(iter(v.keys()))
        while k.hasNext():
            k1 = k.next()
            val = v.get(k1)
            if a1._hx_hasattr(k1):
                x = getattr(a1,k1)
                setattr(a1,val,x)
                delattr(a1,k1)
        return a1
HxOverrides._hx_class = HxOverrides


class python_internal_MethodClosure:
    _hx_class_name = "python.internal.MethodClosure"
    __slots__ = ("obj", "func")
    _hx_fields = ["obj", "func"]
    _hx_methods = ["__call__"]

    def __init__(self,obj,func):
        self.obj = obj
        self.func = func

    def __call__(self,*args):
        return self.func(self.obj,*args)

python_internal_MethodClosure._hx_class = python_internal_MethodClosure


class sys_net_Socket:
    _hx_class_name = "sys.net.Socket"
    __slots__ = ("_hx___s", "input", "output")
    _hx_fields = ["__s", "input", "output"]
    _hx_methods = ["__initSocket", "fileno"]

    def __init__(self):
        self.output = None
        self.input = None
        self._hx___s = None
        self._hx___initSocket()
        self.input = sys_net__Socket_SocketInput(self._hx___s)
        self.output = sys_net__Socket_SocketOutput(self._hx___s)

    def _hx___initSocket(self):
        self._hx___s = python_lib_socket_Socket()

    def fileno(self):
        return self._hx___s.fileno()

sys_net_Socket._hx_class = sys_net_Socket


class python_net_SslSocket(sys_net_Socket):
    _hx_class_name = "python.net.SslSocket"
    __slots__ = ("hostName",)
    _hx_fields = ["hostName"]
    _hx_methods = ["__initSocket"]
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = sys_net_Socket


    def __init__(self):
        self.hostName = None
        super().__init__()

    def _hx___initSocket(self):
        context = python_lib_ssl_SSLContext(python_lib_Ssl.PROTOCOL_SSLv23)
        context.verify_mode = python_lib_Ssl.CERT_REQUIRED
        context.set_default_verify_paths()
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv2)
        context.options = (context.options | python_lib_Ssl.OP_NO_SSLv3)
        context.options = (context.options | python_lib_Ssl.OP_NO_COMPRESSION)
        context.options = (context.options | python_lib_Ssl.OP_NO_TLSv1)
        self._hx___s = python_lib_socket_Socket()
        self._hx___s = context.wrap_socket(self._hx___s,False,True,True,self.hostName)

python_net_SslSocket._hx_class = python_net_SslSocket


class sys_net__Socket_SocketInput(haxe_io_Input):
    _hx_class_name = "sys.net._Socket.SocketInput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Input


    def __init__(self,s):
        self._hx___s = s

sys_net__Socket_SocketInput._hx_class = sys_net__Socket_SocketInput


class sys_net__Socket_SocketOutput(haxe_io_Output):
    _hx_class_name = "sys.net._Socket.SocketOutput"
    __slots__ = ("_hx___s",)
    _hx_fields = ["__s"]
    _hx_methods = []
    _hx_statics = []
    _hx_interfaces = []
    _hx_super = haxe_io_Output


    def __init__(self,s):
        self._hx___s = s

sys_net__Socket_SocketOutput._hx_class = sys_net__Socket_SocketOutput

Math.NEGATIVE_INFINITY = float("-inf")
Math.POSITIVE_INFINITY = float("inf")
Math.NaN = float("nan")
Math.PI = python_lib_Math.pi

def _hx_init__Defs_Defs_Fields__fn_indices():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = 13
        _g.h["img2img"] = 33
        _g.h["inpaint"] = 33
        _g.h["Outpainting_mk2"] = 33
        _g.h["SD Upscale"] = 33
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.fn_indices = _hx_init__Defs_Defs_Fields__fn_indices()
def _hx_init__Defs_Defs_Fields__defaults():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = ["a cute dog", "evil", "None", "None", 20, "Euler a", False, False, 1, 1, 7, -1, -1, 0, 0, 0, True, 512, 512, False, 0.7, 0, 0, "None", False, False, None, "", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        _g.h["img2img"] = [0, "a cute dog", "evil", "None", "None", "data:image/png;base64,", None, None, None, "Draw mask", 20, "Euler a", 4, "fill", False, False, 1, 1, 7, 0.75, -1, -1, 0, 0, 0, True, 512, 512, "Just resize", False, 32, "Inpaint masked", "", "", "None", "Nonsense", True, True, "", "", True, 50, True, 1, 0, False, 4, 1, "Nonsense", 128, 8, ["left", "right", "up", "down"], 1, 0.05, 128, 4, "fill", ["left", "right", "up", "down"], False, False, None, "", "Nonsense", 64, "None", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        _g.h["inpaint"] = [1, "a cute dog", "evil", "None", "None", None, None, "data:image/png;base64,", "data:image/png;base64,MASK", "Upload mask", 20, "Euler a", 4, "fill", False, False, 1, 1, 7, 0.75, -1, -1, 0, 0, 0, True, 512, 512, "Just resize", False, 32, "Inpaint masked", "", "", "None", "Nonsense", True, True, "", "", True, 50, True, 1, 0, False, 4, 1, "Nonsense", 128, 8, ["left", "right", "up", "down"], 1, 0.05, 128, 4, "fill", ["left", "right", "up", "down"], False, False, None, "", "Nonsense", 64, "None", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        _g.h["Outpainting_mk2"] = [0, "a cute dog", "evil", "None", "None", "data:image/png;base64,", None, None, None, "Draw mask", 20, "Euler a", 4, "fill", False, False, 1, 1, 7, 0.75, -1, -1, 0, 0, 0, True, 512, 512, "Just resize", False, 32, "Inpaint masked", "", "", "Outpainting mk2", "Nonsense", True, True, "", "", True, 50, True, 1, 0, False, 4, 1, "Nonsense", 120, 7, ["left", "up", "down"], 1.02, 0.06, 128, 4, "fill", ["left", "right", "up", "down"], False, False, None, "", "Nonsense", 64, "None", "Seed", "", "Nothing", "", True, False, False, None, "", ""]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.defaults = _hx_init__Defs_Defs_Fields__defaults()
def _hx_init__Defs_Defs_Fields__ui_tags():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["txt2img"] = ["prompt", "negative_prompt", None, None, "steps", "sampler", "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "seed", "subseed", "subseed_strength", "seed_resize_from_h", "seed_resize_from_w", None, "!img_height", "!img_width", "highres_fix", "highres_fix_noise_scale", "firstpass_width", "firstpass_height", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        _g.h["img2img"] = [None, "prompt", "negative_prompt", None, None, "!img_in", None, None, None, None, "steps", "sampler", None, None, "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "denoising_strength", "seed", "subseed", "subseed_strength", "seed_resize_from_w", "seed_resize_from_h", None, "!img_height", "!img_width", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        _g.h["inpaint"] = [None, "prompt", "negative_prompt", None, None, None, None, "!img_in", "!mask_in", None, "steps", "sampler", "mask_blur", "masked_content", "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "denoising_strength", "seed", "subseed", "subseed_strength", "seed_resize_from_w", "seed_resize_from_h", None, "!img_height", "!img_width", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        _g.h["Outpainting_mk2"] = [None, "prompt", "negative_prompt", None, None, "!img_in", None, None, None, None, "steps", "sampler", None, None, "restore_faces", "tiling", "batch_count", "batch_size", "cfg_scale", "denoising_strength", "seed", "subseed", "subseed_strength", "seed_resize_from_w", "seed_resize_from_h", None, "!img_height", "!img_width", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, "outpainting_pixels_to_expand", "outpainting_mask_blur", "outpainting_directions", "outpainting_falloff_exponent", "outpainting_color_variation", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
        return _g
    return _hx_local_0()
_Defs_Defs_Fields_.ui_tags = _hx_init__Defs_Defs_Fields__ui_tags()
MyDocker.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'checkReady': _hx_AnonObject({'_hx_async': None})}), 'fields': _hx_AnonObject({'generate': _hx_AnonObject({'_hx_async': None})})})
Utils.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'receive': _hx_AnonObject({'_hx_async': None})})})
Utils.params_for_layer = []
host_App.__meta__ = _hx_AnonObject({'statics': _hx_AnonObject({'getDocumentState': _hx_AnonObject({'_hx_async': None}), 'setDocumentState': _hx_AnonObject({'_hx_async': None})})})
host__UIDefs_UIDefs_Fields_.samplers = ["Euler a", "Euler", "LMS", "Heun", "DPM2", "DPM2 a", "DPM fast", "DPM adaptive", "LMS Karras", "DPM2 Karras", "DPM2a Karras", "DDIM", "PLMS"]
def _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo():
    def _hx_local_0():
        _g = haxe_ds_StringMap()
        _g.h["prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "a cute dog"})
        _g.h["negative_prompt"] = _hx_AnonObject({'inputtype': "prompt", 'fdefault': "evil"})
        _g.h["steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 20, 'range': _hx_AnonObject({'min': 1, 'max': 200, 'step': 1})})
        _g.h["sampler"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "Euler a", 'comboBoxOptions': host__UIDefs_UIDefs_Fields_.samplers})
        _g.h["restore_faces"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["tiling"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["batch_count"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 32, 'step': 1})})
        _g.h["batch_size"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 1, 'max': 16, 'step': 1})})
        _g.h["cfg_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 7, 'range': _hx_AnonObject({'min': -10, 'max': 64, 'step': 0.5})})
        _g.h["seed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed"] = _hx_AnonObject({'inputtype': "seed", 'fdefault': -1})
        _g.h["subseed_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.05})})
        _g.h["seed_resize_from_h"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["seed_resize_from_w"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["highres_fix"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_scale_latent"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["highres_fix_noise_scale"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.7, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["denoising_strength"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.75, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 512, 'step': 1})})
        _g.h["masked_content"] = _hx_AnonObject({'inputtype': "ComboBox", 'fdefault': "fill", 'comboBoxOptions': ["fill", "original", "latent noise", "latent nothing"]})
        _g.h["inpaint_at_full_res"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["outpainting_pixels_to_expand"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 8, 'range': _hx_AnonObject({'min': 8, 'max': 128, 'step': 8})})
        _g.h["outpainting_mask_blur"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 4, 'range': _hx_AnonObject({'min': 0, 'max': 64, 'step': 1})})
        _g.h["outpainting_directions"] = _hx_AnonObject({'inputtype': "outpainting_directions", 'fdefault': ["left", "right", "up", "down"]})
        _g.h["outpainting_falloff_exponent"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 1, 'range': _hx_AnonObject({'min': 0, 'max': 4, 'step': 0.01})})
        _g.h["outpainting_color_variation"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.05, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["upscale_tile_overlap"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 64, 'range': _hx_AnonObject({'min': 16, 'max': 256, 'step': 16})})
        _g.h["upscaler"] = _hx_AnonObject({'inputtype': "ComboBox", 'comboBoxOptions': ["Lanczos", "None", "Real-ESRGAN 4x plus", "Real-ESRGAN 4x plus anime 6B", "LDSR"]})
        _g.h["firstpass_width"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["firstpass_height"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0, 'range': _hx_AnonObject({'min': 0, 'max': 1024, 'step': 64})})
        _g.h["Ae_learn_rate"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "0.0001"})
        _g.h["Ae_weight"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.9, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_steps"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 5, 'range': _hx_AnonObject({'min': 0, 'max': 50, 'step': 1})})
        _g.h["Ae_embedding"] = _hx_AnonObject({'inputtype': "string", 'fdefault': "None"})
        _g.h["Ae_slerp"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        _g.h["Ae_text"] = _hx_AnonObject({'inputtype': "string", 'fdefault': ""})
        _g.h["Ae_slerp_angle"] = _hx_AnonObject({'inputtype': "SpinBox", 'fdefault': 0.1, 'range': _hx_AnonObject({'min': 0, 'max': 1, 'step': 0.01})})
        _g.h["Ae_negative"] = _hx_AnonObject({'inputtype': "CheckBox", 'fdefault': False})
        return _g
    return _hx_local_0()
host__UIDefs_UIDefs_Fields_.widgetinfo = _hx_init_host__UIDefs_UIDefs_Fields__widgetinfo()
python_Boot.keywords = set(["and", "del", "from", "not", "with", "as", "elif", "global", "or", "yield", "assert", "else", "if", "pass", "None", "break", "except", "import", "raise", "True", "class", "exec", "in", "return", "False", "continue", "finally", "is", "try", "def", "for", "lambda", "while"])
python_Boot.prefixLength = len("_hx_")