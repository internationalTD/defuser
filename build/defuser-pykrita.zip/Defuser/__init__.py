from krita import DockWidgetFactory, DockWidgetFactoryBase, Extension
from .MyDocker import MyDocker
from PyQt5.QtWidgets import QTabWidget
DOCKER_ID = 'Defuser'

instance = Krita.instance()

class MyExtension(Extension):

    def __init__(self, parent):
        # This is initialising the parent, always important when subclassing.
        super().__init__(parent)

        self.docker = None
    def getDocker(self):

        if self.docker == None:
            dockersList = Krita.instance().dockers()
            for docker in dockersList:
                if docker.objectName() == DOCKER_ID:
                    self.docker= docker

        return self.docker
    def setup(self):
        pass

    def createActions(self, window):
        sdCheckReady_action = window.createAction("defuser_check", "SD Check requirements and fix", "tools/scripts")
        def f():


            docker = self.getDocker()
            mode = docker.widget().findChildren(QTabWidget)[0].tabText( docker.widget().findChildren(QTabWidget)[0].currentIndex()) 
            loop_max = 32
            while not docker.checkReady(mode) and loop_max >0:
                #TODO: fix this, a bit unsafe if waiting on the "create Document" dialog. (infinite loop w/o user input)
                docker.checkReady(mode)
                loop_max -= 1
        sdCheckReady_action.triggered.connect(f)

        sdGenerate_action = window.createAction("defuser_generate", "SD Generate if ready", "tools/scripts")
        def f2():
            docker = self.getDocker()
            mode = docker.widget().findChildren(QTabWidget)[0].tabText( docker.widget().findChildren(QTabWidget)[0].currentIndex()) 
            docker.generate()
        sdGenerate_action.triggered.connect(f2)

dock_widget_factory = DockWidgetFactory(DOCKER_ID,
                                        DockWidgetFactoryBase.DockRight,
                                        MyDocker)

instance.addExtension(MyExtension(instance))
instance.addDockWidgetFactory(dock_widget_factory)